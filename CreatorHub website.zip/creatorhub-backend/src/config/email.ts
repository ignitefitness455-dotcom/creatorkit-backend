import nodemailer from 'nodemailer';
import { env, isEmailConfigured } from './env';

// Email transporter
let transporter: nodemailer.Transporter | null = null;

if (isEmailConfigured()) {
  // Using Resend SMTP
  transporter = nodemailer.createTransport({
    host: 'smtp.resend.com',
    port: 465,
    secure: true,
    auth: {
      user: 'resend',
      pass: env.RESEND_API_KEY,
    },
  });
}

// Send email
export async function sendEmail(
  to: string,
  subject: string,
  html: string,
  text?: string
): Promise<boolean> {
  if (!transporter) {
    console.log('Email not configured. Would send:');
    console.log(`To: ${to}`);
    console.log(`Subject: ${subject}`);
    console.log(`Body: ${html}`);
    return true; // Return true in development
  }

  try {
    await transporter.sendMail({
      from: env.EMAIL_FROM,
      to,
      subject,
      html,
      text: text || html.replace(/<[^>]*>/g, ''),
    });
    return true;
  } catch (error) {
    console.error('Failed to send email:', error);
    return false;
  }
}

// Send verification email
export async function sendVerificationEmail(
  to: string,
  name: string,
  token: string
): Promise<boolean> {
  const verificationUrl = `${env.FRONTEND_URL}/verify-email?token=${token}`;
  
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #6366f1;">Verify Your Email</h2>
      <p>Hi ${name || 'there'},</p>
      <p>Thank you for signing up! Please verify your email address by clicking the button below:</p>
      <a href="${verificationUrl}" 
         style="display: inline-block; background: #6366f1; color: white; padding: 12px 24px; 
                text-decoration: none; border-radius: 8px; margin: 16px 0;">
        Verify Email
      </a>
      <p>Or copy and paste this link:</p>
      <p style="word-break: break-all; color: #6366f1;">${verificationUrl}</p>
      <p>This link will expire in 24 hours.</p>
      <hr style="border: none; border-top: 1px solid #e5e7eb; margin: 24px 0;">
      <p style="color: #6b7280; font-size: 12px;">
        If you didn't create an account, you can safely ignore this email.
      </p>
    </div>
  `;

  return sendEmail(to, 'Verify Your Email - CreatorHub', html);
}

// Send password reset email
export async function sendPasswordResetEmail(
  to: string,
  name: string,
  token: string
): Promise<boolean> {
  const resetUrl = `${env.FRONTEND_URL}/reset-password?token=${token}`;
  
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #6366f1;">Reset Your Password</h2>
      <p>Hi ${name || 'there'},</p>
      <p>We received a request to reset your password. Click the button below to create a new password:</p>
      <a href="${resetUrl}" 
         style="display: inline-block; background: #6366f1; color: white; padding: 12px 24px; 
                text-decoration: none; border-radius: 8px; margin: 16px 0;">
        Reset Password
      </a>
      <p>Or copy and paste this link:</p>
      <p style="word-break: break-all; color: #6366f1;">${resetUrl}</p>
      <p>This link will expire in 1 hour.</p>
      <hr style="border: none; border-top: 1px solid #e5e7eb; margin: 24px 0;">
      <p style="color: #6b7280; font-size: 12px;">
        If you didn't request a password reset, you can safely ignore this email.
      </p>
    </div>
  `;

  return sendEmail(to, 'Reset Your Password - CreatorHub', html);
}

// Send welcome email
export async function sendWelcomeEmail(to: string, name: string): Promise<boolean> {
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #6366f1;">Welcome to CreatorHub!</h2>
      <p>Hi ${name || 'there'},</p>
      <p>Welcome to CreatorHub! We're excited to have you on board.</p>
      <p>With CreatorHub, you can:</p>
      <ul>
        <li>Process PDFs - merge, split, compress, convert</li>
        <li>Edit images - compress, remove backgrounds, upscale</li>
        <li>Generate AI content - hashtags, captions, bios</li>
        <li>Create business tools - QR codes, invoices, passwords</li>
      </ul>
      <a href="${env.FRONTEND_URL}/tools" 
         style="display: inline-block; background: #6366f1; color: white; padding: 12px 24px; 
                text-decoration: none; border-radius: 8px; margin: 16px 0;">
        Explore Tools
      </a>
      <hr style="border: none; border-top: 1px solid #e5e7eb; margin: 24px 0;">
      <p style="color: #6b7280; font-size: 12px;">
        Need help? Contact us at support@creatorhub.com
      </p>
    </div>
  `;

  return sendEmail(to, 'Welcome to CreatorHub!', html);
}

// Send subscription confirmation email
export async function sendSubscriptionEmail(
  to: string,
  name: string,
  plan: string
): Promise<boolean> {
  const html = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <h2 style="color: #6366f1;">Subscription Confirmed!</h2>
      <p>Hi ${name || 'there'},</p>
      <p>Thank you for subscribing to CreatorHub ${plan} plan!</p>
      <p>Your subscription is now active. You can manage your subscription from your account settings.</p>
      <a href="${env.FRONTEND_URL}/dashboard/settings" 
         style="display: inline-block; background: #6366f1; color: white; padding: 12px 24px; 
                text-decoration: none; border-radius: 8px; margin: 16px 0;">
        Manage Subscription
      </a>
      <hr style="border: none; border-top: 1px solid #e5e7eb; margin: 24px 0;">
      <p style="color: #6b7280; font-size: 12px;">
        Questions? Contact us at support@creatorhub.com
      </p>
    </div>
  `;

  return sendEmail(to, `CreatorHub ${plan} Subscription Confirmed`, html);
}

export default transporter;
