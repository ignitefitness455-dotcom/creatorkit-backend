import { z } from 'zod';

const envSchema = z.object({
  // Database
  DATABASE_URL: z.string().min(1),
  
  // JWT - make optional for deployment, will use defaults
  JWT_SECRET: z.string().min(1).default('default-jwt-secret-change-in-production-min-32-chars-long'),
  JWT_REFRESH_SECRET: z.string().min(1).default('default-refresh-secret-change-in-production-min-32'),
  JWT_EXPIRES_IN: z.string().default('15m'),
  JWT_REFRESH_EXPIRES_IN: z.string().default('7d'),
  
  // AWS S3
  AWS_ACCESS_KEY_ID: z.string().optional(),
  AWS_SECRET_ACCESS_KEY: z.string().optional(),
  AWS_REGION: z.string().default('us-east-1'),
  AWS_S3_BUCKET: z.string().default('creatorhub-uploads'),
  AWS_S3_ENDPOINT: z.string().optional(),
  
  // Redis - make optional, will use in-memory fallback
  REDIS_URL: z.string().optional().default(''),
  UPSTASH_REDIS_REST_URL: z.string().optional(),
  UPSTASH_REDIS_REST_TOKEN: z.string().optional(),
  
  // OpenAI
  OPENAI_API_KEY: z.string().optional(),
  
  // Stripe
  STRIPE_SECRET_KEY: z.string().optional(),
  STRIPE_PUBLISHABLE_KEY: z.string().optional(),
  STRIPE_WEBHOOK_SECRET: z.string().optional(),
  STRIPE_PRICE_BASIC: z.string().optional(),
  STRIPE_PRICE_PRO: z.string().optional(),
  STRIPE_PRICE_ENTERPRISE: z.string().optional(),
  
  // Email
  RESEND_API_KEY: z.string().optional(),
  EMAIL_FROM: z.string().default('noreply@creatorhub.com'),
  
  // App
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  PORT: z.string().default('5000'),
  FRONTEND_URL: z.string().default('http://localhost:5173'),
  API_URL: z.string().default('http://localhost:5000'),
  
  // Rate Limiting
  RATE_LIMIT_WINDOW_MS: z.string().default('900000'),
  RATE_LIMIT_MAX_REQUESTS: z.string().default('100'),
});

const parsedEnv = envSchema.safeParse(process.env);

if (!parsedEnv.success) {
  console.error('❌ Invalid environment variables:');
  parsedEnv.error.issues.forEach((issue) => {
    console.error(`  - ${issue.path.join('.')}: ${issue.message}`);
  });
  // Don't exit, just log warnings in production
  if (process.env.NODE_ENV === 'production') {
    console.warn('⚠️  Continuing with default values...');
  }
}

export const env = parsedEnv.success ? parsedEnv.data : envSchema.parse({});

// Helper to check if Stripe is configured
export const isStripeConfigured = (): boolean => {
  return !!env.STRIPE_SECRET_KEY && !!env.STRIPE_WEBHOOK_SECRET;
};

// Helper to check if OpenAI is configured
export const isOpenAIConfigured = (): boolean => {
  return !!env.OPENAI_API_KEY;
};

// Helper to check if AWS is configured
export const isAWSConfigured = (): boolean => {
  return !!env.AWS_ACCESS_KEY_ID && !!env.AWS_SECRET_ACCESS_KEY;
};

// Helper to check if email is configured
export const isEmailConfigured = (): boolean => {
  return !!env.RESEND_API_KEY;
};

export default env;
