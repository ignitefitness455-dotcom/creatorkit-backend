import { S3Client, PutObjectCommand, GetObjectCommand, DeleteObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { env, isAWSConfigured } from './env';
import fs from 'fs/promises';
import path from 'path';

// Check if AWS is configured
const awsConfigured = isAWSConfigured();

// S3 Client configuration - only create if AWS is configured
let s3ClientInstance: S3Client | null = null;

if (awsConfigured) {
  const s3Config: any = {
    region: env.AWS_REGION,
    credentials: {
      accessKeyId: env.AWS_ACCESS_KEY_ID!,
      secretAccessKey: env.AWS_SECRET_ACCESS_KEY!,
    },
  };

  // Add custom endpoint for Cloudflare R2 or MinIO
  if (env.AWS_S3_ENDPOINT) {
    s3Config.endpoint = env.AWS_S3_ENDPOINT;
    s3Config.forcePathStyle = true;
  }

  s3ClientInstance = new S3Client(s3Config);
}

export const s3Client = s3ClientInstance;
export const S3_BUCKET = env.AWS_S3_BUCKET;

// Local storage fallback when S3 is not configured
const localStoragePath = path.join(process.cwd(), 'uploads', 'files');

// Ensure local storage directory exists
async function ensureLocalStorage(): Promise<void> {
  try {
    await fs.mkdir(localStoragePath, { recursive: true });
  } catch {}
}

// Generate presigned URL for upload
export async function generateUploadUrl(
  key: string,
  contentType: string,
  expiresIn: number = 300
): Promise<string> {
  if (!s3Client) {
    // Local storage fallback - return a local URL
    await ensureLocalStorage();
    return `${env.API_URL}/api/files/local-upload/${encodeURIComponent(key)}`;
  }

  const command = new PutObjectCommand({
    Bucket: S3_BUCKET,
    Key: key,
    ContentType: contentType,
  });

  return getSignedUrl(s3Client, command, { expiresIn });
}

// Generate presigned URL for download
export async function generateDownloadUrl(
  key: string,
  expiresIn: number = 300
): Promise<string> {
  if (!s3Client) {
    // Local storage fallback
    return `${env.API_URL}/api/files/local-download/${encodeURIComponent(path.basename(key))}`;
  }

  const command = new GetObjectCommand({
    Bucket: S3_BUCKET,
    Key: key,
  });

  return getSignedUrl(s3Client, command, { expiresIn });
}

// Delete object from S3
export async function deleteObject(key: string): Promise<void> {
  if (!s3Client) {
    // Local storage fallback
    const localPath = path.join(localStoragePath, path.basename(key));
    try {
      await fs.unlink(localPath);
    } catch {}
    return;
  }

  const command = new DeleteObjectCommand({
    Bucket: S3_BUCKET,
    Key: key,
  });

  await s3Client.send(command);
}

// Save file locally (fallback when S3 not configured)
export async function saveFileLocally(
  fileBuffer: Buffer,
  fileName: string
): Promise<{ filePath: string; url: string }> {
  await ensureLocalStorage();
  const localFileName = `${Date.now()}-${fileName}`;
  const filePath = path.join(localStoragePath, localFileName);
  await fs.writeFile(filePath, fileBuffer);
  
  return {
    filePath,
    url: `${env.API_URL}/api/files/local-download/${encodeURIComponent(localFileName)}`,
  };
}

// Generate S3 key for user file
export function generateS3Key(userId: string, fileName: string): string {
  const timestamp = Date.now();
  const random = Math.random().toString(36).substring(2, 8);
  const sanitizedFileName = fileName.replace(/[^a-zA-Z0-9.-]/g, '_');
  return `uploads/${userId}/${timestamp}-${random}-${sanitizedFileName}`;
}

// Get public URL (for public buckets)
export function getPublicUrl(key: string): string {
  if (!s3Client) {
    return `${env.API_URL}/api/files/local-download/${encodeURIComponent(path.basename(key))}`;
  }
  
  if (env.AWS_S3_ENDPOINT) {
    return `${env.AWS_S3_ENDPOINT}/${S3_BUCKET}/${key}`;
  }
  return `https://${S3_BUCKET}.s3.${env.AWS_REGION}.amazonaws.com/${key}`;
}

export default s3Client;
