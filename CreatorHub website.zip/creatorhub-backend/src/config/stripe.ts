import Stripe from 'stripe';
import { env, isStripeConfigured } from './env';

// Initialize Stripe only if configured
export const stripe = isStripeConfigured() 
  ? new Stripe(env.STRIPE_SECRET_KEY!, { apiVersion: '2023-10-16' })
  : null;

// Price IDs
export const PRICE_IDS = {
  BASIC: env.STRIPE_PRICE_BASIC,
  PRO: env.STRIPE_PRICE_PRO,
  ENTERPRISE: env.STRIPE_PRICE_ENTERPRISE,
};

// Plan prices (in cents) - fallback if Stripe not configured
export const PLAN_PRICES = {
  BASIC: 999,      // $9.99
  PRO: 2999,       // $29.99
  ENTERPRISE: 9999, // $99.99
};

// Create Stripe customer
export async function createStripeCustomer(email: string, name?: string): Promise<string | null> {
  if (!stripe) return null;
  
  const customer = await stripe.customers.create({
    email,
    name,
  });
  
  return customer.id;
}

// Create checkout session
export async function createCheckoutSession(
  customerId: string,
  priceId: string,
  successUrl: string,
  cancelUrl: string
): Promise<Stripe.Checkout.Session | null> {
  if (!stripe) return null;
  
  const session = await stripe.checkout.sessions.create({
    customer: customerId,
    payment_method_types: ['card'],
    line_items: [
      {
        price: priceId,
        quantity: 1,
      },
    ],
    mode: 'subscription',
    success_url: successUrl,
    cancel_url: cancelUrl,
    subscription_data: {
      trial_period_days: 7, // 7-day free trial
    },
  });
  
  return session;
}

// Create customer portal session
export async function createPortalSession(
  customerId: string,
  returnUrl: string
): Promise<Stripe.BillingPortal.Session | null> {
  if (!stripe) return null;
  
  const session = await stripe.billingPortal.sessions.create({
    customer: customerId,
    return_url: returnUrl,
  });
  
  return session;
}

// Cancel subscription
export async function cancelSubscription(subscriptionId: string): Promise<Stripe.Subscription | null> {
  if (!stripe) return null;
  
  const subscription = await stripe.subscriptions.update(subscriptionId, {
    cancel_at_period_end: true,
  });
  
  return subscription;
}

// Resume subscription
export async function resumeSubscription(subscriptionId: string): Promise<Stripe.Subscription | null> {
  if (!stripe) return null;
  
  const subscription = await stripe.subscriptions.update(subscriptionId, {
    cancel_at_period_end: false,
  });
  
  return subscription;
}

// Get subscription details
export async function getSubscription(subscriptionId: string): Promise<Stripe.Subscription | null> {
  if (!stripe) return null;
  
  return stripe.subscriptions.retrieve(subscriptionId);
}

// Construct webhook event
export function constructWebhookEvent(
  payload: string | Buffer,
  signature: string
): Stripe.Event | null {
  if (!stripe || !env.STRIPE_WEBHOOK_SECRET) return null;
  
  try {
    return stripe.webhooks.constructEvent(payload, signature, env.STRIPE_WEBHOOK_SECRET);
  } catch (err: any) {
    console.error('Webhook signature verification failed:', err.message);
    return null;
  }
}

export default stripe;
