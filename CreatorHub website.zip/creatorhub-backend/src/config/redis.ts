import Redis from 'ioredis';
import { env } from './env';

// Check if Redis URL is configured
const hasRedisUrl = env.REDIS_URL && env.REDIS_URL.length > 0;

// Create Redis client or mock for development
let redisClient: Redis;

if (hasRedisUrl) {
  redisClient = new Redis(env.REDIS_URL, {
    maxRetriesPerRequest: null,
    enableReadyCheck: false,
    retryStrategy: (times) => {
      if (times > 3) {
        console.warn('⚠️  Redis connection failed after 3 retries, using in-memory fallback');
        return null;
      }
      return Math.min(times * 100, 3000);
    },
  });
} else {
  // Create a mock Redis client for when Redis is not available
  console.log('ℹ️  Redis URL not configured, using in-memory fallback');
  const memoryStore = new Map<string, string>();
  
  redisClient = {
    get: async (key: string) => memoryStore.get(key) || null,
    set: async (key: string, value: string) => { memoryStore.set(key, value); return 'OK'; },
    setex: async (key: string, seconds: number, value: string) => {
      memoryStore.set(key, value);
      setTimeout(() => memoryStore.delete(key), seconds * 1000);
      return 'OK';
    },
    del: async (...keys: string[]) => {
      keys.forEach(k => memoryStore.delete(k));
      return keys.length;
    },
    keys: async (pattern: string) => {
      const regex = new RegExp(pattern.replace('*', '.*'));
      return Array.from(memoryStore.keys()).filter(k => regex.test(k));
    },
    multi: () => ({
      incr: (key: string) => {
        const current = parseInt(memoryStore.get(key) || '0');
        memoryStore.set(key, String(current + 1));
        return { exec: async () => [[null, current + 1]] };
      },
      pexpire: () => ({ exec: async () => [[null, 1]] }),
      exec: async () => [[null, 1]],
    }),
    on: () => {},
    quit: async () => {},
    status: 'ready',
  } as any;
}

export const redis = redisClient;

// Redis client for rate limiting (Upstash compatible)
export const rateLimitRedis = env.UPSTASH_REDIS_REST_URL 
  ? new Redis(env.UPSTASH_REDIS_REST_URL, {
      token: env.UPSTASH_REDIS_REST_TOKEN,
      maxRetriesPerRequest: null,
      enableReadyCheck: false,
    })
  : redis;

// Event handlers (only for real Redis)
if (hasRedisUrl) {
  redis.on('connect', () => {
    console.log('✅ Redis connected successfully');
  });

  redis.on('error', (err) => {
    console.error('❌ Redis error:', err.message);
  });
}

// Cache helpers
export const cache = {
  async get<T>(key: string): Promise<T | null> {
    try {
      const value = await redis.get(key);
      return value ? JSON.parse(value) : null;
    } catch {
      return null;
    }
  },

  async set(key: string, value: unknown, ttlSeconds?: number): Promise<void> {
    try {
      const serialized = JSON.stringify(value);
      if (ttlSeconds) {
        await redis.setex(key, ttlSeconds, serialized);
      } else {
        await redis.set(key, serialized);
      }
    } catch (err) {
      console.warn('Cache set failed:', err);
    }
  },

  async delete(key: string): Promise<void> {
    try {
      await redis.del(key);
    } catch {}
  },

  async deletePattern(pattern: string): Promise<void> {
    try {
      const keys = await redis.keys(pattern);
      if (keys.length > 0) {
        await redis.del(...keys);
      }
    } catch {}
  },
};

// Rate limit helpers
export const rateLimit = {
  async increment(key: string, windowMs: number): Promise<{ count: number; resetTime: number }> {
    try {
      const multi = redis.multi();
      const now = Date.now();
      const windowStart = Math.floor(now / windowMs) * windowMs;
      const rateKey = `${key}:${windowStart}`;
      
      multi.incr(rateKey);
      multi.pexpire(rateKey, windowMs);
      
      const results = await multi.exec();
      const count = results?.[0]?.[1] as number || 1;
      
      return {
        count,
        resetTime: windowStart + windowMs,
      };
    } catch {
      // Fallback: allow the request
      return { count: 1, resetTime: Date.now() + windowMs };
    }
  },

  async reset(key: string): Promise<void> {
    try {
      const keys = await redis.keys(`${key}:*`);
      if (keys.length > 0) {
        await redis.del(...keys);
      }
    } catch {}
  },
};

export default redis;
