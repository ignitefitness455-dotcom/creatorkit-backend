import OpenAI from 'openai';
import { env, isOpenAIConfigured } from './env';

// Initialize OpenAI only if configured
export const openai = isOpenAIConfigured()
  ? new OpenAI({ apiKey: env.OPENAI_API_KEY })
  : null;

// Generate hashtags
export async function generateHashtags(
  content: string,
  platform: string,
  count: number = 15
): Promise<string[]> {
  if (!openai) {
    // Fallback mock response
    return [
      '#creatorhub',
      '#contentcreator',
      '#digitalcreator',
      '#creative',
      '#content',
      '#socialmedia',
      '#marketing',
      '#branding',
      '#growth',
      '#engagement',
    ].slice(0, count);
  }

  const prompt = `Generate ${count} relevant and trending hashtags for the following content on ${platform}:

Content: "${content}"

Requirements:
- Mix of popular and niche hashtags
- Include both broad and specific tags
- No spaces in hashtags
- Relevant to the content
- Format: just the hashtags, one per line`;

  const response = await openai.chat.completions.create({
    model: 'gpt-4',
    messages: [
      {
        role: 'system',
        content: 'You are a social media marketing expert. Generate engaging, relevant hashtags.',
      },
      { role: 'user', content: prompt },
    ],
    temperature: 0.7,
    max_tokens: 200,
  });

  const text = response.choices[0]?.message?.content || '';
  return text
    .split('\n')
    .map((tag) => tag.trim())
    .filter((tag) => tag.startsWith('#'));
}

// Generate caption
export async function generateCaption(
  content: string,
  platform: string,
  tone: string,
  length: 'short' | 'medium' | 'long'
): Promise<string> {
  if (!openai) {
    return `Check out this amazing content! 🚀\n\n${content}\n\nWhat do you think? Let me know in the comments! 👇`;
  }

  const lengthGuide = {
    short: '1-2 sentences, under 100 characters',
    medium: '3-5 sentences, around 200 characters',
    long: '5-8 sentences, detailed description',
  };

  const prompt = `Write an engaging ${platform} caption for the following content:

Content: "${content}"

Tone: ${tone}
Length: ${lengthGuide[length]}

Requirements:
- Include relevant emojis
- Add a call-to-action
- Engaging and authentic
- Platform-optimized`;

  const response = await openai.chat.completions.create({
    model: 'gpt-4',
    messages: [
      {
        role: 'system',
        content: 'You are a creative copywriter specializing in social media content.',
      },
      { role: 'user', content: prompt },
    ],
    temperature: 0.8,
    max_tokens: 300,
  });

  return response.choices[0]?.message?.content || '';
}

// Generate bio
export async function generateBio(
  niche: string,
  personality: string,
  platform: string
): Promise<string> {
  if (!openai) {
    return `✨ ${niche} enthusiast | Creating magic daily\n🎯 Helping you grow\n📩 DM for collabs`;
  }

  const prompt = `Write a catchy ${platform} bio for someone in the ${niche} niche with a ${personality} personality.

Requirements:
- Include relevant emojis
- Show personality
- Clear value proposition
- Call-to-action
- Under 150 characters for Instagram/Twitter`;

  const response = await openai.chat.completions.create({
    model: 'gpt-4',
    messages: [
      {
        role: 'system',
        content: 'You are a branding expert who writes compelling social media bios.',
      },
      { role: 'user', content: prompt },
    ],
    temperature: 0.8,
    max_tokens: 150,
  });

  return response.choices[0]?.message?.content || '';
}

// Generate content ideas
export async function generateContentIdeas(
  niche: string,
  count: number = 5
): Promise<Array<{ title: string; description: string }>> {
  if (!openai) {
    return [
      { title: 'Behind the Scenes', description: 'Show your creative process' },
      { title: 'Tips & Tricks', description: 'Share valuable insights' },
      { title: 'Day in the Life', description: 'A typical day in your world' },
      { title: 'Q&A Session', description: 'Answer follower questions' },
      { title: 'Tutorial', description: 'Teach something valuable' },
    ].slice(0, count);
  }

  const prompt = `Generate ${count} content ideas for a ${niche} creator.

Format as JSON array with "title" and "description" fields.
Make ideas specific, actionable, and engaging.`;

  const response = await openai.chat.completions.create({
    model: 'gpt-4',
    messages: [
      {
        role: 'system',
        content: 'You are a content strategist. Generate creative content ideas.',
      },
      { role: 'user', content: prompt },
    ],
    temperature: 0.8,
    max_tokens: 500,
    response_format: { type: 'json_object' },
  });

  try {
    const content = response.choices[0]?.message?.content || '{}';
    const parsed = JSON.parse(content);
    return parsed.ideas || [];
  } catch {
    return [];
  }
}

// Generate video script
export async function generateVideoScript(
  topic: string,
  duration: number,
  style: string
): Promise<{ hook: string; body: string[]; cta: string }> {
  if (!openai) {
    return {
      hook: `Ever wondered how to master ${topic}?`,
      body: ['Intro to the topic', 'Key points explained', 'Practical examples'],
      cta: 'Follow for more tips like this!',
    };
  }

  const prompt = `Write a ${duration}-second video script about "${topic}" in a ${style} style.

Format as JSON with:
- "hook": Attention-grabbing opening (under 5 seconds when read)
- "body": Array of 3-5 key points
- "cta": Strong call-to-action

Make it engaging and suitable for short-form video.`;

  const response = await openai.chat.completions.create({
    model: 'gpt-4',
    messages: [
      {
        role: 'system',
        content: 'You are a video scriptwriter specializing in viral short-form content.',
      },
      { role: 'user', content: prompt },
    ],
    temperature: 0.8,
    max_tokens: 500,
    response_format: { type: 'json_object' },
  });

  try {
    const content = response.choices[0]?.message?.content || '{}';
    return JSON.parse(content);
  } catch {
    return { hook: '', body: [], cta: '' };
  }
}

export default openai;
