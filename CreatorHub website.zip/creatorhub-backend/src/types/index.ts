// User types
export interface User {
  id: string;
  email: string;
  name: string | null;
  avatar: string | null;
  emailVerified: boolean;
  plan: Plan;
  createdAt: Date;
}

export interface UserWithSubscription extends User {
  subscription: Subscription | null;
  usage: Usage | null;
}

// Auth types
export interface Tokens {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
}

export interface JwtPayload {
  userId: string;
  email: string;
  plan: Plan;
  iat?: number;
  exp?: number;
}

// Subscription types
export interface Subscription {
  id: string;
  plan: Plan;
  status: SubscriptionStatus;
  currentPeriodStart: Date | null;
  currentPeriodEnd: Date | null;
  cancelAtPeriodEnd: boolean;
}

export interface Usage {
  pdfOperations: number;
  imageOperations: number;
  aiOperations: number;
  fileUploads: number;
  apiCalls: number;
  storageUsed: bigint;
  resetAt: Date;
}

// File types
export interface FileRecord {
  id: string;
  originalName: string;
  fileName: string;
  mimeType: string;
  size: bigint;
  s3Url: string;
  status: FileStatus;
  processedUrl: string | null;
  createdAt: Date;
}

// API Response types
export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  error?: string;
  message?: string;
  meta?: PaginationMeta;
}

export interface PaginationMeta {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
}

// Tool types
export interface Tool {
  id: string;
  name: string;
  description: string;
  category: ToolCategory;
  icon: string;
  color: string;
  isPremium: boolean;
  requiresAuth: boolean;
}

export type ToolCategory = 
  | 'PDF'
  | 'IMAGE'
  | 'SOCIAL'
  | 'BUSINESS';

// Job types
export interface JobData {
  userId?: string;
  fileIds?: string[];
  options?: Record<string, unknown>;
  [key: string]: unknown;
}

export interface JobResult {
  fileUrl?: string;
  fileName?: string;
  mimeType?: string;
  size?: number;
  metadata?: Record<string, unknown>;
}

// Payment types
export interface Payment {
  id: string;
  amount: number;
  currency: string;
  status: PaymentStatus;
  plan: Plan;
  description: string | null;
  receiptUrl: string | null;
  createdAt: Date;
}

// Plan limits
export interface PlanLimits {
  pdfOperations: number;
  imageOperations: number;
  aiOperations: number;
  storageGB: number;
  maxFileSizeMB: number;
  concurrentJobs: number;
}

// Enums
export enum Plan {
  FREE = 'FREE',
  BASIC = 'BASIC',
  PRO = 'PRO',
  ENTERPRISE = 'ENTERPRISE',
}

export enum SubscriptionStatus {
  INACTIVE = 'INACTIVE',
  ACTIVE = 'ACTIVE',
  PAST_DUE = 'PAST_DUE',
  CANCELED = 'CANCELED',
  UNPAID = 'UNPAID',
}

export enum FileStatus {
  PENDING = 'PENDING',
  PROCESSING = 'PROCESSING',
  COMPLETED = 'COMPLETED',
  FAILED = 'FAILED',
  EXPIRED = 'EXPIRED',
}

export enum PaymentStatus {
  PENDING = 'PENDING',
  COMPLETED = 'COMPLETED',
  FAILED = 'FAILED',
  REFUNDED = 'REFUNDED',
}

export enum JobType {
  PDF_MERGE = 'PDF_MERGE',
  PDF_SPLIT = 'PDF_SPLIT',
  PDF_COMPRESS = 'PDF_COMPRESS',
  PDF_CONVERT = 'PDF_CONVERT',
  PDF_ROTATE = 'PDF_ROTATE',
  PDF_ESIGN = 'PDF_ESIGN',
  IMAGE_COMPRESS = 'IMAGE_COMPRESS',
  IMAGE_REMOVE_BG = 'IMAGE_REMOVE_BG',
  IMAGE_UPSCALE = 'IMAGE_UPSCALE',
  IMAGE_CONVERT = 'IMAGE_CONVERT',
  AI_GENERATE = 'AI_GENERATE',
  FILE_PROCESS = 'FILE_PROCESS',
}

export enum JobStatus {
  PENDING = 'PENDING',
  PROCESSING = 'PROCESSING',
  COMPLETED = 'COMPLETED',
  FAILED = 'FAILED',
  CANCELLED = 'CANCELLED',
}

// Request body types
export interface RegisterBody {
  email: string;
  password: string;
  name?: string;
}

export interface LoginBody {
  email: string;
  password: string;
}

export interface ProcessPdfBody {
  fileIds: string[];
  operation: string;
  options?: Record<string, unknown>;
}

export interface ProcessImageBody {
  fileId: string;
  operation: string;
  options?: Record<string, unknown>;
}

export interface GenerateAiBody {
  type: 'hashtags' | 'caption' | 'bio' | 'content-ideas' | 'script';
  content: string;
  options?: Record<string, unknown>;
}

// Webhook types
export interface StripeWebhookEvent {
  id: string;
  type: string;
  data: {
    object: Record<string, unknown>;
  };
}

// Middleware types
export interface AuthenticatedRequest extends Request {
  user?: JwtPayload;
}
