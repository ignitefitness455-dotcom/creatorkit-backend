import express, { Router } from 'express';
import paymentController from '../controllers/paymentController';
import { authenticate } from '../middleware/auth';

const router = Router();

// Public routes
router.get('/plans', paymentController.getPlans);

// Stripe webhook (raw body needed) - placed before express.json middleware
// This route should be registered in server.ts before body parsers
router.post('/webhook', paymentController.stripeWebhook);

// Protected routes
router.use(authenticate);

router.post('/checkout', paymentController.createCheckout);
router.post('/portal', paymentController.createPortal);
router.get('/subscription', paymentController.getSubscription);
router.post('/subscription/cancel', paymentController.cancelSubscription);
router.post('/subscription/resume', paymentController.resumeSubscription);
router.get('/history', paymentController.getPaymentHistory);

export default router;
