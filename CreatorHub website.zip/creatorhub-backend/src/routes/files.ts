import { Router } from 'express';
import fileController from '../controllers/fileController';
import { authenticate, optionalAuth } from '../middleware/auth';
import { rateLimitUpload } from '../middleware/rateLimit';
import { upload, cleanupUploads, addFileMetadata } from '../middleware/upload';
import { s3Client } from '../config/s3';
import fs from 'fs/promises';
import path from 'path';

const router = Router();

// All routes require authentication
router.use(authenticate);

// Generate presigned upload URL
router.post('/upload-url', rateLimitUpload, fileController.generateUploadUrl);

// Confirm upload completion
router.post('/confirm-upload', fileController.confirmUpload);

// Direct file upload
router.post(
  '/upload',
  rateLimitUpload,
  upload.single('file'),
  addFileMetadata,
  cleanupUploads,
  fileController.uploadFile
);

// Get user's files
router.get('/', fileController.getFiles);

// Get storage info
router.get('/storage/info', fileController.getStorageInfo);

// Get file by ID
router.get('/:id', fileController.getFile);

// Download file
router.get('/:id/download', fileController.downloadFile);

// Local file download endpoint (when S3 not configured)
router.get('/local-download/:filename', optionalAuth, async (req, res, next) => {
  try {
    const { filename } = req.params;
    const localStoragePath = path.join(process.cwd(), 'uploads', 'files');
    const filePath = path.join(localStoragePath, filename);
    
    // Security check - prevent directory traversal
    if (!filePath.startsWith(localStoragePath)) {
      return res.status(403).json({ error: 'Access denied' });
    }
    
    // Check if file exists
    try {
      await fs.access(filePath);
    } catch {
      return res.status(404).json({ error: 'File not found' });
    }
    
    // Send file
    res.sendFile(filePath);
  } catch (error) {
    next(error);
  }
});

// Local file upload endpoint (when S3 not configured)
router.post('/local-upload/:key', optionalAuth, upload.single('file'), async (req, res, next) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }
    
    res.json({
      success: true,
      message: 'File uploaded successfully',
      fileName: req.file.filename,
    });
  } catch (error) {
    next(error);
  }
});

// Delete file
router.delete('/:id', fileController.deleteFile);

export default router;
