import { Router } from 'express';
import authController from '../controllers/authController';
import { authenticate, refreshAccessToken, logout } from '../middleware/auth';
import { validators, validate } from '../middleware/validate';
import { rateLimitAuth } from '../middleware/rateLimit';

const router = Router();

// Public routes
router.post(
  '/register',
  rateLimitAuth,
  validate(validators.register),
  authController.register
);

router.post(
  '/login',
  rateLimitAuth,
  validate(validators.login),
  authController.login
);

router.get('/verify-email', authController.verifyEmail);

router.post(
  '/resend-verification',
  rateLimitAuth,
  validate(validators.forgotPassword),
  authController.resendVerification
);

router.post(
  '/forgot-password',
  rateLimitAuth,
  validate(validators.forgotPassword),
  authController.forgotPassword
);

router.post(
  '/reset-password',
  rateLimitAuth,
  validate(validators.resetPassword),
  authController.resetPassword
);

router.post('/refresh-token', refreshAccessToken);

router.post('/oauth/callback', authController.oauthCallback);

// Protected routes
router.use(authenticate);

router.post(
  '/change-password',
  validate(validators.changePassword),
  authController.changePassword
);

router.get('/me', authController.getCurrentUser);

router.patch('/profile', authController.updateProfile);

router.post('/logout', logout);

export default router;
