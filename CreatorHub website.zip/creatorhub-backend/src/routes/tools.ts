import { Router } from 'express';
import toolsController from '../controllers/toolsController';
import { authenticate, optionalAuth } from '../middleware/auth';
import { validators, validate } from '../middleware/validate';
import { rateLimitAI, rateLimitByPlan } from '../middleware/rateLimit';

const router = Router();

// PDF Tools (require auth)
router.use('/pdf', authenticate);
router.post('/pdf/merge', validate(validators.pdfMerge), toolsController.mergePDFs);
router.post('/pdf/split', validate(validators.pdfSplit), toolsController.splitPDF);
router.post('/pdf/compress', toolsController.compressPDF);
router.post('/pdf/convert-to-images', toolsController.convertPDFToImages);
router.post('/pdf/rotate', toolsController.rotatePDF);

// Image Tools (require auth)
router.use('/image', authenticate);
router.post('/image/compress', toolsController.compressImage);
router.post('/image/upscale', toolsController.upscaleImage);
router.post('/image/convert', toolsController.convertImage);
router.post('/image/remove-background', toolsController.removeBackground);
router.post('/image/extract-colors', toolsController.extractColors);

// AI Tools (require auth + rate limiting)
router.use('/ai', authenticate, rateLimitAI);
router.post(
  '/ai/hashtags',
  validate(validators.generateHashtags),
  toolsController.generateHashtags
);
router.post(
  '/ai/caption',
  validate(validators.generateCaption),
  toolsController.generateCaption
);
router.post('/ai/bio', validate(validators.generateBio), toolsController.generateBio);
router.post('/ai/content-ideas', toolsController.generateContentIdeas);
router.post('/ai/video-script', toolsController.generateVideoScript);

// Business Tools (some require auth)
router.post('/business/qr-code', toolsController.generateQRCode);
router.post(
  '/business/invoice',
  authenticate,
  validate(validators.generateInvoice),
  toolsController.generateInvoice
);
router.post('/business/emi', validate(validators.calculateEMI), toolsController.calculateEMI);
router.post('/business/password', toolsController.generatePassword);

// Job status (require auth)
router.get('/jobs/:jobId', authenticate, toolsController.getJobStatus);

// Usage stats (require auth)
router.get('/usage/stats', authenticate, toolsController.getUsageStats);

export default router;
