// Custom error classes
export class AppError extends Error {
  public statusCode: number;
  public isOperational: boolean;
  public code: string;

  constructor(
    message: string,
    statusCode: number = 500,
    code: string = 'INTERNAL_ERROR',
    isOperational: boolean = true
  ) {
    super(message);
    this.statusCode = statusCode;
    this.code = code;
    this.isOperational = isOperational;

    Error.captureStackTrace(this, this.constructor);
  }
}

export class BadRequestError extends AppError {
  constructor(message: string = 'Bad Request', code: string = 'BAD_REQUEST') {
    super(message, 400, code);
  }
}

export class UnauthorizedError extends AppError {
  constructor(message: string = 'Unauthorized', code: string = 'UNAUTHORIZED') {
    super(message, 401, code);
  }
}

export class ForbiddenError extends AppError {
  constructor(message: string = 'Forbidden', code: string = 'FORBIDDEN') {
    super(message, 403, code);
  }
}

export class NotFoundError extends AppError {
  constructor(message: string = 'Not Found', code: string = 'NOT_FOUND') {
    super(message, 404, code);
  }
}

export class ConflictError extends AppError {
  constructor(message: string = 'Conflict', code: string = 'CONFLICT') {
    super(message, 409, code);
  }
}

export class ValidationError extends AppError {
  public errors: Array<{ field: string; message: string }>;

  constructor(
    errors: Array<{ field: string; message: string }>,
    message: string = 'Validation Error'
  ) {
    super(message, 422, 'VALIDATION_ERROR');
    this.errors = errors;
  }
}

export class RateLimitError extends AppError {
  public retryAfter: number;

  constructor(message: string = 'Too Many Requests', retryAfter: number = 60) {
    super(message, 429, 'RATE_LIMIT_EXCEEDED');
    this.retryAfter = retryAfter;
  }
}

export class ServiceUnavailableError extends AppError {
  constructor(message: string = 'Service Unavailable', code: string = 'SERVICE_UNAVAILABLE') {
    super(message, 503, code);
  }
}

// Error codes
export const ErrorCodes = {
  // Auth errors
  INVALID_CREDENTIALS: 'INVALID_CREDENTIALS',
  TOKEN_EXPIRED: 'TOKEN_EXPIRED',
  TOKEN_INVALID: 'TOKEN_INVALID',
  EMAIL_NOT_VERIFIED: 'EMAIL_NOT_VERIFIED',
  EMAIL_ALREADY_EXISTS: 'EMAIL_ALREADY_EXISTS',
  USER_NOT_FOUND: 'USER_NOT_FOUND',
  INVALID_PASSWORD: 'INVALID_PASSWORD',
  PASSWORD_TOO_WEAK: 'PASSWORD_TOO_WEAK',
  OAUTH_ERROR: 'OAUTH_ERROR',

  // File errors
  FILE_TOO_LARGE: 'FILE_TOO_LARGE',
  INVALID_FILE_TYPE: 'INVALID_FILE_TYPE',
  FILE_NOT_FOUND: 'FILE_NOT_FOUND',
  UPLOAD_FAILED: 'UPLOAD_FAILED',
  PROCESSING_FAILED: 'PROCESSING_FAILED',
  STORAGE_FULL: 'STORAGE_FULL',

  // Subscription errors
  SUBSCRIPTION_REQUIRED: 'SUBSCRIPTION_REQUIRED',
  PLAN_LIMIT_EXCEEDED: 'PLAN_LIMIT_EXCEEDED',
  PAYMENT_FAILED: 'PAYMENT_FAILED',
  SUBSCRIPTION_EXPIRED: 'SUBSCRIPTION_EXPIRED',

  // API errors
  RATE_LIMIT_EXCEEDED: 'RATE_LIMIT_EXCEEDED',
  API_ERROR: 'API_ERROR',
  SERVICE_UNAVAILABLE: 'SERVICE_UNAVAILABLE',

  // Validation errors
  VALIDATION_ERROR: 'VALIDATION_ERROR',
  MISSING_REQUIRED_FIELD: 'MISSING_REQUIRED_FIELD',
  INVALID_FORMAT: 'INVALID_FORMAT',
} as const;

// Error messages
export const ErrorMessages: Record<string, string> = {
  [ErrorCodes.INVALID_CREDENTIALS]: 'Invalid email or password',
  [ErrorCodes.TOKEN_EXPIRED]: 'Your session has expired. Please login again',
  [ErrorCodes.TOKEN_INVALID]: 'Invalid authentication token',
  [ErrorCodes.EMAIL_NOT_VERIFIED]: 'Please verify your email address',
  [ErrorCodes.EMAIL_ALREADY_EXISTS]: 'An account with this email already exists',
  [ErrorCodes.USER_NOT_FOUND]: 'User not found',
  [ErrorCodes.INVALID_PASSWORD]: 'Invalid password',
  [ErrorCodes.PASSWORD_TOO_WEAK]: 'Password is too weak',
  [ErrorCodes.OAUTH_ERROR]: 'OAuth authentication failed',

  [ErrorCodes.FILE_TOO_LARGE]: 'File size exceeds the limit',
  [ErrorCodes.INVALID_FILE_TYPE]: 'Invalid file type',
  [ErrorCodes.FILE_NOT_FOUND]: 'File not found',
  [ErrorCodes.UPLOAD_FAILED]: 'File upload failed',
  [ErrorCodes.PROCESSING_FAILED]: 'File processing failed',
  [ErrorCodes.STORAGE_FULL]: 'Storage limit exceeded',

  [ErrorCodes.SUBSCRIPTION_REQUIRED]: 'Active subscription required',
  [ErrorCodes.PLAN_LIMIT_EXCEEDED]: 'You have reached your plan limit',
  [ErrorCodes.PAYMENT_FAILED]: 'Payment processing failed',
  [ErrorCodes.SUBSCRIPTION_EXPIRED]: 'Your subscription has expired',

  [ErrorCodes.RATE_LIMIT_EXCEEDED]: 'Too many requests. Please try again later',
  [ErrorCodes.API_ERROR]: 'API request failed',
  [ErrorCodes.SERVICE_UNAVAILABLE]: 'Service temporarily unavailable',

  [ErrorCodes.VALIDATION_ERROR]: 'Validation failed',
  [ErrorCodes.MISSING_REQUIRED_FIELD]: 'Required field is missing',
  [ErrorCodes.INVALID_FORMAT]: 'Invalid data format',
};

// Get error message
export function getErrorMessage(code: string): string {
  return ErrorMessages[code] || 'An unexpected error occurred';
}

// Handle Prisma errors
export function handlePrismaError(error: any): AppError {
  const code = error?.code;
  const meta = error?.meta;

  switch (code) {
    case 'P2002':
      const field = meta?.target?.[0] || 'field';
      return new ConflictError(
        `A record with this ${field} already exists`,
        'UNIQUE_CONSTRAINT_VIOLATION'
      );
    case 'P2025':
      return new NotFoundError('Record not found', 'RECORD_NOT_FOUND');
    case 'P2003':
      return new BadRequestError(
        'Foreign key constraint failed',
        'FOREIGN_KEY_CONSTRAINT'
      );
    default:
      return new AppError(
        'Database error occurred',
        500,
        'DATABASE_ERROR',
        false
      );
  }
}

// Handle JWT errors
export function handleJWTError(error: any): AppError {
  if (error.name === 'TokenExpiredError') {
    return new UnauthorizedError(
      'Your session has expired',
      ErrorCodes.TOKEN_EXPIRED
    );
  }
  if (error.name === 'JsonWebTokenError') {
    return new UnauthorizedError(
      'Invalid authentication token',
      ErrorCodes.TOKEN_INVALID
    );
  }
  return new UnauthorizedError('Authentication failed', 'AUTH_FAILED');
}
