import { Plan, PlanLimits } from '../types';

// Plan limits configuration
export const PLAN_LIMITS: Record<Plan, PlanLimits> = {
  [Plan.FREE]: {
    pdfOperations: 5,
    imageOperations: 10,
    aiOperations: 3,
    storageGB: 0.5,
    maxFileSizeMB: 10,
    concurrentJobs: 1,
  },
  [Plan.BASIC]: {
    pdfOperations: 50,
    imageOperations: 100,
    aiOperations: 25,
    storageGB: 5,
    maxFileSizeMB: 50,
    concurrentJobs: 2,
  },
  [Plan.PRO]: {
    pdfOperations: 500,
    imageOperations: 1000,
    aiOperations: 200,
    storageGB: 50,
    maxFileSizeMB: 100,
    concurrentJobs: 5,
  },
  [Plan.ENTERPRISE]: {
    pdfOperations: -1, // Unlimited
    imageOperations: -1,
    aiOperations: -1,
    storageGB: 500,
    maxFileSizeMB: 500,
    concurrentJobs: 10,
  },
};

// Check if operation is allowed
export function isOperationAllowed(
  plan: Plan,
  operationType: keyof PlanLimits,
  currentUsage: number
): boolean {
  const limit = PLAN_LIMITS[plan][operationType];
  
  // -1 means unlimited
  if (limit === -1) return true;
  
  return currentUsage < limit;
}

// Get remaining operations
export function getRemainingOperations(
  plan: Plan,
  operationType: keyof PlanLimits,
  currentUsage: number
): number {
  const limit = PLAN_LIMITS[plan][operationType];
  
  // -1 means unlimited
  if (limit === -1) return -1;
  
  return Math.max(0, limit - currentUsage);
}

// Get max file size in bytes
export function getMaxFileSize(plan: Plan): number {
  return PLAN_LIMITS[plan].maxFileSizeMB * 1024 * 1024;
}

// Get storage limit in bytes
export function getStorageLimit(plan: Plan): number {
  return PLAN_LIMITS[plan].storageGB * 1024 * 1024 * 1024;
}

// Check if storage is available
export function isStorageAvailable(
  plan: Plan,
  currentStorage: bigint,
  newFileSize: number
): boolean {
  const limit = getStorageLimit(plan);
  if (limit === -1) return true;
  
  return Number(currentStorage) + newFileSize <= limit;
}

// Get plan features
export function getPlanFeatures(plan: Plan): string[] {
  const features: Record<Plan, string[]> = {
    [Plan.FREE]: [
      '5 PDF operations/month',
      '10 Image operations/month',
      '3 AI generations/month',
      '500MB storage',
      '10MB max file size',
      'Basic support',
    ],
    [Plan.BASIC]: [
      '50 PDF operations/month',
      '100 Image operations/month',
      '25 AI generations/month',
      '5GB storage',
      '50MB max file size',
      'Priority support',
      'No ads',
    ],
    [Plan.PRO]: [
      '500 PDF operations/month',
      '1000 Image operations/month',
      '200 AI generations/month',
      '50GB storage',
      '100MB max file size',
      'Priority support',
      'No ads',
      'API access',
      'Batch processing',
    ],
    [Plan.ENTERPRISE]: [
      'Unlimited PDF operations',
      'Unlimited Image operations',
      'Unlimited AI generations',
      '500GB storage',
      '500MB max file size',
      '24/7 dedicated support',
      'No ads',
      'Full API access',
      'Batch processing',
      'Custom integrations',
      'SLA guarantee',
    ],
  };

  return features[plan];
}

// Get plan price
export function getPlanPrice(plan: Plan): { monthly: number; yearly: number } {
  const prices: Record<Plan, { monthly: number; yearly: number }> = {
    [Plan.FREE]: { monthly: 0, yearly: 0 },
    [Plan.BASIC]: { monthly: 9.99, yearly: 99.99 },
    [Plan.PRO]: { monthly: 29.99, yearly: 299.99 },
    [Plan.ENTERPRISE]: { monthly: 99.99, yearly: 999.99 },
  };

  return prices[plan];
}

// Get plan display name
export function getPlanDisplayName(plan: Plan): string {
  const names: Record<Plan, string> = {
    [Plan.FREE]: 'Free',
    [Plan.BASIC]: 'Basic',
    [Plan.PRO]: 'Pro',
    [Plan.ENTERPRISE]: 'Enterprise',
  };

  return names[plan];
}

// Check if plan upgrade is needed
export function isUpgradeNeeded(
  currentPlan: Plan,
  requiredPlan: Plan
): boolean {
  const planHierarchy: Record<Plan, number> = {
    [Plan.FREE]: 0,
    [Plan.BASIC]: 1,
    [Plan.PRO]: 2,
    [Plan.ENTERPRISE]: 3,
  };

  return planHierarchy[currentPlan] < planHierarchy[requiredPlan];
}

// Get recommended plan based on usage
export function getRecommendedPlan(
  pdfOperations: number,
  imageOperations: number,
  aiOperations: number,
  storageGB: number
): Plan {
  if (
    pdfOperations > PLAN_LIMITS[Plan.PRO].pdfOperations ||
    imageOperations > PLAN_LIMITS[Plan.PRO].imageOperations ||
    aiOperations > PLAN_LIMITS[Plan.PRO].aiOperations ||
    storageGB > PLAN_LIMITS[Plan.PRO].storageGB
  ) {
    return Plan.ENTERPRISE;
  }

  if (
    pdfOperations > PLAN_LIMITS[Plan.BASIC].pdfOperations ||
    imageOperations > PLAN_LIMITS[Plan.BASIC].imageOperations ||
    aiOperations > PLAN_LIMITS[Plan.BASIC].aiOperations ||
    storageGB > PLAN_LIMITS[Plan.BASIC].storageGB
  ) {
    return Plan.PRO;
  }

  if (
    pdfOperations > PLAN_LIMITS[Plan.FREE].pdfOperations ||
    imageOperations > PLAN_LIMITS[Plan.FREE].imageOperations ||
    aiOperations > PLAN_LIMITS[Plan.FREE].aiOperations ||
    storageGB > PLAN_LIMITS[Plan.FREE].storageGB
  ) {
    return Plan.BASIC;
  }

  return Plan.FREE;
}

export default PLAN_LIMITS;
