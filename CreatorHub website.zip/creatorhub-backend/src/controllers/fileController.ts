import { Request, Response, NextFunction } from 'express';
import { prisma } from '../config/database';
import { generateUploadUrl, generateDownloadUrl, generateS3Key, deleteObject, saveFileLocally, s3Client } from '../config/s3';
import { BadRequestError, NotFoundError, ForbiddenError } from '../utils/errors';
import { isStorageAvailable, getStorageLimit } from '../utils/planLimits';
import { Plan, FileStatus } from '../types';
import fs from 'fs/promises';
import path from 'path';

// Generate upload URL
export async function generateUploadUrlHandler(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { fileName, mimeType, size } = req.body;
    const userId = req.user!.userId;
    const userPlan = req.user!.plan || Plan.FREE;

    // Check storage limit
    const usage = await prisma.usage.findUnique({
      where: { userId },
    });

    if (!isStorageAvailable(userPlan, usage?.storageUsed || BigInt(0), size)) {
      throw new ForbiddenError(
        'Storage limit exceeded. Please upgrade your plan.',
        'STORAGE_FULL'
      );
    }

    // Generate S3 key
    const s3Key = generateS3Key(userId, fileName);

    // Generate presigned URL
    const uploadUrl = await generateUploadUrl(s3Key, mimeType, 300);

    // Create file record
    const file = await prisma.file.create({
      data: {
        userId,
        originalName: fileName,
        fileName: path.basename(s3Key),
        mimeType,
        size: BigInt(size),
        s3Key,
        s3Url: '', // Will be updated after upload
        status: FileStatus.PENDING,
      },
    });

    res.json({
      success: true,
      data: {
        fileId: file.id,
        uploadUrl,
        s3Key,
        expiresIn: 300,
      },
    });
  } catch (error) {
    next(error);
  }
}

// Confirm file upload
export async function confirmUpload(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { fileId } = req.body;
    const userId = req.user!.userId;

    const file = await prisma.file.findFirst({
      where: {
        id: fileId,
        userId,
      },
    });

    if (!file) {
      throw new NotFoundError('File not found');
    }

    // Update file status
    const updatedFile = await prisma.file.update({
      where: { id: fileId },
      data: {
        status: FileStatus.COMPLETED,
        s3Url: await generateDownloadUrl(file.s3Key, 3600),
      },
    });

    // Update storage usage
    await prisma.usage.update({
      where: { userId },
      data: {
        storageUsed: {
          increment: file.size,
        },
        fileUploads: {
          increment: 1,
        },
      },
    });

    res.json({
      success: true,
      data: {
        file: {
          id: updatedFile.id,
          originalName: updatedFile.originalName,
          size: Number(updatedFile.size),
          mimeType: updatedFile.mimeType,
          status: updatedFile.status,
          downloadUrl: updatedFile.s3Url,
          createdAt: updatedFile.createdAt,
        },
      },
    });
  } catch (error) {
    next(error);
  }
}

// Upload file directly
export async function uploadFile(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    if (!req.file) {
      throw new BadRequestError('No file uploaded');
    }

    const userId = req.user!.userId;
    const userPlan = req.user!.plan || Plan.FREE;
    const fileSize = req.file.size;

    // Check storage limit
    const usage = await prisma.usage.findUnique({
      where: { userId },
    });

    if (!isStorageAvailable(userPlan, usage?.storageUsed || BigInt(0), fileSize)) {
      // Cleanup uploaded file
      await fs.unlink(req.file.path);
      throw new ForbiddenError(
        'Storage limit exceeded. Please upgrade your plan.',
        'STORAGE_FULL'
      );
    }

    let filePath = req.file.path;
    let downloadUrl: string;

    // If S3 not configured, save to local storage
    if (!s3Client) {
      const fileBuffer = await fs.readFile(req.file.path);
      const { filePath: localPath, url } = await saveFileLocally(fileBuffer, req.file.filename);
      downloadUrl = url;
      // Clean up temp file
      await fs.unlink(req.file.path).catch(() => {});
      filePath = localPath;
    } else {
      downloadUrl = `${process.env.API_URL}/api/files/download/${req.file.filename}`;
    }

    // Create file record
    const file = await prisma.file.create({
      data: {
        userId,
        originalName: req.file.originalname,
        fileName: req.file.filename,
        mimeType: req.file.mimetype,
        size: BigInt(fileSize),
        s3Key: filePath,
        s3Url: downloadUrl,
        status: FileStatus.COMPLETED,
      },
    });

    // Update storage usage
    await prisma.usage.update({
      where: { userId },
      data: {
        storageUsed: {
          increment: BigInt(fileSize),
        },
        fileUploads: {
          increment: 1,
        },
      },
    });

    res.json({
      success: true,
      data: {
        file: {
          id: file.id,
          originalName: file.originalName,
          size: Number(file.size),
          mimeType: file.mimeType,
          status: file.status,
          downloadUrl: file.s3Url,
          createdAt: file.createdAt,
        },
      },
    });
  } catch (error) {
    next(error);
  }
}

// Get user's files
export async function getFiles(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const userId = req.user!.userId;
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 20;
    const skip = (page - 1) * limit;

    const [files, total] = await Promise.all([
      prisma.file.findMany({
        where: {
          userId,
          status: {
            not: FileStatus.EXPIRED,
          },
        },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
        select: {
          id: true,
          originalName: true,
          size: true,
          mimeType: true,
          status: true,
          s3Url: true,
          createdAt: true,
        },
      }),
      prisma.file.count({
        where: {
          userId,
          status: {
            not: FileStatus.EXPIRED,
          },
        },
      }),
    ]);

    // Refresh download URLs
    const filesWithUrls = await Promise.all(
      files.map(async (file) => ({
        ...file,
        size: Number(file.size),
        downloadUrl: file.s3Url
          ? await generateDownloadUrl(
              (await prisma.file.findUnique({ where: { id: file.id } }))?.s3Key || '',
              3600
            )
          : null,
      }))
    );

    res.json({
      success: true,
      data: filesWithUrls,
      meta: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    next(error);
  }
}

// Get file by ID
export async function getFile(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { id } = req.params;
    const userId = req.user!.userId;

    const file = await prisma.file.findFirst({
      where: {
        id,
        userId,
      },
    });

    if (!file) {
      throw new NotFoundError('File not found');
    }

    // Generate fresh download URL
    const downloadUrl = await generateDownloadUrl(file.s3Key, 3600);

    res.json({
      success: true,
      data: {
        id: file.id,
        originalName: file.originalName,
        size: Number(file.size),
        mimeType: file.mimeType,
        status: file.status,
        downloadUrl,
        createdAt: file.createdAt,
      },
    });
  } catch (error) {
    next(error);
  }
}

// Delete file
export async function deleteFile(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { id } = req.params;
    const userId = req.user!.userId;

    const file = await prisma.file.findFirst({
      where: {
        id,
        userId,
      },
    });

    if (!file) {
      throw new NotFoundError('File not found');
    }

    // Delete from S3
    try {
      await deleteObject(file.s3Key);
    } catch (err) {
      console.error('Failed to delete from S3:', err);
    }

    // Delete from database
    await prisma.file.delete({
      where: { id },
    });

    // Update storage usage
    await prisma.usage.update({
      where: { userId },
      data: {
        storageUsed: {
          decrement: file.size,
        },
      },
    });

    res.json({
      success: true,
      message: 'File deleted successfully',
    });
  } catch (error) {
    next(error);
  }
}

// Get storage info
export async function getStorageInfo(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const userId = req.user!.userId;
    const userPlan = req.user!.plan || Plan.FREE;

    const usage = await prisma.usage.findUnique({
      where: { userId },
    });

    const limit = getStorageLimit(userPlan);
    const used = Number(usage?.storageUsed || 0);

    res.json({
      success: true,
      data: {
        used,
        limit,
        available: limit - used,
        percentage: Math.round((used / limit) * 100),
        unit: 'bytes',
      },
    });
  } catch (error) {
    next(error);
  }
}

// Download file
export async function downloadFile(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { id } = req.params;
    const userId = req.user?.userId;

    const file = await prisma.file.findFirst({
      where: {
        id,
        ...(userId ? { userId } : {}),
      },
    });

    if (!file) {
      throw new NotFoundError('File not found');
    }

    // Generate download URL
    const downloadUrl = await generateDownloadUrl(file.s3Key, 300);

    res.json({
      success: true,
      data: {
        downloadUrl,
        fileName: file.originalName,
        expiresIn: 300,
      },
    });
  } catch (error) {
    next(error);
  }
}

export default {
  generateUploadUrl: generateUploadUrlHandler,
  confirmUpload,
  uploadFile,
  getFiles,
  getFile,
  deleteFile,
  getStorageInfo,
  downloadFile,
};
