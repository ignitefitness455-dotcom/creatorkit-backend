import { Request, Response, NextFunction } from 'express';
import { prisma } from '../config/database';
import pdfService from '../services/pdfService';
import imageService from '../services/imageService';
import aiService from '../services/aiService';
import businessService from '../services/businessService';
import { addJob, fileProcessingQueue } from '../services/queueService';
import { BadRequestError, NotFoundError, ForbiddenError } from '../utils/errors';
import { isOperationAllowed, getRemainingOperations } from '../utils/planLimits';
import { Plan, JobType, JobStatus } from '../types';
import fs from 'fs/promises';

// PDF Tools

// Merge PDFs
export async function mergePDFs(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { fileIds } = req.body;
    const userId = req.user!.userId;
    const userPlan = req.user!.plan || Plan.FREE;

    // Check operation limit
    const usage = await prisma.usage.findUnique({
      where: { userId },
    });

    if (!isOperationAllowed(userPlan, 'pdfOperations', usage?.pdfOperations || 0)) {
      throw new ForbiddenError(
        'PDF operation limit exceeded. Please upgrade your plan.',
        'PLAN_LIMIT_EXCEEDED'
      );
    }

    // Get files
    const files = await prisma.file.findMany({
      where: {
        id: { in: fileIds },
        userId,
      },
    });

    if (files.length !== fileIds.length) {
      throw new NotFoundError('One or more files not found');
    }

    // Add to queue
    const job = await addJob(fileProcessingQueue, JobType.PDF_MERGE, {
      filePaths: files.map((f) => f.s3Key),
      userId,
    });

    res.json({
      success: true,
      data: {
        jobId: job.id,
        status: JobStatus.PENDING,
      },
    });
  } catch (error) {
    next(error);
  }
}

// Split PDF
export async function splitPDF(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { fileId, pages } = req.body;
    const userId = req.user!.userId;
    const userPlan = req.user!.plan || Plan.FREE;

    // Check operation limit
    const usage = await prisma.usage.findUnique({
      where: { userId },
    });

    if (!isOperationAllowed(userPlan, 'pdfOperations', usage?.pdfOperations || 0)) {
      throw new ForbiddenError(
        'PDF operation limit exceeded. Please upgrade your plan.',
        'PLAN_LIMIT_EXCEEDED'
      );
    }

    // Get file
    const file = await prisma.file.findFirst({
      where: { id: fileId, userId },
    });

    if (!file) {
      throw new NotFoundError('File not found');
    }

    // Add to queue
    const job = await addJob(fileProcessingQueue, JobType.PDF_SPLIT, {
      filePath: file.s3Key,
      pages,
      userId,
    });

    res.json({
      success: true,
      data: {
        jobId: job.id,
        status: JobStatus.PENDING,
      },
    });
  } catch (error) {
    next(error);
  }
}

// Compress PDF
export async function compressPDF(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { fileId, quality = 'medium' } = req.body;
    const userId = req.user!.userId;
    const userPlan = req.user!.plan || Plan.FREE;

    // Check operation limit
    const usage = await prisma.usage.findUnique({
      where: { userId },
    });

    if (!isOperationAllowed(userPlan, 'pdfOperations', usage?.pdfOperations || 0)) {
      throw new ForbiddenError(
        'PDF operation limit exceeded. Please upgrade your plan.',
        'PLAN_LIMIT_EXCEEDED'
      );
    }

    // Get file
    const file = await prisma.file.findFirst({
      where: { id: fileId, userId },
    });

    if (!file) {
      throw new NotFoundError('File not found');
    }

    // Add to queue
    const job = await addJob(fileProcessingQueue, JobType.PDF_COMPRESS, {
      filePath: file.s3Key,
      quality,
      userId,
    });

    res.json({
      success: true,
      data: {
        jobId: job.id,
        status: JobStatus.PENDING,
      },
    });
  } catch (error) {
    next(error);
  }
}

// Convert PDF to images
export async function convertPDFToImages(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { fileId, format = 'png' } = req.body;
    const userId = req.user!.userId;
    const userPlan = req.user!.plan || Plan.FREE;

    // Check operation limit
    const usage = await prisma.usage.findUnique({
      where: { userId },
    });

    if (!isOperationAllowed(userPlan, 'pdfOperations', usage?.pdfOperations || 0)) {
      throw new ForbiddenError(
        'PDF operation limit exceeded. Please upgrade your plan.',
        'PLAN_LIMIT_EXCEEDED'
      );
    }

    // Get file
    const file = await prisma.file.findFirst({
      where: { id: fileId, userId },
    });

    if (!file) {
      throw new NotFoundError('File not found');
    }

    // Add to queue
    const job = await addJob(fileProcessingQueue, JobType.PDF_CONVERT, {
      filePath: file.s3Key,
      format,
      userId,
    });

    res.json({
      success: true,
      data: {
        jobId: job.id,
        status: JobStatus.PENDING,
      },
    });
  } catch (error) {
    next(error);
  }
}

// Rotate PDF
export async function rotatePDF(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { fileId, rotation, pages } = req.body;
    const userId = req.user!.userId;
    const userPlan = req.user!.plan || Plan.FREE;

    // Check operation limit
    const usage = await prisma.usage.findUnique({
      where: { userId },
    });

    if (!isOperationAllowed(userPlan, 'pdfOperations', usage?.pdfOperations || 0)) {
      throw new ForbiddenError(
        'PDF operation limit exceeded. Please upgrade your plan.',
        'PLAN_LIMIT_EXCEEDED'
      );
    }

    // Get file
    const file = await prisma.file.findFirst({
      where: { id: fileId, userId },
    });

    if (!file) {
      throw new NotFoundError('File not found');
    }

    // Add to queue
    const job = await addJob(fileProcessingQueue, JobType.PDF_ROTATE, {
      filePath: file.s3Key,
      rotation,
      pages,
      userId,
    });

    res.json({
      success: true,
      data: {
        jobId: job.id,
        status: JobStatus.PENDING,
      },
    });
  } catch (error) {
    next(error);
  }
}

// Image Tools

// Compress image
export async function compressImage(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { fileId, quality = 80 } = req.body;
    const userId = req.user!.userId;
    const userPlan = req.user!.plan || Plan.FREE;

    // Check operation limit
    const usage = await prisma.usage.findUnique({
      where: { userId },
    });

    if (!isOperationAllowed(userPlan, 'imageOperations', usage?.imageOperations || 0)) {
      throw new ForbiddenError(
        'Image operation limit exceeded. Please upgrade your plan.',
        'PLAN_LIMIT_EXCEEDED'
      );
    }

    // Get file
    const file = await prisma.file.findFirst({
      where: { id: fileId, userId },
    });

    if (!file) {
      throw new NotFoundError('File not found');
    }

    // Add to queue
    const job = await addJob(fileProcessingQueue, JobType.IMAGE_COMPRESS, {
      filePath: file.s3Key,
      quality,
      userId,
    });

    res.json({
      success: true,
      data: {
        jobId: job.id,
        status: JobStatus.PENDING,
      },
    });
  } catch (error) {
    next(error);
  }
}

// Upscale image
export async function upscaleImage(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { fileId, scale = 2 } = req.body;
    const userId = req.user!.userId;
    const userPlan = req.user!.plan || Plan.FREE;

    // Check operation limit
    const usage = await prisma.usage.findUnique({
      where: { userId },
    });

    if (!isOperationAllowed(userPlan, 'imageOperations', usage?.imageOperations || 0)) {
      throw new ForbiddenError(
        'Image operation limit exceeded. Please upgrade your plan.',
        'PLAN_LIMIT_EXCEEDED'
      );
    }

    // Get file
    const file = await prisma.file.findFirst({
      where: { id: fileId, userId },
    });

    if (!file) {
      throw new NotFoundError('File not found');
    }

    // Add to queue
    const job = await addJob(fileProcessingQueue, JobType.IMAGE_UPSCALE, {
      filePath: file.s3Key,
      scale,
      userId,
    });

    res.json({
      success: true,
      data: {
        jobId: job.id,
        status: JobStatus.PENDING,
      },
    });
  } catch (error) {
    next(error);
  }
}

// Convert image
export async function convertImage(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { fileId, format, quality = 90 } = req.body;
    const userId = req.user!.userId;
    const userPlan = req.user!.plan || Plan.FREE;

    // Check operation limit
    const usage = await prisma.usage.findUnique({
      where: { userId },
    });

    if (!isOperationAllowed(userPlan, 'imageOperations', usage?.imageOperations || 0)) {
      throw new ForbiddenError(
        'Image operation limit exceeded. Please upgrade your plan.',
        'PLAN_LIMIT_EXCEEDED'
      );
    }

    // Get file
    const file = await prisma.file.findFirst({
      where: { id: fileId, userId },
    });

    if (!file) {
      throw new NotFoundError('File not found');
    }

    // Add to queue
    const job = await addJob(fileProcessingQueue, JobType.IMAGE_CONVERT, {
      filePath: file.s3Key,
      format,
      quality,
      userId,
    });

    res.json({
      success: true,
      data: {
        jobId: job.id,
        status: JobStatus.PENDING,
      },
    });
  } catch (error) {
    next(error);
  }
}

// Remove background
export async function removeBackground(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { fileId } = req.body;
    const userId = req.user!.userId;
    const userPlan = req.user!.plan || Plan.FREE;

    // Check operation limit
    const usage = await prisma.usage.findUnique({
      where: { userId },
    });

    if (!isOperationAllowed(userPlan, 'imageOperations', usage?.imageOperations || 0)) {
      throw new ForbiddenError(
        'Image operation limit exceeded. Please upgrade your plan.',
        'PLAN_LIMIT_EXCEEDED'
      );
    }

    // Get file
    const file = await prisma.file.findFirst({
      where: { id: fileId, userId },
    });

    if (!file) {
      throw new NotFoundError('File not found');
    }

    // Add to queue
    const job = await addJob(fileProcessingQueue, JobType.IMAGE_REMOVE_BG, {
      filePath: file.s3Key,
      userId,
    });

    res.json({
      success: true,
      data: {
        jobId: job.id,
        status: JobStatus.PENDING,
      },
    });
  } catch (error) {
    next(error);
  }
}

// Extract colors
export async function extractColors(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { fileId, count = 5 } = req.body;
    const userId = req.user!.userId;

    // Get file
    const file = await prisma.file.findFirst({
      where: { id: fileId, userId },
    });

    if (!file) {
      throw new NotFoundError('File not found');
    }

    // Process directly (no queue needed for quick operations)
    const colors = await imageService.extractColors(file.s3Key, count);

    res.json({
      success: true,
      data: { colors },
    });
  } catch (error) {
    next(error);
  }
}

// AI Tools

// Generate hashtags
export async function generateHashtags(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { content, platform = 'instagram', count = 15 } = req.body;
    const userId = req.user!.userId;
    const userPlan = req.user!.plan || Plan.FREE;

    // Check operation limit
    const usage = await prisma.usage.findUnique({
      where: { userId },
    });

    if (!isOperationAllowed(userPlan, 'aiOperations', usage?.aiOperations || 0)) {
      throw new ForbiddenError(
        'AI operation limit exceeded. Please upgrade your plan.',
        'PLAN_LIMIT_EXCEEDED'
      );
    }

    const hashtags = await aiService.generateHashtags(content, platform, count);

    // Update usage
    await prisma.usage.update({
      where: { userId },
      data: {
        aiOperations: { increment: 1 },
        totalOperations: { increment: 1 },
      },
    });

    res.json({
      success: true,
      data: { hashtags },
    });
  } catch (error) {
    next(error);
  }
}

// Generate caption
export async function generateCaption(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { content, platform = 'instagram', tone = 'engaging', length = 'medium' } = req.body;
    const userId = req.user!.userId;
    const userPlan = req.user!.plan || Plan.FREE;

    // Check operation limit
    const usage = await prisma.usage.findUnique({
      where: { userId },
    });

    if (!isOperationAllowed(userPlan, 'aiOperations', usage?.aiOperations || 0)) {
      throw new ForbiddenError(
        'AI operation limit exceeded. Please upgrade your plan.',
        'PLAN_LIMIT_EXCEEDED'
      );
    }

    const caption = await aiService.generateCaption(content, platform, tone, length);

    // Update usage
    await prisma.usage.update({
      where: { userId },
      data: {
        aiOperations: { increment: 1 },
        totalOperations: { increment: 1 },
      },
    });

    res.json({
      success: true,
      data: { caption },
    });
  } catch (error) {
    next(error);
  }
}

// Generate bio
export async function generateBio(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { niche, personality = 'professional', platform = 'instagram' } = req.body;
    const userId = req.user!.userId;
    const userPlan = req.user!.plan || Plan.FREE;

    // Check operation limit
    const usage = await prisma.usage.findUnique({
      where: { userId },
    });

    if (!isOperationAllowed(userPlan, 'aiOperations', usage?.aiOperations || 0)) {
      throw new ForbiddenError(
        'AI operation limit exceeded. Please upgrade your plan.',
        'PLAN_LIMIT_EXCEEDED'
      );
    }

    const bio = await aiService.generateBio(niche, personality, platform);

    // Update usage
    await prisma.usage.update({
      where: { userId },
      data: {
        aiOperations: { increment: 1 },
        totalOperations: { increment: 1 },
      },
    });

    res.json({
      success: true,
      data: { bio },
    });
  } catch (error) {
    next(error);
  }
}

// Generate content ideas
export async function generateContentIdeas(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { niche, count = 5 } = req.body;
    const userId = req.user!.userId;
    const userPlan = req.user!.plan || Plan.FREE;

    // Check operation limit
    const usage = await prisma.usage.findUnique({
      where: { userId },
    });

    if (!isOperationAllowed(userPlan, 'aiOperations', usage?.aiOperations || 0)) {
      throw new ForbiddenError(
        'AI operation limit exceeded. Please upgrade your plan.',
        'PLAN_LIMIT_EXCEEDED'
      );
    }

    const ideas = await aiService.generateContentIdeas(niche, count);

    // Update usage
    await prisma.usage.update({
      where: { userId },
      data: {
        aiOperations: { increment: 1 },
        totalOperations: { increment: 1 },
      },
    });

    res.json({
      success: true,
      data: { ideas },
    });
  } catch (error) {
    next(error);
  }
}

// Generate video script
export async function generateVideoScript(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { topic, duration = 60, style = 'educational' } = req.body;
    const userId = req.user!.userId;
    const userPlan = req.user!.plan || Plan.FREE;

    // Check operation limit
    const usage = await prisma.usage.findUnique({
      where: { userId },
    });

    if (!isOperationAllowed(userPlan, 'aiOperations', usage?.aiOperations || 0)) {
      throw new ForbiddenError(
        'AI operation limit exceeded. Please upgrade your plan.',
        'PLAN_LIMIT_EXCEEDED'
      );
    }

    const script = await aiService.generateVideoScript(topic, duration, style);

    // Update usage
    await prisma.usage.update({
      where: { userId },
      data: {
        aiOperations: { increment: 1 },
        totalOperations: { increment: 1 },
      },
    });

    res.json({
      success: true,
      data: { script },
    });
  } catch (error) {
    next(error);
  }
}

// Business Tools

// Generate QR code
export async function generateQRCode(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { data, size, color, bgColor, type = 'text' } = req.body;

    let result;

    switch (type) {
      case 'wifi':
        const { ssid, password, encryption } = req.body;
        result = await businessService.generateWiFiQR(ssid, password, encryption, {
          size,
          color,
        });
        break;
      case 'vcard':
        const { contact } = req.body;
        result = await businessService.generateVCardQR(contact, { size, color });
        break;
      default:
        result = await businessService.generateQRCode(data, {
          size,
          color,
          bgColor,
        });
    }

    res.json({
      success: true,
      data: {
        dataUrl: result.dataUrl,
        fileName: result.fileName,
      },
    });
  } catch (error) {
    next(error);
  }
}

// Generate invoice
export async function generateInvoice(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const invoiceData = req.body;

    const result = await businessService.generateInvoice({
      ...invoiceData,
      date: new Date(invoiceData.date),
      dueDate: new Date(invoiceData.dueDate),
    });

    res.json({
      success: true,
      data: {
        fileName: result.fileName,
        downloadUrl: `${process.env.API_URL}/api/files/download/${result.fileName}`,
      },
    });
  } catch (error) {
    next(error);
  }
}

// Calculate EMI
export async function calculateEMI(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { principal, rate, tenure } = req.body;

    const result = businessService.calculateEMI(principal, rate, tenure);

    res.json({
      success: true,
      data: result,
    });
  } catch (error) {
    next(error);
  }
}

// Generate password
export async function generatePassword(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { length = 16, count = 1, options = {} } = req.body;

    if (count === 1) {
      const result = businessService.generatePassword(length, options);
      res.json({
        success: true,
        data: result,
      });
    } else {
      const results = businessService.generatePasswords(count, length, options);
      res.json({
        success: true,
        data: { passwords: results },
      });
    }
  } catch (error) {
    next(error);
  }
}

// Get job status
export async function getJobStatus(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { jobId } = req.params;

    const job = await prisma.job.findUnique({
      where: { id: jobId },
    });

    if (!job) {
      throw new NotFoundError('Job not found');
    }

    res.json({
      success: true,
      data: {
        id: job.id,
        type: job.type,
        status: job.status,
        progress: job.progress,
        result: job.result,
        error: job.error,
        createdAt: job.createdAt,
        startedAt: job.startedAt,
        completedAt: job.completedAt,
      },
    });
  } catch (error) {
    next(error);
  }
}

// Get usage stats
export async function getUsageStats(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const userId = req.user!.userId;
    const userPlan = req.user!.plan || Plan.FREE;

    const usage = await prisma.usage.findUnique({
      where: { userId },
    });

    if (!usage) {
      throw new NotFoundError('Usage data not found');
    }

    res.json({
      success: true,
      data: {
        pdfOperations: {
          used: usage.pdfOperations,
          remaining: getRemainingOperations(userPlan, 'pdfOperations', usage.pdfOperations),
        },
        imageOperations: {
          used: usage.imageOperations,
          remaining: getRemainingOperations(userPlan, 'imageOperations', usage.imageOperations),
        },
        aiOperations: {
          used: usage.aiOperations,
          remaining: getRemainingOperations(userPlan, 'aiOperations', usage.aiOperations),
        },
        fileUploads: usage.fileUploads,
        storageUsed: Number(usage.storageUsed),
        totalOperations: usage.totalOperations,
        resetAt: usage.resetAt,
      },
    });
  } catch (error) {
    next(error);
  }
}

export default {
  // PDF
  mergePDFs,
  splitPDF,
  compressPDF,
  convertPDFToImages,
  rotatePDF,
  // Image
  compressImage,
  upscaleImage,
  convertImage,
  removeBackground,
  extractColors,
  // AI
  generateHashtags,
  generateCaption,
  generateBio,
  generateContentIdeas,
  generateVideoScript,
  // Business
  generateQRCode,
  generateInvoice,
  calculateEMI,
  generatePassword,
  // General
  getJobStatus,
  getUsageStats,
};
