import { Request, Response, NextFunction } from 'express';
import { prisma } from '../config/database';
import {
  stripe,
  createStripeCustomer,
  createCheckoutSession,
  createPortalSession,
  cancelSubscription,
  resumeSubscription,
  PRICE_IDS,
  isStripeConfigured,
} from '../config/stripe';
import { sendSubscriptionEmail } from '../config/email';
import { BadRequestError, NotFoundError, ForbiddenError } from '../utils/errors';
import { Plan } from '../types';

// Create checkout session
export async function createCheckout(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    if (!isStripeConfigured()) {
      throw new BadRequestError('Payment processing is not configured');
    }

    const { plan } = req.body;
    const userId = req.user!.userId;

    // Get user
    const user = await prisma.user.findUnique({
      where: { id: userId },
      include: { subscription: true },
    });

    if (!user) {
      throw new NotFoundError('User not found');
    }

    // Get price ID
    const priceId = PRICE_IDS[plan as keyof typeof PRICE_IDS];
    if (!priceId) {
      throw new BadRequestError('Invalid plan selected');
    }

    // Create or get Stripe customer
    let stripeCustomerId = user.subscription?.stripeCustomerId;

    if (!stripeCustomerId) {
      stripeCustomerId = await createStripeCustomer(user.email, user.name || undefined);
      if (!stripeCustomerId) {
        throw new BadRequestError('Failed to create customer');
      }

      // Save customer ID
      await prisma.subscription.upsert({
        where: { userId },
        create: {
          userId,
          stripeCustomerId,
          plan: Plan.FREE,
        },
        update: {
          stripeCustomerId,
        },
      });
    }

    // Create checkout session
    const session = await createCheckoutSession(
      stripeCustomerId,
      priceId,
      `${process.env.FRONTEND_URL}/dashboard?success=true`,
      `${process.env.FRONTEND_URL}/pricing?canceled=true`
    );

    if (!session) {
      throw new BadRequestError('Failed to create checkout session');
    }

    res.json({
      success: true,
      data: {
        sessionId: session.id,
        url: session.url,
      },
    });
  } catch (error) {
    next(error);
  }
}

// Create customer portal session
export async function createPortal(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    if (!isStripeConfigured()) {
      throw new BadRequestError('Payment processing is not configured');
    }

    const userId = req.user!.userId;

    const subscription = await prisma.subscription.findUnique({
      where: { userId },
    });

    if (!subscription?.stripeCustomerId) {
      throw new BadRequestError('No subscription found');
    }

    const session = await createPortalSession(
      subscription.stripeCustomerId,
      `${process.env.FRONTEND_URL}/dashboard/settings`
    );

    if (!session) {
      throw new BadRequestError('Failed to create portal session');
    }

    res.json({
      success: true,
      data: {
        url: session.url,
      },
    });
  } catch (error) {
    next(error);
  }
}

// Get subscription status
export async function getSubscription(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const userId = req.user!.userId;

    const subscription = await prisma.subscription.findUnique({
      where: { userId },
    });

    res.json({
      success: true,
      data: subscription || {
        plan: Plan.FREE,
        status: 'INACTIVE',
      },
    });
  } catch (error) {
    next(error);
  }
}

// Cancel subscription
export async function cancelSubscriptionHandler(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    if (!isStripeConfigured()) {
      throw new BadRequestError('Payment processing is not configured');
    }

    const userId = req.user!.userId;

    const subscription = await prisma.subscription.findUnique({
      where: { userId },
    });

    if (!subscription?.stripeSubscriptionId) {
      throw new BadRequestError('No active subscription found');
    }

    await cancelSubscription(subscription.stripeSubscriptionId);

    await prisma.subscription.update({
      where: { userId },
      data: {
        cancelAtPeriodEnd: true,
      },
    });

    res.json({
      success: true,
      message: 'Subscription will be canceled at the end of the billing period',
    });
  } catch (error) {
    next(error);
  }
}

// Resume subscription
export async function resumeSubscriptionHandler(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    if (!isStripeConfigured()) {
      throw new BadRequestError('Payment processing is not configured');
    }

    const userId = req.user!.userId;

    const subscription = await prisma.subscription.findUnique({
      where: { userId },
    });

    if (!subscription?.stripeSubscriptionId) {
      throw new BadRequestError('No subscription found');
    }

    await resumeSubscription(subscription.stripeSubscriptionId);

    await prisma.subscription.update({
      where: { userId },
      data: {
        cancelAtPeriodEnd: false,
      },
    });

    res.json({
      success: true,
      message: 'Subscription resumed successfully',
    });
  } catch (error) {
    next(error);
  }
}

// Get payment history
export async function getPaymentHistory(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const userId = req.user!.userId;
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 10;
    const skip = (page - 1) * limit;

    const [payments, total] = await Promise.all([
      prisma.payment.findMany({
        where: { userId },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      prisma.payment.count({
        where: { userId },
      }),
    ]);

    res.json({
      success: true,
      data: payments,
      meta: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    next(error);
  }
}

// Stripe webhook handler
export async function stripeWebhook(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    if (!isStripeConfigured()) {
      res.status(400).json({ error: 'Stripe not configured' });
      return;
    }

    const sig = req.headers['stripe-signature'] as string;
    const event = stripe!.webhooks.constructEvent(
      req.body,
      sig,
      process.env.STRIPE_WEBHOOK_SECRET!
    );

    // Handle events
    switch (event.type) {
      case 'checkout.session.completed': {
        const session = event.data.object as any;
        await handleCheckoutCompleted(session);
        break;
      }

      case 'invoice.payment_succeeded': {
        const invoice = event.data.object as any;
        await handleInvoicePaid(invoice);
        break;
      }

      case 'invoice.payment_failed': {
        const invoice = event.data.object as any;
        await handleInvoiceFailed(invoice);
        break;
      }

      case 'customer.subscription.updated': {
        const subscription = event.data.object as any;
        await handleSubscriptionUpdated(subscription);
        break;
      }

      case 'customer.subscription.deleted': {
        const subscription = event.data.object as any;
        await handleSubscriptionDeleted(subscription);
        break;
      }
    }

    res.json({ received: true });
  } catch (error: any) {
    console.error('Webhook error:', error.message);
    res.status(400).json({ error: error.message });
  }
}

// Handle checkout completed
async function handleCheckoutCompleted(session: any): Promise<void> {
  const customerId = session.customer;
  const subscriptionId = session.subscription;
  const priceId = session.line_items?.data[0]?.price?.id;

  // Find plan from price ID
  let plan = Plan.BASIC;
  if (priceId === PRICE_IDS.PRO) plan = Plan.PRO;
  if (priceId === PRICE_IDS.ENTERPRISE) plan = Plan.ENTERPRISE;

  // Find user by customer ID
  const subscription = await prisma.subscription.findFirst({
    where: { stripeCustomerId: customerId },
    include: { user: true },
  });

  if (subscription) {
    await prisma.subscription.update({
      where: { id: subscription.id },
      data: {
        stripeSubscriptionId: subscriptionId,
        stripePriceId: priceId,
        plan,
        status: 'ACTIVE',
        currentPeriodStart: new Date(session.current_period_start * 1000),
        currentPeriodEnd: new Date(session.current_period_end * 1000),
      },
    });

    // Send confirmation email
    await sendSubscriptionEmail(subscription.user.email, subscription.user.name || '', plan);

    // Create payment record
    await prisma.payment.create({
      data: {
        userId: subscription.userId,
        stripePaymentIntentId: session.payment_intent,
        amount: session.amount_total,
        currency: session.currency,
        status: 'COMPLETED',
        plan,
        description: `Subscription to ${plan} plan`,
      },
    });
  }
}

// Handle invoice paid
async function handleInvoicePaid(invoice: any): Promise<void> {
  const subscriptionId = invoice.subscription;
  const customerId = invoice.customer;

  const subscription = await prisma.subscription.findFirst({
    where: { stripeSubscriptionId: subscriptionId },
  });

  if (subscription) {
    await prisma.payment.create({
      data: {
        userId: subscription.userId,
        stripeInvoiceId: invoice.id,
        amount: invoice.amount_paid,
        currency: invoice.currency,
        status: 'COMPLETED',
        plan: subscription.plan as Plan,
        description: `Invoice payment for ${subscription.plan} plan`,
        receiptUrl: invoice.hosted_invoice_url,
      },
    });
  }
}

// Handle invoice failed
async function handleInvoiceFailed(invoice: any): Promise<void> {
  const subscriptionId = invoice.subscription;

  const subscription = await prisma.subscription.findFirst({
    where: { stripeSubscriptionId: subscriptionId },
  });

  if (subscription) {
    await prisma.subscription.update({
      where: { id: subscription.id },
      data: {
        status: 'PAST_DUE',
      },
    });

    await prisma.payment.create({
      data: {
        userId: subscription.userId,
        stripeInvoiceId: invoice.id,
        amount: invoice.amount_due,
        currency: invoice.currency,
        status: 'FAILED',
        plan: subscription.plan as Plan,
        description: `Failed invoice payment for ${subscription.plan} plan`,
      },
    });
  }
}

// Handle subscription updated
async function handleSubscriptionUpdated(subscription: any): Promise<void> {
  const dbSubscription = await prisma.subscription.findFirst({
    where: { stripeSubscriptionId: subscription.id },
  });

  if (dbSubscription) {
    await prisma.subscription.update({
      where: { id: dbSubscription.id },
      data: {
        status: subscription.status.toUpperCase(),
        currentPeriodStart: new Date(subscription.current_period_start * 1000),
        currentPeriodEnd: new Date(subscription.current_period_end * 1000),
        cancelAtPeriodEnd: subscription.cancel_at_period_end,
      },
    });
  }
}

// Handle subscription deleted
async function handleSubscriptionDeleted(subscription: any): Promise<void> {
  const dbSubscription = await prisma.subscription.findFirst({
    where: { stripeSubscriptionId: subscription.id },
  });

  if (dbSubscription) {
    await prisma.subscription.update({
      where: { id: dbSubscription.id },
      data: {
        plan: Plan.FREE,
        status: 'CANCELED',
        stripeSubscriptionId: null,
        stripePriceId: null,
      },
    });
  }
}

// Get plans
export async function getPlans(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const plans = [
      {
        id: Plan.FREE,
        name: 'Free',
        description: 'Perfect for trying out our tools',
        price: { monthly: 0, yearly: 0 },
        features: [
          '5 PDF operations/month',
          '10 Image operations/month',
          '3 AI generations/month',
          '500MB storage',
          '10MB max file size',
        ],
        cta: 'Get Started',
      },
      {
        id: Plan.BASIC,
        name: 'Basic',
        description: 'For casual creators',
        price: { monthly: 9.99, yearly: 99.99 },
        features: [
          '50 PDF operations/month',
          '100 Image operations/month',
          '25 AI generations/month',
          '5GB storage',
          '50MB max file size',
          'Priority support',
        ],
        cta: 'Start Free Trial',
        popular: false,
      },
      {
        id: Plan.PRO,
        name: 'Pro',
        description: 'For professional creators',
        price: { monthly: 29.99, yearly: 299.99 },
        features: [
          '500 PDF operations/month',
          '1000 Image operations/month',
          '200 AI generations/month',
          '50GB storage',
          '100MB max file size',
          'Priority support',
          'API access',
        ],
        cta: 'Start Free Trial',
        popular: true,
      },
      {
        id: Plan.ENTERPRISE,
        name: 'Enterprise',
        description: 'For teams and businesses',
        price: { monthly: 99.99, yearly: 999.99 },
        features: [
          'Unlimited PDF operations',
          'Unlimited Image operations',
          'Unlimited AI generations',
          '500GB storage',
          '500MB max file size',
          '24/7 dedicated support',
          'Full API access',
          'Custom integrations',
        ],
        cta: 'Contact Sales',
      },
    ];

    res.json({
      success: true,
      data: plans,
    });
  } catch (error) {
    next(error);
  }
}

export default {
  createCheckout,
  createPortal,
  getSubscription,
  cancelSubscription: cancelSubscriptionHandler,
  resumeSubscription: resumeSubscriptionHandler,
  getPaymentHistory,
  stripeWebhook,
  getPlans,
};
