import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import compression from 'compression';
import cookieParser from 'cookie-parser';
import { env } from './config/env';
import { testConnection } from './config/database';
import { redis } from './config/redis';
import { errorHandler, notFoundHandler } from './middleware/errorHandler';

// Import routes
import authRoutes from './routes/auth';
import fileRoutes from './routes/files';
import toolsRoutes from './routes/tools';
import paymentRoutes from './routes/payments';

// Initialize express app
const app = express();

// Security middleware
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", "data:", "https:"],
    },
  },
  crossOriginEmbedderPolicy: false,
}));

// CORS
app.use(cors({
  origin: env.FRONTEND_URL,
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));

// Stripe webhook - needs raw body, must be before express.json
app.use('/api/payments/webhook', express.raw({ type: 'application/json' }));

// Body parsing
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(cookieParser());

// Compression
app.use(compression());

// Logging
if (env.NODE_ENV === 'development') {
  app.use(morgan('dev'));
} else {
  app.use(morgan('combined'));
}

// Health check endpoint
app.get('/health', async (_req, res) => {
  const dbHealthy = await testConnection().catch(() => false);
  const redisHealthy = redis.status === 'ready' || redis.status === 'connecting';

  res.status(dbHealthy && redisHealthy ? 200 : 503).json({
    status: dbHealthy && redisHealthy ? 'healthy' : 'unhealthy',
    timestamp: new Date().toISOString(),
    services: {
      database: dbHealthy ? 'connected' : 'disconnected',
      redis: redisHealthy ? 'connected' : 'disconnected',
    },
    version: process.env.npm_package_version || '1.0.0',
  });
});

// API routes
app.use('/api/auth', authRoutes);
app.use('/api/files', fileRoutes);
app.use('/api/tools', toolsRoutes);
app.use('/api/payments', paymentRoutes);

// Root endpoint
app.get('/', (_req, res) => {
  res.json({
    name: 'CreatorHub API',
    version: '1.0.0',
    description: 'Creative Tools Platform API',
    documentation: '/api/docs',
    health: '/health',
  });
});

// 404 handler
app.use(notFoundHandler);

// Error handler
app.use(errorHandler);

// Start server
const PORT = parseInt(env.PORT);

async function startServer() {
  try {
    // Test database connection with retry
    let dbConnected = false;
    let retries = 0;
    const maxRetries = 5;
    
    while (!dbConnected && retries < maxRetries) {
      dbConnected = await testConnection();
      if (!dbConnected) {
        retries++;
        console.warn(`⚠️  Database connection failed (attempt ${retries}/${maxRetries}). Retrying in 5 seconds...`);
        await new Promise(resolve => setTimeout(resolve, 5000));
      }
    }
    
    if (!dbConnected) {
      console.error('❌ Failed to connect to database after maximum retries');
      console.log('⚠️  Starting server without database - some features may not work');
    }

    // Start server
    app.listen(PORT, '0.0.0.0', () => {
      console.log(`
╔════════════════════════════════════════════════════════╗
║                                                        ║
║   🚀 CreatorHub API Server                             ║
║                                                        ║
║   Environment: ${env.NODE_ENV.padEnd(34)}║
║   Port: ${PORT.toString().padEnd(43)}║
║   Database: ${(dbConnected ? 'Connected' : 'Disconnected').padEnd(37)}║
║   Redis: ${(redis.status === 'ready' ? 'Connected' : 'In-Memory').padEnd(40)}║
║                                                        ║
║   API Endpoints:                                       ║
║   • Health:    http://localhost:${PORT}/health                ║
║   • API:       http://localhost:${PORT}/api                   ║
║                                                        ║
╚════════════════════════════════════════════════════════╝
      `);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    // Don't exit, try to start anyway
    console.log('⚠️  Attempting to start server despite errors...');
    app.listen(PORT, '0.0.0.0', () => {
      console.log(`🚀 Server started on port ${PORT} (with errors)`);
    });
  }
}

// Handle uncaught errors
process.on('uncaughtException', (error) => {
  console.error('Uncaught Exception:', error);
  process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('SIGTERM received. Shutting down gracefully...');
  
  // Close Redis connection
  await redis.quit();
  
  // Exit process
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('SIGINT received. Shutting down gracefully...');
  
  // Close Redis connection
  await redis.quit();
  
  // Exit process
  process.exit(0);
});

// Start the server
startServer();

export default app;
