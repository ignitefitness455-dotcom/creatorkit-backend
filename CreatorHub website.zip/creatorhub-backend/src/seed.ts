import { prisma } from './config/database';
import { Plan } from './types';
import bcrypt from 'bcryptjs';

async function seed() {
  console.log('🌱 Seeding database...\n');

  // Create admin user
  const adminEmail = 'admin@creatorhub.com';
  const adminPassword = await bcrypt.hash('Admin123!', 12);

  const admin = await prisma.user.upsert({
    where: { email: adminEmail },
    update: {},
    create: {
      email: adminEmail,
      password: adminPassword,
      name: 'Admin User',
      emailVerified: true,
    },
  });

  console.log('✅ Admin user created:', admin.email);

  // Create admin subscription
  await prisma.subscription.upsert({
    where: { userId: admin.id },
    update: {},
    create: {
      userId: admin.id,
      plan: Plan.ENTERPRISE,
      status: 'ACTIVE',
    },
  });

  // Create admin usage
  await prisma.usage.upsert({
    where: { userId: admin.id },
    update: {},
    create: {
      userId: admin.id,
    },
  });

  console.log('✅ Admin subscription created\n');

  // Create test user
  const testEmail = 'test@example.com';
  const testPassword = await bcrypt.hash('Test123!', 12);

  const testUser = await prisma.user.upsert({
    where: { email: testEmail },
    update: {},
    create: {
      email: testEmail,
      password: testPassword,
      name: 'Test User',
      emailVerified: true,
    },
  });

  console.log('✅ Test user created:', testUser.email);

  // Create test user subscription (FREE plan)
  await prisma.subscription.upsert({
    where: { userId: testUser.id },
    update: {},
    create: {
      userId: testUser.id,
      plan: Plan.FREE,
      status: 'INACTIVE',
    },
  });

  // Create test user usage
  await prisma.usage.upsert({
    where: { userId: testUser.id },
    update: {},
    create: {
      userId: testUser.id,
    },
  });

  console.log('✅ Test user subscription created\n');

  console.log('🎉 Seeding completed!');
  console.log('\nTest credentials:');
  console.log('  Admin: admin@creatorhub.com / Admin123!');
  console.log('  User:  test@example.com / Test123!');
}

seed()
  .catch((e) => {
    console.error('❌ Seeding failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
