import QRCode from 'qrcode';
import fs from 'fs/promises';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';

// QR Code generation
export async function generateQRCode(
  data: string,
  options: {
    size?: number;
    color?: string;
    bgColor?: string;
    errorCorrectionLevel?: 'L' | 'M' | 'Q' | 'H';
    logo?: string; // Base64 encoded logo image
  } = {}
): Promise<{ filePath: string; fileName: string; dataUrl: string }> {
  const {
    size = 500,
    color = '#000000',
    bgColor = '#FFFFFF',
    errorCorrectionLevel = 'M',
  } = options;

  const outputFileName = `qr-${uuidv4()}.png`;
  const outputPath = path.join(process.cwd(), 'uploads', 'temp', outputFileName);

  // Convert hex colors to RGB arrays
  const hexToRgb = (hex: string): [number, number, number] => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result
      ? [
          parseInt(result[1], 16),
          parseInt(result[2], 16),
          parseInt(result[3], 16),
        ]
      : [0, 0, 0];
  };

  const colorRgb = hexToRgb(color);
  const bgRgb = hexToRgb(bgColor);

  // Generate QR code
  const dataUrl = await QRCode.toDataURL(data, {
    width: size,
    margin: 2,
    color: {
      dark: color,
      light: bgColor,
    },
    errorCorrectionLevel,
  });

  // Save to file
  const base64Data = dataUrl.replace(/^data:image\/png;base64,/, '');
  await fs.writeFile(outputPath, base64Data, 'base64');

  return {
    filePath: outputPath,
    fileName: outputFileName,
    dataUrl,
  };
}

// Generate vCard QR Code
export async function generateVCardQR(
  contact: {
    firstName: string;
    lastName: string;
    phone?: string;
    email?: string;
    company?: string;
    title?: string;
    website?: string;
    address?: string;
  },
  options: { size?: number; color?: string } = {}
): Promise<{ filePath: string; fileName: string; dataUrl: string }> {
  // Build vCard format
  const vCardLines = [
    'BEGIN:VCARD',
    'VERSION:3.0',
    `N:${contact.lastName};${contact.firstName};;;`,
    `FN:${contact.firstName} ${contact.lastName}`,
  ];

  if (contact.phone) vCardLines.push(`TEL;TYPE=CELL:${contact.phone}`);
  if (contact.email) vCardLines.push(`EMAIL;TYPE=WORK:${contact.email}`);
  if (contact.company) vCardLines.push(`ORG:${contact.company}`);
  if (contact.title) vCardLines.push(`TITLE:${contact.title}`);
  if (contact.website) vCardLines.push(`URL:${contact.website}`);
  if (contact.address) vCardLines.push(`ADR;TYPE=WORK:;;${contact.address};;;;`);

  vCardLines.push('END:VCARD');

  const vCardData = vCardLines.join('\n');

  return generateQRCode(vCardData, { ...options, errorCorrectionLevel: 'H' });
}

// WiFi QR Code
export async function generateWiFiQR(
  ssid: string,
  password: string,
  encryption: 'WPA' | 'WEP' | 'nopass' = 'WPA',
  options: { size?: number; color?: string } = {}
): Promise<{ filePath: string; fileName: string; dataUrl: string }> {
  const wifiString = `WIFI:S:${ssid};T:${encryption};P:${password};;`;
  return generateQRCode(wifiString, options);
}

// Invoice item interface
interface InvoiceItem {
  description: string;
  quantity: number;
  price: number; // in cents
}

// Generate Invoice PDF
export async function generateInvoice(
  invoiceData: {
    invoiceNumber: string;
    date: Date;
    dueDate: Date;
    from: {
      name: string;
      email: string;
      address?: string;
      phone?: string;
    };
    to: {
      name: string;
      email: string;
      address?: string;
    };
    items: InvoiceItem[];
    taxRate?: number;
    notes?: string;
    currency?: string;
  }
): Promise<{ filePath: string; fileName: string }> {
  const pdfDoc = await PDFDocument.create();
  const page = pdfDoc.addPage([612, 792]); // US Letter size

  const { width, height } = page.getSize();
  const helvetica = await pdfDoc.embedFont(StandardFonts.Helvetica);
  const helveticaBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);

  let y = height - 50;

  // Header
  page.drawText('INVOICE', {
    x: 50,
    y,
    size: 30,
    font: helveticaBold,
    color: rgb(0.2, 0.2, 0.8),
  });

  // Invoice number and dates
  y -= 40;
  page.drawText(`Invoice #: ${invoiceData.invoiceNumber}`, {
    x: 50,
    y,
    size: 12,
    font: helvetica,
  });

  y -= 20;
  page.drawText(`Date: ${invoiceData.date.toLocaleDateString()}`, {
    x: 50,
    y,
    size: 12,
    font: helvetica,
  });

  y -= 20;
  page.drawText(`Due Date: ${invoiceData.dueDate.toLocaleDateString()}`, {
    x: 50,
    y,
    size: 12,
    font: helvetica,
  });

  // From section
  y -= 50;
  page.drawText('From:', {
    x: 50,
    y,
    size: 14,
    font: helveticaBold,
  });

  y -= 20;
  page.drawText(invoiceData.from.name, {
    x: 50,
    y,
    size: 12,
    font: helvetica,
  });

  y -= 15;
  page.drawText(invoiceData.from.email, {
    x: 50,
    y,
    size: 10,
    font: helvetica,
    color: rgb(0.4, 0.4, 0.4),
  });

  if (invoiceData.from.address) {
    y -= 15;
    page.drawText(invoiceData.from.address, {
      x: 50,
      y,
      size: 10,
      font: helvetica,
      color: rgb(0.4, 0.4, 0.4),
    });
  }

  // To section
  y -= 40;
  page.drawText('Bill To:', {
    x: 50,
    y,
    size: 14,
    font: helveticaBold,
  });

  y -= 20;
  page.drawText(invoiceData.to.name, {
    x: 50,
    y,
    size: 12,
    font: helvetica,
  });

  y -= 15;
  page.drawText(invoiceData.to.email, {
    x: 50,
    y,
    size: 10,
    font: helvetica,
    color: rgb(0.4, 0.4, 0.4),
  });

  // Items table header
  y -= 60;
  const tableY = y;
  
  page.drawRectangle({
    x: 50,
    y: y - 10,
    width: width - 100,
    height: 30,
    color: rgb(0.95, 0.95, 0.95),
  });

  page.drawText('Description', {
    x: 60,
    y,
    size: 11,
    font: helveticaBold,
  });

  page.drawText('Qty', {
    x: 350,
    y,
    size: 11,
    font: helveticaBold,
  });

  page.drawText('Price', {
    x: 420,
    y,
    size: 11,
    font: helveticaBold,
  });

  page.drawText('Amount', {
    x: 500,
    y,
    size: 11,
    font: helveticaBold,
  });

  // Items
  y -= 35;
  let subtotal = 0;
  const currency = invoiceData.currency || 'USD';

  for (const item of invoiceData.items) {
    const amount = item.quantity * item.price;
    subtotal += amount;

    page.drawText(item.description.substring(0, 40), {
      x: 60,
      y,
      size: 10,
      font: helvetica,
    });

    page.drawText(item.quantity.toString(), {
      x: 350,
      y,
      size: 10,
      font: helvetica,
    });

    page.drawText(formatCurrency(item.price, currency), {
      x: 420,
      y,
      size: 10,
      font: helvetica,
    });

    page.drawText(formatCurrency(amount, currency), {
      x: 500,
      y,
      size: 10,
      font: helvetica,
    });

    y -= 20;
  }

  // Totals
  y -= 20;
  const taxRate = invoiceData.taxRate || 0;
  const tax = Math.round(subtotal * (taxRate / 100));
  const total = subtotal + tax;

  // Subtotal
  page.drawText('Subtotal:', {
    x: 400,
    y,
    size: 11,
    font: helveticaBold,
  });

  page.drawText(formatCurrency(subtotal, currency), {
    x: 500,
    y,
    size: 11,
    font: helvetica,
  });

  // Tax
  if (tax > 0) {
    y -= 20;
    page.drawText(`Tax (${taxRate}%):`, {
      x: 400,
      y,
      size: 11,
      font: helveticaBold,
    });

    page.drawText(formatCurrency(tax, currency), {
      x: 500,
      y,
      size: 11,
      font: helvetica,
    });
  }

  // Total
  y -= 25;
  page.drawRectangle({
    x: 390,
    y: y - 5,
    width: 170,
    height: 25,
    color: rgb(0.2, 0.2, 0.8),
  });

  page.drawText('TOTAL:', {
    x: 400,
    y,
    size: 12,
    font: helveticaBold,
    color: rgb(1, 1, 1),
  });

  page.drawText(formatCurrency(total, currency), {
    x: 500,
    y,
    size: 12,
    font: helveticaBold,
    color: rgb(1, 1, 1),
  });

  // Notes
  if (invoiceData.notes) {
    y -= 60;
    page.drawText('Notes:', {
      x: 50,
      y,
      size: 12,
      font: helveticaBold,
    });

    y -= 20;
    const words = invoiceData.notes.split(' ');
    let line = '';
    
    for (const word of words) {
      if ((line + word).length > 80) {
        page.drawText(line, {
          x: 50,
          y,
          size: 10,
          font: helvetica,
        });
        y -= 15;
        line = word + ' ';
      } else {
        line += word + ' ';
      }
    }
    
    if (line) {
      page.drawText(line, {
        x: 50,
        y,
        size: 10,
        font: helvetica,
      });
    }
  }

  // Save PDF
  const pdfBytes = await pdfDoc.save();
  const outputFileName = `invoice-${invoiceData.invoiceNumber}-${uuidv4()}.pdf`;
  const outputPath = path.join(process.cwd(), 'uploads', 'temp', outputFileName);

  await fs.writeFile(outputPath, pdfBytes);

  return {
    filePath: outputPath,
    fileName: outputFileName,
  };
}

// Format currency (cents to string)
function formatCurrency(cents: number, currency: string): string {
  const amount = cents / 100;
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency,
  }).format(amount);
}

// EMI Calculator
export function calculateEMI(
  principal: number, // in currency units
  annualRate: number, // annual interest rate in percentage
  tenureMonths: number
): {
  emi: number;
  totalInterest: number;
  totalPayment: number;
  schedule: Array<{
    month: number;
    emi: number;
    principal: number;
    interest: number;
    balance: number;
  }>;
} {
  const monthlyRate = annualRate / 12 / 100;
  
  // EMI formula: P * r * (1 + r)^n / ((1 + r)^n - 1)
  const emi =
    monthlyRate === 0
      ? principal / tenureMonths
      : (principal *
          monthlyRate *
          Math.pow(1 + monthlyRate, tenureMonths)) /
        (Math.pow(1 + monthlyRate, tenureMonths) - 1);

  const totalPayment = emi * tenureMonths;
  const totalInterest = totalPayment - principal;

  // Generate amortization schedule
  const schedule: Array<{
    month: number;
    emi: number;
    principal: number;
    interest: number;
    balance: number;
  }> = [];

  let balance = principal;

  for (let month = 1; month <= tenureMonths; month++) {
    const interestPayment = balance * monthlyRate;
    const principalPayment = emi - interestPayment;
    balance -= principalPayment;

    schedule.push({
      month,
      emi: Math.round(emi * 100) / 100,
      principal: Math.round(principalPayment * 100) / 100,
      interest: Math.round(interestPayment * 100) / 100,
      balance: Math.max(0, Math.round(balance * 100) / 100),
    });
  }

  return {
    emi: Math.round(emi * 100) / 100,
    totalInterest: Math.round(totalInterest * 100) / 100,
    totalPayment: Math.round(totalPayment * 100) / 100,
    schedule,
  };
}

// Password Generator
export function generatePassword(
  length: number = 16,
  options: {
    uppercase?: boolean;
    lowercase?: boolean;
    numbers?: boolean;
    symbols?: boolean;
    excludeSimilar?: boolean;
    excludeAmbiguous?: boolean;
  } = {}
): {
  password: string;
  strength: 'weak' | 'medium' | 'strong' | 'very-strong';
  entropy: number;
} {
  const {
    uppercase = true,
    lowercase = true,
    numbers = true,
    symbols = true,
    excludeSimilar = false,
    excludeAmbiguous = false,
  } = options;

  let chars = '';
  
  if (lowercase) chars += 'abcdefghijklmnopqrstuvwxyz';
  if (uppercase) chars += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  if (numbers) chars += '0123456789';
  if (symbols) chars += '!@#$%^&*()_+-=[]{}|;:,.<>?';

  // Exclude similar characters
  if (excludeSimilar) {
    chars = chars.replace(/[0O1lI]/g, '');
  }

  // Exclude ambiguous characters
  if (excludeAmbiguous) {
    chars = chars.replace(/[{}[\]()/\\'"`~,;:.<>]/g, '');
  }

  if (chars === '') {
    chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
  }

  let password = '';
  const array = new Uint32Array(length);
  crypto.getRandomValues(array);

  for (let i = 0; i < length; i++) {
    password += chars[array[i] % chars.length];
  }

  // Calculate strength
  const poolSize = chars.length;
  const entropy = Math.log2(Math.pow(poolSize, length));

  let strength: 'weak' | 'medium' | 'strong' | 'very-strong';
  if (entropy < 50) strength = 'weak';
  else if (entropy < 75) strength = 'medium';
  else if (entropy < 100) strength = 'strong';
  else strength = 'very-strong';

  return { password, strength, entropy: Math.round(entropy * 100) / 100 };
}

// Generate multiple passwords
export function generatePasswords(
  count: number = 5,
  length: number = 16,
  options?: Parameters<typeof generatePassword>[1]
): ReturnType<typeof generatePassword>[] {
  const passwords: ReturnType<typeof generatePassword>[] = [];
  
  for (let i = 0; i < count; i++) {
    passwords.push(generatePassword(length, options));
  }
  
  return passwords;
}

// Mockup Generator (placeholder - would use Puppeteer or Canvas)
export async function generateMockup(
  imagePath: string,
  template: 'iphone' | 'macbook' | 'ipad' | 'browser' | 'billboard'
): Promise<{ filePath: string; fileName: string }> {
  // This is a placeholder - real implementation would use Puppeteer or Canvas
  // to composite the image onto a device mockup template
  
  // For now, just return the original image
  const outputFileName = `mockup-${template}-${uuidv4()}.png`;
  const outputPath = path.join(process.cwd(), 'uploads', 'temp', outputFileName);
  
  // Copy the original file
  const imageBuffer = await fs.readFile(imagePath);
  await fs.writeFile(outputPath, imageBuffer);
  
  return {
    filePath: outputPath,
    fileName: outputFileName,
  };
}

export default {
  generateQRCode,
  generateVCardQR,
  generateWiFiQR,
  generateInvoice,
  calculateEMI,
  generatePassword,
  generatePasswords,
  generateMockup,
};
