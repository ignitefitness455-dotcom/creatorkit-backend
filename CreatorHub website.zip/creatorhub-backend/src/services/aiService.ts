import { openai, isOpenAIConfigured } from '../config/openai';
import { cache } from '../config/redis';

// Cache duration in seconds
const CACHE_DURATION = 60 * 60; // 1 hour

// Generate hashtags
export async function generateHashtags(
  content: string,
  platform: string = 'instagram',
  count: number = 15
): Promise<string[]> {
  const cacheKey = `hashtags:${platform}:${Buffer.from(content).toString('base64').slice(0, 32)}:${count}`;
  
  // Check cache
  const cached = await cache.get<string[]>(cacheKey);
  if (cached) return cached;

  if (!isOpenAIConfigured()) {
    // Fallback hashtags
    const fallbackHashtags = [
      '#contentcreator',
      '#digitalcreator',
      '#creative',
      '#content',
      '#socialmedia',
      '#marketing',
      '#branding',
      '#growth',
      '#engagement',
      '#viral',
      '#trending',
      '#instagood',
      '#photooftheday',
      '#love',
      '#beautiful',
    ].slice(0, count);
    
    await cache.set(cacheKey, fallbackHashtags, CACHE_DURATION);
    return fallbackHashtags;
  }

  const prompt = `Generate ${count} relevant, trending, and engaging hashtags for the following content on ${platform}:

Content: "${content}"

Requirements:
- Mix of popular (1M+ posts) and niche (10K-100K posts) hashtags
- Include both broad and specific tags related to the content
- No spaces in hashtags (use camelCase if needed)
- Relevant to the content theme and ${platform} audience
- Format: just the hashtags, one per line, starting with #`;

  const response = await openai!.chat.completions.create({
    model: 'gpt-4',
    messages: [
      {
        role: 'system',
        content: 'You are a social media marketing expert specializing in hashtag strategy. Generate engaging, relevant hashtags that maximize reach and engagement.',
      },
      { role: 'user', content: prompt },
    ],
    temperature: 0.7,
    max_tokens: 200,
  });

  const text = response.choices[0]?.message?.content || '';
  const hashtags = text
    .split('\n')
    .map((tag) => tag.trim())
    .filter((tag) => tag.startsWith('#') && tag.length > 1)
    .slice(0, count);

  // Cache result
  await cache.set(cacheKey, hashtags, CACHE_DURATION);

  return hashtags;
}

// Generate caption
export async function generateCaption(
  content: string,
  platform: string = 'instagram',
  tone: string = 'engaging',
  length: 'short' | 'medium' | 'long' = 'medium'
): Promise<string> {
  const cacheKey = `caption:${platform}:${tone}:${length}:${Buffer.from(content).toString('base64').slice(0, 32)}`;
  
  // Check cache
  const cached = await cache.get<string>(cacheKey);
  if (cached) return cached;

  const lengthGuide = {
    short: '1-2 sentences, under 150 characters - punchy and direct',
    medium: '3-5 sentences, around 200-300 characters - engaging and informative',
    long: '5-8 sentences, detailed - storytelling style with emoji breaks',
  };

  const toneGuide: Record<string, string> = {
    professional: 'formal, business-focused, authoritative',
    casual: 'friendly, conversational, relatable',
    funny: 'humorous, witty, entertaining with jokes or puns',
    inspirational: 'motivational, uplifting, thought-provoking',
    promotional: 'sales-focused, highlighting benefits, call-to-action heavy',
  };

  if (!isOpenAIConfigured()) {
    const fallbackCaption = `✨ ${content}

What do you think? Drop your thoughts in the comments! 👇

Follow for more content like this! ❤️`;
    
    await cache.set(cacheKey, fallbackCaption, CACHE_DURATION);
    return fallbackCaption;
  }

  const prompt = `Write an engaging ${platform} caption for the following content:

Content: "${content}"

Tone: ${toneGuide[tone] || tone}
Length: ${lengthGuide[length]}
Platform: ${platform}

Requirements:
- Include 3-5 relevant emojis naturally throughout
- Add a strong call-to-action at the end
- Use ${platform}-best practices (hashtags at end for IG, concise for Twitter, etc.)
- Make it authentic and engaging
- Avoid generic phrases like "Check this out" or "Amazing content"`;

  const response = await openai!.chat.completions.create({
    model: 'gpt-4',
    messages: [
      {
        role: 'system',
        content: 'You are a creative copywriter specializing in viral social media content. Write captions that drive engagement and feel authentic.',
      },
      { role: 'user', content: prompt },
    ],
    temperature: 0.8,
    max_tokens: 400,
  });

  const caption = response.choices[0]?.message?.content?.trim() || '';

  // Cache result
  await cache.set(cacheKey, caption, CACHE_DURATION);

  return caption;
}

// Generate bio
export async function generateBio(
  niche: string,
  personality: string = 'professional',
  platform: string = 'instagram'
): Promise<string> {
  const cacheKey = `bio:${platform}:${personality}:${Buffer.from(niche).toString('base64').slice(0, 32)}`;
  
  // Check cache
  const cached = await cache.get<string>(cacheKey);
  if (cached) return cached;

  const personalityGuide: Record<string, string> = {
    professional: 'polished, credible, industry-expert vibe',
    fun: 'playful, energetic, uses humor and emojis liberally',
    creative: 'artistic, unique, showcases creativity',
    minimal: 'clean, simple, less is more approach',
    bold: 'confident, statement-making, stands out',
  };

  const platformLimits: Record<string, string> = {
    instagram: '150 characters max',
    twitter: '160 characters max',
    tiktok: '80 characters max',
    linkedin: '200 characters max',
  };

  if (!isOpenAIConfigured()) {
    const fallbackBio = `✨ ${niche} creator | Sharing daily inspiration
🎯 Helping you grow and succeed  
📩 DM for collaborations`;
    
    await cache.set(cacheKey, fallbackBio, CACHE_DURATION);
    return fallbackBio;
  }

  const prompt = `Write a compelling ${platform} bio for someone in the ${niche} space.

Personality: ${personalityGuide[personality] || personality}
Platform: ${platform} (${platformLimits[platform] || 'concise'})

Requirements:
- Include strategic emojis (2-4 max)
- Clear value proposition in first line
- Show personality while staying professional
- Include a soft call-to-action
- Use line breaks for readability
- Avoid clichés like "Living my best life" or "Just a [niche] enthusiast"`;

  const response = await openai!.chat.completions.create({
    model: 'gpt-4',
    messages: [
      {
        role: 'system',
        content: 'You are a branding expert who writes compelling social media bios that convert profile visitors to followers.',
      },
      { role: 'user', content: prompt },
    ],
    temperature: 0.8,
    max_tokens: 200,
  });

  const bio = response.choices[0]?.message?.content?.trim() || '';

  // Cache result
  await cache.set(cacheKey, bio, CACHE_DURATION);

  return bio;
}

// Generate content ideas
export async function generateContentIdeas(
  niche: string,
  count: number = 5
): Promise<Array<{ title: string; description: string; format: string; hook: string }>> {
  const cacheKey = `ideas:${Buffer.from(niche).toString('base64').slice(0, 32)}:${count}`;
  
  // Check cache
  const cached = await cache.get<Array<{ title: string; description: string; format: string; hook: string }>>(cacheKey);
  if (cached) return cached;

  if (!isOpenAIConfigured()) {
    const fallbackIdeas = [
      {
        title: 'Behind the Scenes',
        description: 'Show your creative process and workflow',
        format: 'Carousel/Reels',
        hook: 'POV: The reality behind the perfect post',
      },
      {
        title: 'Myth Busting',
        description: 'Debunk common misconceptions in your niche',
        format: 'Video/Reels',
        hook: 'Stop believing this lie about [topic]',
      },
      {
        title: 'Day in the Life',
        description: 'A typical day in your world',
        format: 'Reels/TikTok',
        hook: 'A day in my life as a [profession]',
      },
      {
        title: 'Tutorial/Tips',
        description: 'Teach something valuable to your audience',
        format: 'Carousel/Video',
        hook: 'Save this! 5 tips that changed everything',
      },
      {
        title: 'Transformation',
        description: 'Before and after results',
        format: 'Reels/Carousel',
        hook: 'The transformation that took 6 months',
      },
    ].slice(0, count);
    
    await cache.set(cacheKey, fallbackIdeas, CACHE_DURATION);
    return fallbackIdeas;
  }

  const prompt = `Generate ${count} creative content ideas for a ${niche} creator.

For each idea, provide:
1. Title - catchy, clickable title
2. Description - what the content is about (1-2 sentences)
3. Format - best platform format (Reels, Carousel, Story, Live, etc.)
4. Hook - attention-grabbing opening line/hook

Make ideas:
- Specific to the ${niche} niche
- Trending format-friendly
- Engagement-optimized
- Actionable and clear

Return as a JSON array with objects containing: title, description, format, hook`;

  const response = await openai!.chat.completions.create({
    model: 'gpt-4',
    messages: [
      {
        role: 'system',
        content: 'You are a content strategist who creates viral content ideas. Be specific, creative, and trend-aware.',
      },
      { role: 'user', content: prompt },
    ],
    temperature: 0.9,
    max_tokens: 800,
    response_format: { type: 'json_object' },
  });

  try {
    const content = response.choices[0]?.message?.content || '{"ideas": []}';
    const parsed = JSON.parse(content);
    const ideas = parsed.ideas || [];

    // Cache result
    await cache.set(cacheKey, ideas, CACHE_DURATION);

    return ideas;
  } catch {
    return [];
  }
}

// Generate video script
export async function generateVideoScript(
  topic: string,
  duration: number = 60,
  style: string = 'educational'
): Promise<{ hook: string; body: string[]; cta: string; captions: string[] }> {
  const cacheKey = `script:${style}:${duration}:${Buffer.from(topic).toString('base64').slice(0, 32)}`;
  
  // Check cache
  const cached = await cache.get<{ hook: string; body: string[]; cta: string; captions: string[] }>(cacheKey);
  if (cached) return cached;

  const styleGuide: Record<string, string> = {
    educational: 'informative, teaches something valuable, facts and insights',
    entertaining: 'fun, engaging, uses humor, keeps attention',
    inspirational: 'motivational, emotional, storytelling-driven',
    promotional: 'sells a product/service, highlights benefits, persuasive',
    storytelling: 'narrative arc, personal experience, relatable journey',
  };

  const wordCount = Math.floor(duration * 2.5); // Average speaking rate

  if (!isOpenAIConfigured()) {
    const fallbackScript = {
      hook: `Ever wondered about ${topic}? Let me blow your mind.`,
      body: [
        `Here's what most people get wrong about ${topic}.`,
        `The truth is actually surprising.`,
        `Let me break it down for you in simple terms.`,
      ],
      cta: 'Follow for more insights like this! What topic should I cover next?',
      captions: [
        'POV: You just learned something new',
        'This changes everything',
        'Save this for later!',
      ],
    };
    
    await cache.set(cacheKey, fallbackScript, CACHE_DURATION);
    return fallbackScript;
  }

  const prompt = `Write a ${duration}-second video script about "${topic}" in a ${style} style.

Style: ${styleGuide[style] || style}
Target word count: ~${wordCount} words (for ${duration} seconds)

Structure:
1. HOOK (3-5 seconds) - Stop-the-scroll opening that creates curiosity
2. BODY (45-50 seconds) - 3-4 key points, each with a visual cue
3. CTA (3-5 seconds) - Strong call-to-action

Also provide 3 on-screen caption/text overlay suggestions.

Return as JSON with:
- hook: the opening line
- body: array of 3-4 key point scripts
- cta: call-to-action
- captions: array of 3 caption ideas`;

  const response = await openai!.chat.completions.create({
    model: 'gpt-4',
    messages: [
      {
        role: 'system',
        content: 'You are a viral video scriptwriter. Create scripts that hook viewers in 3 seconds and keep them watching till the end.',
      },
      { role: 'user', content: prompt },
    ],
    temperature: 0.8,
    max_tokens: 600,
    response_format: { type: 'json_object' },
  });

  try {
    const content = response.choices[0]?.message?.content || '{}';
    const script = JSON.parse(content);

    // Cache result
    await cache.set(cacheKey, script, CACHE_DURATION);

    return script;
  } catch {
    return { hook: '', body: [], cta: '', captions: [] };
  }
}

// Analyze engagement
export async function analyzeEngagement(
  posts: Array<{ likes: number; comments: number; shares: number; saves: number; views: number }>
): Promise<{
  averageEngagement: number;
  engagementRate: number;
  bestPerforming: number;
  recommendations: string[];
}> {
  if (posts.length === 0) {
    return {
      averageEngagement: 0,
      engagementRate: 0,
      bestPerforming: 0,
      recommendations: ['Start posting consistently to get engagement data'],
    };
  }

  const totalEngagement = posts.reduce(
    (sum, post) => sum + post.likes + post.comments + post.shares + post.saves,
    0
  );
  const averageEngagement = totalEngagement / posts.length;
  const totalViews = posts.reduce((sum, post) => sum + post.views, 0);
  const engagementRate = totalViews > 0 ? (totalEngagement / totalViews) * 100 : 0;

  // Find best performing post
  const engagements = posts.map(
    (post) => post.likes + post.comments + post.shares + post.saves
  );
  const bestPerforming = Math.max(...engagements);

  // Generate recommendations
  const recommendations: string[] = [];

  if (engagementRate < 3) {
    recommendations.push('Your engagement rate is below average. Try using more hooks in your captions.');
  }
  if (posts.some((p) => p.saves < p.likes * 0.1)) {
    recommendations.push('Create more save-worthy content (tips, tutorials, resources).');
  }
  if (posts.some((p) => p.comments < p.likes * 0.05)) {
    recommendations.push('Ask questions in your captions to boost comments.');
  }

  if (recommendations.length === 0) {
    recommendations.push('Great engagement! Keep experimenting with different content types.');
  }

  return {
    averageEngagement: Math.round(averageEngagement),
    engagementRate: Math.round(engagementRate * 100) / 100,
    bestPerforming,
    recommendations,
  };
}

export default {
  generateHashtags,
  generateCaption,
  generateBio,
  generateContentIdeas,
  generateVideoScript,
  analyzeEngagement,
};
