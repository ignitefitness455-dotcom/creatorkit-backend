import { Queue, Worker, Job } from 'bullmq';
import { redis } from '../config/redis';
import { prisma } from '../config/database';
import pdfService from './pdfService';
import imageService from './imageService';
import { JobType, JobStatus } from '../types';
import fs from 'fs/promises';

// Check if Redis is properly configured
const hasRedis = redis.status !== undefined;

// Job queues - use mock if Redis not available
const createQueue = (name: string, options: any) => {
  if (!hasRedis) {
    console.log(`ℹ️  Redis not available, ${name} queue will process synchronously`);
    // Return a mock queue that processes immediately
    return {
      name,
      add: async (jobName: string, data: any, opts?: any) => {
        const jobId = opts?.jobId || `${jobName}-${Date.now()}`;
        // Process immediately
        setImmediate(() => processJobDirectly(jobId, jobName as JobType, data));
        return { id: jobId, name: jobName, data } as any;
      },
      getJob: async () => null,
      getWaitingCount: async () => 0,
      getActiveCount: async () => 0,
      getCompletedCount: async () => 0,
      getFailedCount: async () => 0,
    } as any;
  }
  return new Queue(name, { connection: redis, ...options });
};

// Process job directly without queue (fallback mode)
async function processJobDirectly(jobId: string, type: JobType, data: any) {
  try {
    // Create job record
    await prisma.job.create({
      data: {
        id: jobId,
        type,
        status: JobStatus.PROCESSING,
        data,
        userId: data.userId,
        startedAt: new Date(),
      },
    });

    let result: any;
    
    // Process based on type
    switch (type) {
      case JobType.PDF_MERGE:
        result = await processPdfMergeDirectly(data);
        break;
      case JobType.PDF_SPLIT:
        result = await processPdfSplitDirectly(data);
        break;
      case JobType.PDF_COMPRESS:
        result = await processPdfCompressDirectly(data);
        break;
      case JobType.IMAGE_COMPRESS:
        result = await processImageCompressDirectly(data);
        break;
      default:
        throw new Error(`Direct processing not implemented for ${type}`);
    }

    // Update as completed
    await prisma.job.update({
      where: { id: jobId },
      data: {
        status: JobStatus.COMPLETED,
        result,
        progress: 100,
        completedAt: new Date(),
      },
    });
  } catch (error: any) {
    await prisma.job.update({
      where: { id: jobId },
      data: {
        status: JobStatus.FAILED,
        error: error.message,
        completedAt: new Date(),
      },
    });
  }
}

// Direct processing functions
async function processPdfMergeDirectly(data: any) {
  const { filePaths, userId } = data;
  const result = await pdfService.mergePDFs(filePaths);
  const upload = await pdfService.uploadToS3(result.filePath, userId, result.fileName);
  await pdfService.cleanupTempFiles([...filePaths, result.filePath]);
  return { fileName: result.fileName, size: result.size, downloadUrl: upload.s3Url };
}

async function processPdfSplitDirectly(data: any) {
  const { filePath, pages, userId } = data;
  const result = await pdfService.splitPDF(filePath, pages);
  const upload = await pdfService.uploadToS3(result.filePath, userId, result.fileName);
  await pdfService.cleanupTempFiles([filePath, result.filePath]);
  return { fileName: result.fileName, size: result.size, downloadUrl: upload.s3Url };
}

async function processPdfCompressDirectly(data: any) {
  const { filePath, quality, userId } = data;
  const result = await pdfService.compressPDF(filePath, quality);
  const upload = await pdfService.uploadToS3(result.filePath, userId, result.fileName);
  await pdfService.cleanupTempFiles([filePath, result.filePath]);
  return { fileName: result.fileName, size: result.size, downloadUrl: upload.s3Url };
}

async function processImageCompressDirectly(data: any) {
  const { filePath, quality, userId } = data;
  const result = await imageService.compressImage(filePath, quality);
  const upload = await imageService.uploadToS3(result.filePath, userId, result.fileName);
  await imageService.cleanupTempFiles([filePath, result.filePath]);
  return { fileName: result.fileName, size: result.size, downloadUrl: upload.s3Url };
}

export const fileProcessingQueue = createQueue('file-processing', {
  defaultJobOptions: {
    attempts: 3,
    backoff: { type: 'exponential', delay: 5000 },
    removeOnComplete: 100,
    removeOnFail: 50,
  },
});

export const aiProcessingQueue = createQueue('ai-processing', {
  defaultJobOptions: {
    attempts: 2,
    backoff: { type: 'fixed', delay: 10000 },
    removeOnComplete: 50,
    removeOnFail: 20,
  },
});

export const emailQueue = createQueue('email', {
  defaultJobOptions: {
    attempts: 3,
    backoff: { type: 'exponential', delay: 5000 },
    removeOnComplete: 200,
    removeOnFail: 50,
  },
});

// Add job to queue
export async function addJob(
  queue: Queue,
  type: JobType,
  data: Record<string, unknown>,
  options: {
    priority?: number;
    delay?: number;
    jobId?: string;
  } = {}
): Promise<Job> {
  const job = await queue.add(type, data, {
    ...options,
    jobId: options.jobId || `${type}-${Date.now()}`,
  });

  // Create job record in database
  await prisma.job.create({
    data: {
      id: job.id!,
      type,
      status: JobStatus.PENDING,
      data,
      userId: data.userId as string | undefined,
    },
  });

  return job;
}

// Get job status
export async function getJobStatus(jobId: string): Promise<{
  id: string;
  status: JobStatus;
  progress: number;
  result?: unknown;
  error?: string;
}> {
  // Check in all queues
  const queues = [fileProcessingQueue, aiProcessingQueue, emailQueue];
  
  for (const queue of queues) {
    const job = await queue.getJob(jobId);
    if (job) {
      const state = await job.getState();
      return {
        id: job.id!,
        status: state as JobStatus,
        progress: job.progress || 0,
        result: job.returnvalue,
        error: job.failedReason,
      };
    }
  }

  // Check database
  const dbJob = await prisma.job.findUnique({
    where: { id: jobId },
  });

  if (dbJob) {
    return {
      id: dbJob.id,
      status: dbJob.status,
      progress: dbJob.progress,
      result: dbJob.result || undefined,
      error: dbJob.error || undefined,
    };
  }

  throw new Error('Job not found');
}

// Update job progress
export async function updateJobProgress(
  jobId: string,
  progress: number
): Promise<void> {
  await prisma.job.update({
    where: { id: jobId },
    data: { progress },
  });
}

// File processing worker - only create if Redis is available
export const fileProcessingWorker = hasRedis ? new Worker(
  'file-processing',
  async (job: Job) => {
    const { type, data } = job;
    const startTime = Date.now();

    console.log(`Processing job ${job.id} of type ${type}`);

    // Update status to processing
    await prisma.job.update({
      where: { id: job.id },
      data: { 
        status: JobStatus.PROCESSING,
        startedAt: new Date(),
      },
    });

    try {
      let result: unknown;

      switch (type) {
        case JobType.PDF_MERGE:
          result = await handlePdfMerge(data);
          break;
        case JobType.PDF_SPLIT:
          result = await handlePdfSplit(data);
          break;
        case JobType.PDF_COMPRESS:
          result = await handlePdfCompress(data);
          break;
        case JobType.PDF_CONVERT:
          result = await handlePdfConvert(data);
          break;
        case JobType.PDF_ROTATE:
          result = await handlePdfRotate(data);
          break;
        case JobType.IMAGE_COMPRESS:
          result = await handleImageCompress(data);
          break;
        case JobType.IMAGE_UPSCALE:
          result = await handleImageUpscale(data);
          break;
        case JobType.IMAGE_CONVERT:
          result = await handleImageConvert(data);
          break;
        case JobType.IMAGE_REMOVE_BG:
          result = await handleImageRemoveBg(data);
          break;
        default:
          throw new Error(`Unknown job type: ${type}`);
      }

      // Update job as completed
      await prisma.job.update({
        where: { id: job.id },
        data: {
          status: JobStatus.COMPLETED,
          result: result as any,
          progress: 100,
          completedAt: new Date(),
        },
      });

      // Update user usage
      if (data.userId) {
        await updateUserUsage(data.userId as string, type);
      }

      console.log(`Job ${job.id} completed in ${Date.now() - startTime}ms`);

      return result;
    } catch (error: any) {
      console.error(`Job ${job.id} failed:`, error);

      // Update job as failed
      await prisma.job.update({
        where: { id: job.id },
        data: {
          status: JobStatus.FAILED,
          error: error.message,
          completedAt: new Date(),
        },
      });

      throw error;
    }
  },
  {
    connection: redis,
    concurrency: 5,
  }
) : null;

// PDF merge handler
async function handlePdfMerge(data: Record<string, unknown>) {
  const { filePaths, outputName, userId } = data as {
    filePaths: string[];
    outputName?: string;
    userId: string;
  };

  const result = await pdfService.mergePDFs(filePaths, outputName);
  
  // Upload to S3
  const upload = await pdfService.uploadToS3(
    result.filePath,
    userId,
    result.fileName
  );

  // Cleanup temp files
  await pdfService.cleanupTempFiles([...filePaths, result.filePath]);

  return {
    fileName: result.fileName,
    size: result.size,
    pageCount: result.pageCount,
    downloadUrl: upload.s3Url,
  };
}

// PDF split handler
async function handlePdfSplit(data: Record<string, unknown>) {
  const { filePath, pages, userId } = data as {
    filePath: string;
    pages: number[];
    userId: string;
  };

  const result = await pdfService.splitPDF(filePath, pages);
  
  const upload = await pdfService.uploadToS3(
    result.filePath,
    userId,
    result.fileName
  );

  await pdfService.cleanupTempFiles([filePath, result.filePath]);

  return {
    fileName: result.fileName,
    size: result.size,
    pageCount: result.pageCount,
    downloadUrl: upload.s3Url,
  };
}

// PDF compress handler
async function handlePdfCompress(data: Record<string, unknown>) {
  const { filePath, quality, userId } = data as {
    filePath: string;
    quality: 'low' | 'medium' | 'high';
    userId: string;
  };

  const result = await pdfService.compressPDF(filePath, quality);
  
  const upload = await pdfService.uploadToS3(
    result.filePath,
    userId,
    result.fileName
  );

  await pdfService.cleanupTempFiles([filePath, result.filePath]);

  return {
    fileName: result.fileName,
    size: result.size,
    pageCount: result.pageCount,
    downloadUrl: upload.s3Url,
  };
}

// PDF convert handler
async function handlePdfConvert(data: Record<string, unknown>) {
  const { filePath, format, userId } = data as {
    filePath: string;
    format: 'png' | 'jpeg';
    userId: string;
  };

  const results = await pdfService.convertPDFToImages(filePath, format);
  
  const uploads = await Promise.all(
    results.map((result) =>
      pdfService.uploadToS3(result.filePath, userId, result.fileName)
    )
  );

  await pdfService.cleanupTempFiles([filePath, ...results.map((r) => r.filePath)]);

  return {
    images: results.map((result, index) => ({
      fileName: result.fileName,
      size: result.size,
      downloadUrl: uploads[index].s3Url,
    })),
  };
}

// PDF rotate handler
async function handlePdfRotate(data: Record<string, unknown>) {
  const { filePath, rotation, pages, userId } = data as {
    filePath: string;
    rotation: 90 | 180 | 270;
    pages?: number[];
    userId: string;
  };

  const result = await pdfService.rotatePDF(filePath, rotation, pages);
  
  const upload = await pdfService.uploadToS3(
    result.filePath,
    userId,
    result.fileName
  );

  await pdfService.cleanupTempFiles([filePath, result.filePath]);

  return {
    fileName: result.fileName,
    size: result.size,
    pageCount: result.pageCount,
    downloadUrl: upload.s3Url,
  };
}

// Image compress handler
async function handleImageCompress(data: Record<string, unknown>) {
  const { filePath, quality, userId } = data as {
    filePath: string;
    quality: number;
    userId: string;
  };

  const result = await imageService.compressImage(filePath, quality);
  
  const upload = await imageService.uploadToS3(
    result.filePath,
    userId,
    result.fileName
  );

  await imageService.cleanupTempFiles([filePath, result.filePath]);

  return {
    fileName: result.fileName,
    size: result.size,
    width: result.width,
    height: result.height,
    downloadUrl: upload.s3Url,
  };
}

// Image upscale handler
async function handleImageUpscale(data: Record<string, unknown>) {
  const { filePath, scale, userId } = data as {
    filePath: string;
    scale: 2 | 4;
    userId: string;
  };

  const result = await imageService.upscaleImage(filePath, scale);
  
  const upload = await imageService.uploadToS3(
    result.filePath,
    userId,
    result.fileName
  );

  await imageService.cleanupTempFiles([filePath, result.filePath]);

  return {
    fileName: result.fileName,
    size: result.size,
    width: result.width,
    height: result.height,
    downloadUrl: upload.s3Url,
  };
}

// Image convert handler
async function handleImageConvert(data: Record<string, unknown>) {
  const { filePath, format, quality, userId } = data as {
    filePath: string;
    format: 'jpeg' | 'png' | 'webp' | 'gif' | 'avif' | 'tiff';
    quality: number;
    userId: string;
  };

  const result = await imageService.convertImage(filePath, format, quality);
  
  const upload = await imageService.uploadToS3(
    result.filePath,
    userId,
    result.fileName
  );

  await imageService.cleanupTempFiles([filePath, result.filePath]);

  return {
    fileName: result.fileName,
    size: result.size,
    width: result.width,
    height: result.height,
    downloadUrl: upload.s3Url,
  };
}

// Image remove background handler
async function handleImageRemoveBg(data: Record<string, unknown>) {
  const { filePath, userId } = data as {
    filePath: string;
    userId: string;
  };

  const result = await imageService.removeBackground(filePath);
  
  const upload = await imageService.uploadToS3(
    result.filePath,
    userId,
    result.fileName
  );

  await imageService.cleanupTempFiles([filePath, result.filePath]);

  return {
    fileName: result.fileName,
    size: result.size,
    width: result.width,
    height: result.height,
    downloadUrl: upload.s3Url,
  };
}

// Update user usage
async function updateUserUsage(userId: string, jobType: JobType): Promise<void> {
  const usageField = getUsageField(jobType);
  
  await prisma.usage.updateMany({
    where: { userId },
    data: {
      [usageField]: { increment: 1 },
      totalOperations: { increment: 1 },
    },
  });
}

// Get usage field name from job type
function getUsageField(jobType: JobType): string {
  switch (jobType) {
    case JobType.PDF_MERGE:
    case JobType.PDF_SPLIT:
    case JobType.PDF_COMPRESS:
    case JobType.PDF_CONVERT:
    case JobType.PDF_ROTATE:
    case JobType.PDF_ESIGN:
      return 'pdfOperations';
    case JobType.IMAGE_COMPRESS:
    case JobType.IMAGE_UPSCALE:
    case JobType.IMAGE_CONVERT:
    case JobType.IMAGE_REMOVE_BG:
      return 'imageOperations';
    case JobType.AI_GENERATE:
      return 'aiOperations';
    default:
      return 'apiCalls';
  }
}

// Worker event handlers (only if worker exists)
if (fileProcessingWorker) {
  fileProcessingWorker.on('completed', (job) => {
    console.log(`Job ${job.id} completed successfully`);
  });

  fileProcessingWorker.on('failed', (job, err) => {
    console.error(`Job ${job?.id} failed:`, err);
  });
}

// Cleanup old jobs periodically
export async function cleanupOldJobs(): Promise<void> {
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

  await prisma.job.deleteMany({
    where: {
      createdAt: {
        lt: thirtyDaysAgo,
      },
    },
  });

  console.log('Cleaned up old jobs');
}

// Queue health check
export async function checkQueueHealth(): Promise<{
  fileProcessing: { waiting: number; active: number; completed: number; failed: number };
  aiProcessing: { waiting: number; active: number; completed: number; failed: number };
  email: { waiting: number; active: number; completed: number; failed: number };
}> {
  return {
    fileProcessing: {
      waiting: await fileProcessingQueue.getWaitingCount?.() || 0,
      active: await fileProcessingQueue.getActiveCount?.() || 0,
      completed: await fileProcessingQueue.getCompletedCount?.() || 0,
      failed: await fileProcessingQueue.getFailedCount?.() || 0,
    },
    aiProcessing: {
      waiting: await aiProcessingQueue.getWaitingCount?.() || 0,
      active: await aiProcessingQueue.getActiveCount?.() || 0,
      completed: await aiProcessingQueue.getCompletedCount?.() || 0,
      failed: await aiProcessingQueue.getFailedCount?.() || 0,
    },
    email: {
      waiting: await emailQueue.getWaitingCount?.() || 0,
      active: await emailQueue.getActiveCount?.() || 0,
      completed: await emailQueue.getCompletedCount?.() || 0,
      failed: await emailQueue.getFailedCount?.() || 0,
    },
  };
}

export default {
  fileProcessingQueue,
  aiProcessingQueue,
  emailQueue,
  addJob,
  getJobStatus,
  updateJobProgress,
  cleanupOldJobs,
  checkQueueHealth,
};
