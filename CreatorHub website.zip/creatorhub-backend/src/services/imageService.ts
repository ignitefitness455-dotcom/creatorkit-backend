import sharp from 'sharp';
import fs from 'fs/promises';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import { s3Client, generateS3Key, S3_BUCKET } from '../config/s3';
import { PutObjectCommand } from '@aws-sdk/client-s3';
import { env } from '../config/env';

// Process result interface
interface ProcessResult {
  filePath: string;
  fileName: string;
  mimeType: string;
  size: number;
  width?: number;
  height?: number;
}

// Image info interface
interface ImageInfo {
  width: number;
  height: number;
  format: string;
  size: number;
  hasAlpha: boolean;
  channels: number;
}

// Get image info
export async function getImageInfo(filePath: string): Promise<ImageInfo> {
  const metadata = await sharp(filePath).metadata();
  const stats = await fs.stat(filePath);

  return {
    width: metadata.width || 0,
    height: metadata.height || 0,
    format: metadata.format || 'unknown',
    size: stats.size,
    hasAlpha: metadata.hasAlpha || false,
    channels: metadata.channels || 0,
  };
}

// Compress image
export async function compressImage(
  filePath: string,
  quality: number = 80,
  format?: 'jpeg' | 'png' | 'webp'
): Promise<ProcessResult> {
  const info = await getImageInfo(filePath);
  const targetFormat = format || (info.format as 'jpeg' | 'png' | 'webp') || 'jpeg';
  
  const outputFileName = `compressed-${uuidv4()}.${targetFormat}`;
  const outputPath = path.join(process.cwd(), 'uploads', 'temp', outputFileName);

  let pipeline = sharp(filePath);

  switch (targetFormat) {
    case 'jpeg':
      pipeline = pipeline.jpeg({ quality, progressive: true, mozjpeg: true });
      break;
    case 'png':
      pipeline = pipeline.png({ 
        quality: Math.min(quality, 90),
        compressionLevel: 9,
        progressive: true 
      });
      break;
    case 'webp':
      pipeline = pipeline.webp({ quality, effort: 6 });
      break;
  }

  await pipeline.toFile(outputPath);

  const stats = await fs.stat(outputPath);
  const outputMetadata = await sharp(outputPath).metadata();

  return {
    filePath: outputPath,
    fileName: outputFileName,
    mimeType: `image/${targetFormat}`,
    size: stats.size,
    width: outputMetadata.width,
    height: outputMetadata.height,
  };
}

// Upscale image (using sharp's resize with different kernels)
export async function upscaleImage(
  filePath: string,
  scale: 2 | 4 = 2
): Promise<ProcessResult> {
  const info = await getImageInfo(filePath);
  const outputFormat = info.format || 'png';
  
  const outputFileName = `upscaled-${uuidv4()}.${outputFormat}`;
  const outputPath = path.join(process.cwd(), 'uploads', 'temp', outputFileName);

  const newWidth = info.width * scale;
  const newHeight = info.height * scale;

  await sharp(filePath)
    .resize(newWidth, newHeight, {
      kernel: sharp.kernel.lanczos3,
      fit: 'contain',
    })
    .toFile(outputPath);

  const stats = await fs.stat(outputPath);
  const outputMetadata = await sharp(outputPath).metadata();

  return {
    filePath: outputPath,
    fileName: outputFileName,
    mimeType: `image/${outputFormat}`,
    size: stats.size,
    width: outputMetadata.width,
    height: outputMetadata.height,
  };
}

// Convert image format
export async function convertImage(
  filePath: string,
  targetFormat: 'jpeg' | 'png' | 'webp' | 'gif' | 'avif' | 'tiff',
  quality: number = 90
): Promise<ProcessResult> {
  const outputFileName = `converted-${uuidv4()}.${targetFormat}`;
  const outputPath = path.join(process.cwd(), 'uploads', 'temp', outputFileName);

  let pipeline = sharp(filePath);

  switch (targetFormat) {
    case 'jpeg':
      pipeline = pipeline.jpeg({ quality, progressive: true });
      break;
    case 'png':
      pipeline = pipeline.png({ quality: Math.min(quality, 90), compressionLevel: 9 });
      break;
    case 'webp':
      pipeline = pipeline.webp({ quality });
      break;
    case 'gif':
      pipeline = pipeline.gif();
      break;
    case 'avif':
      pipeline = pipeline.avif({ quality });
      break;
    case 'tiff':
      pipeline = pipeline.tiff({ quality });
      break;
  }

  await pipeline.toFile(outputPath);

  const stats = await fs.stat(outputPath);
  const outputMetadata = await sharp(outputPath).metadata();

  return {
    filePath: outputPath,
    fileName: outputFileName,
    mimeType: `image/${targetFormat}`,
    size: stats.size,
    width: outputMetadata.width,
    height: outputMetadata.height,
  };
}

// Remove background (mock implementation - would use external API like Remove.bg)
export async function removeBackground(filePath: string): Promise<ProcessResult> {
  // In a real implementation, this would call an external API like Remove.bg
  // For now, we'll just make the image transparent where it's white/close to white
  
  const info = await getImageInfo(filePath);
  const outputFileName = `nobg-${uuidv4()}.png`;
  const outputPath = path.join(process.cwd(), 'uploads', 'temp', outputFileName);

  // Simple background removal by making white/transparent pixels transparent
  // This is a basic implementation - real bg removal requires ML models
  await sharp(filePath)
    .ensureAlpha()
    .raw()
    .toBuffer({ resolveWithObject: true })
    .then(({ data, info }) => {
      // Simple threshold-based background removal
      for (let i = 0; i < data.length; i += info.channels) {
        const r = data[i];
        const g = data[i + 1];
        const b = data[i + 2];
        
        // If pixel is close to white, make it transparent
        const whiteness = (r + g + b) / 3;
        if (whiteness > 240) {
          data[i + 3] = 0; // Set alpha to 0
        }
      }
      
      return sharp(data, {
        raw: {
          width: info.width,
          height: info.height,
          channels: info.channels,
        },
      }).png().toFile(outputPath);
    });

  const stats = await fs.stat(outputPath);
  const outputMetadata = await sharp(outputPath).metadata();

  return {
    filePath: outputPath,
    fileName: outputFileName,
    mimeType: 'image/png',
    size: stats.size,
    width: outputMetadata.width,
    height: outputMetadata.height,
  };
}

// Resize image
export async function resizeImage(
  filePath: string,
  width?: number,
  height?: number,
  fit: 'cover' | 'contain' | 'fill' | 'inside' | 'outside' = 'contain'
): Promise<ProcessResult> {
  const info = await getImageInfo(filePath);
  const outputFormat = info.format || 'jpeg';
  
  const outputFileName = `resized-${uuidv4()}.${outputFormat}`;
  const outputPath = path.join(process.cwd(), 'uploads', 'temp', outputFileName);

  await sharp(filePath)
    .resize(width, height, { fit })
    .toFile(outputPath);

  const stats = await fs.stat(outputPath);
  const outputMetadata = await sharp(outputPath).metadata();

  return {
    filePath: outputPath,
    fileName: outputFileName,
    mimeType: `image/${outputFormat}`,
    size: stats.size,
    width: outputMetadata.width,
    height: outputMetadata.height,
  };
}

// Crop image
export async function cropImage(
  filePath: string,
  left: number,
  top: number,
  width: number,
  height: number
): Promise<ProcessResult> {
  const info = await getImageInfo(filePath);
  const outputFormat = info.format || 'jpeg';
  
  const outputFileName = `cropped-${uuidv4()}.${outputFormat}`;
  const outputPath = path.join(process.cwd(), 'uploads', 'temp', outputFileName);

  await sharp(filePath)
    .extract({ left, top, width, height })
    .toFile(outputPath);

  const stats = await fs.stat(outputPath);
  const outputMetadata = await sharp(outputPath).metadata();

  return {
    filePath: outputPath,
    fileName: outputFileName,
    mimeType: `image/${outputFormat}`,
    size: stats.size,
    width: outputMetadata.width,
    height: outputMetadata.height,
  };
}

// Rotate image
export async function rotateImage(
  filePath: string,
  angle: number
): Promise<ProcessResult> {
  const info = await getImageInfo(filePath);
  const outputFormat = info.format || 'jpeg';
  
  const outputFileName = `rotated-${uuidv4()}.${outputFormat}`;
  const outputPath = path.join(process.cwd(), 'uploads', 'temp', outputFileName);

  await sharp(filePath)
    .rotate(angle)
    .toFile(outputPath);

  const stats = await fs.stat(outputPath);
  const outputMetadata = await sharp(outputPath).metadata();

  return {
    filePath: outputPath,
    fileName: outputFileName,
    mimeType: `image/${outputFormat}`,
    size: stats.size,
    width: outputMetadata.width,
    height: outputMetadata.height,
  };
}

// Apply filters/effects
export async function applyFilter(
  filePath: string,
  filter: 'grayscale' | 'sepia' | 'blur' | 'sharpen' | 'negate'
): Promise<ProcessResult> {
  const info = await getImageInfo(filePath);
  const outputFormat = info.format || 'jpeg';
  
  const outputFileName = `filtered-${uuidv4()}.${outputFormat}`;
  const outputPath = path.join(process.cwd(), 'uploads', 'temp', outputFileName);

  let pipeline = sharp(filePath);

  switch (filter) {
    case 'grayscale':
      pipeline = pipeline.grayscale();
      break;
    case 'sepia':
      pipeline = pipeline.sepia();
      break;
    case 'blur':
      pipeline = pipeline.blur(5);
      break;
    case 'sharpen':
      pipeline = pipeline.sharpen({ sigma: 2, flat: 1, jagged: 2 });
      break;
    case 'negate':
      pipeline = pipeline.negate();
      break;
  }

  await pipeline.toFile(outputPath);

  const stats = await fs.stat(outputPath);
  const outputMetadata = await sharp(outputPath).metadata();

  return {
    filePath: outputPath,
    fileName: outputFileName,
    mimeType: `image/${outputFormat}`,
    size: stats.size,
    width: outputMetadata.width,
    height: outputMetadata.height,
  };
}

// Extract color palette
export async function extractColors(
  filePath: string,
  count: number = 5
): Promise<Array<{ hex: string; rgb: number[]; percentage: number }>> {
  const { dominant, palette } = await sharp(filePath).stats();
  
  // Get raw pixel data for more accurate color extraction
  const { data, info } = await sharp(filePath)
    .raw()
    .toBuffer({ resolveWithObject: true });

  // Simple color quantization (could be improved with k-means)
  const colorMap = new Map<string, number>();
  
  for (let i = 0; i < data.length; i += info.channels) {
    const r = Math.round(data[i] / 32) * 32;
    const g = Math.round(data[i + 1] / 32) * 32;
    const b = Math.round(data[i + 2] / 32) * 32;
    
    const hex = `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
    colorMap.set(hex, (colorMap.get(hex) || 0) + 1);
  }

  // Sort by frequency and get top colors
  const sortedColors = Array.from(colorMap.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, count);

  const totalPixels = data.length / info.channels;

  return sortedColors.map(([hex, count]) => ({
    hex,
    rgb: [
      parseInt(hex.slice(1, 3), 16),
      parseInt(hex.slice(3, 5), 16),
      parseInt(hex.slice(5, 7), 16),
    ],
    percentage: Math.round((count / totalPixels) * 100),
  }));
}

// Take screenshot (mock - would use puppeteer or similar)
export async function takeScreenshot(
  url: string,
  options: {
    width?: number;
    height?: number;
    fullPage?: boolean;
    format?: 'png' | 'jpeg';
  } = {}
): Promise<ProcessResult> {
  // This is a placeholder - real implementation would use Puppeteer or Playwright
  throw new Error('Screenshot functionality requires Puppeteer/Playwright setup');
}

// Upload processed image to S3 or local storage
export async function uploadToS3(
  filePath: string,
  userId: string,
  originalName: string
): Promise<{ s3Key: string; s3Url: string }> {
  const fileContent = await fs.readFile(filePath);
  const s3Key = generateS3Key(userId, originalName);

  // If S3 not configured, save locally
  if (!s3Client) {
    const { saveFileLocally } = await import('../config/s3');
    const { url } = await saveFileLocally(fileContent, originalName);
    return { s3Key, s3Url: url };
  }

  const mimeType = path.extname(originalName).toLowerCase() === '.png' 
    ? 'image/png' 
    : 'image/jpeg';

  await s3Client.send(
    new PutObjectCommand({
      Bucket: S3_BUCKET,
      Key: s3Key,
      Body: fileContent,
      ContentType: mimeType,
    })
  );

  const s3Url = `${env.API_URL}/api/files/download/${path.basename(s3Key)}`;

  return { s3Key, s3Url };
}

// Cleanup temp files
export async function cleanupTempFiles(filePaths: string[]): Promise<void> {
  for (const filePath of filePaths) {
    try {
      await fs.unlink(filePath);
    } catch (err) {
      console.error(`Failed to cleanup file ${filePath}:`, err);
    }
  }
}

export default {
  getImageInfo,
  compressImage,
  upscaleImage,
  convertImage,
  removeBackground,
  resizeImage,
  cropImage,
  rotateImage,
  applyFilter,
  extractColors,
  takeScreenshot,
  uploadToS3,
  cleanupTempFiles,
};
