import { PDFDocument, PDFPage, PDFEmbeddedPage, Rotation } from 'pdf-lib';
import fs from 'fs/promises';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import { fromPath } from 'pdf2pic';
import { s3Client, generateUploadUrl, generateS3Key, S3_BUCKET } from '../config/s3';
import { PutObjectCommand } from '@aws-sdk/client-s3';
import { env } from '../config/env';

// Process result interface
interface ProcessResult {
  filePath: string;
  fileName: string;
  mimeType: string;
  size: number;
  pageCount?: number;
}

// Merge PDFs
export async function mergePDFs(
  filePaths: string[],
  outputName?: string
): Promise<ProcessResult> {
  const mergedPdf = await PDFDocument.create();

  for (const filePath of filePaths) {
    const pdfBytes = await fs.readFile(filePath);
    const pdf = await PDFDocument.load(pdfBytes);
    const pages = await mergedPdf.copyPages(pdf, pdf.getPageIndices());
    pages.forEach((page) => mergedPdf.addPage(page));
  }

  const mergedPdfBytes = await mergedPdf.save();
  
  const outputFileName = outputName || `merged-${uuidv4()}.pdf`;
  const outputPath = path.join(process.cwd(), 'uploads', 'temp', outputFileName);
  
  await fs.writeFile(outputPath, mergedPdfBytes);

  const stats = await fs.stat(outputPath);

  return {
    filePath: outputPath,
    fileName: outputFileName,
    mimeType: 'application/pdf',
    size: stats.size,
    pageCount: mergedPdf.getPageCount(),
  };
}

// Split PDF
export async function splitPDF(
  filePath: string,
  pages: number[]
): Promise<ProcessResult> {
  const pdfBytes = await fs.readFile(filePath);
  const pdf = await PDFDocument.load(pdfBytes);
  const newPdf = await PDFDocument.create();

  // Convert to 0-based indexing
  const pageIndices = pages.map((p) => p - 1);
  const copiedPages = await newPdf.copyPages(pdf, pageIndices);
  copiedPages.forEach((page) => newPdf.addPage(page));

  const newPdfBytes = await newPdf.save();
  
  const outputFileName = `split-${uuidv4()}.pdf`;
  const outputPath = path.join(process.cwd(), 'uploads', 'temp', outputFileName);
  
  await fs.writeFile(outputPath, newPdfBytes);

  const stats = await fs.stat(outputPath);

  return {
    filePath: outputPath,
    fileName: outputFileName,
    mimeType: 'application/pdf',
    size: stats.size,
    pageCount: newPdf.getPageCount(),
  };
}

// Compress PDF
export async function compressPDF(
  filePath: string,
  quality: 'low' | 'medium' | 'high' = 'medium'
): Promise<ProcessResult> {
  const pdfBytes = await fs.readFile(filePath);
  const pdf = await PDFDocument.load(pdfBytes);

  // Compression settings based on quality
  const compressionSettings: Record<string, object> = {
    low: { useObjectStreams: true, addDefaultPage: false },
    medium: { useObjectStreams: true, addDefaultPage: false },
    high: { useObjectStreams: true, addDefaultPage: false },
  };

  const compressedBytes = await pdf.save(compressionSettings[quality]);
  
  const outputFileName = `compressed-${uuidv4()}.pdf`;
  const outputPath = path.join(process.cwd(), 'uploads', 'temp', outputFileName);
  
  await fs.writeFile(outputPath, compressedBytes);

  const stats = await fs.stat(outputPath);

  return {
    filePath: outputPath,
    fileName: outputFileName,
    mimeType: 'application/pdf',
    size: stats.size,
    pageCount: pdf.getPageCount(),
  };
}

// Convert PDF to Images
export async function convertPDFToImages(
  filePath: string,
  format: 'png' | 'jpeg' = 'png',
  dpi: number = 150
): Promise<ProcessResult[]> {
  const outputDir = path.join(process.cwd(), 'uploads', 'temp');
  
  const convert = fromPath(filePath, {
    density: dpi,
    saveFilename: `page-${uuidv4()}`,
    savePath: outputDir,
    format: format.toUpperCase() as 'PNG' | 'JPEG',
    width: 1200,
    height: 1600,
  });

  const pageToConvertAsImage = await convert.bulk(-1, {
    responseType: 'image',
  });

  const results: ProcessResult[] = [];
  
  for (let i = 0; i < pageToConvertAsImage.length; i++) {
    const outputFileName = `page-${i + 1}-${uuidv4()}.${format}`;
    const outputPath = path.join(outputDir, outputFileName);
    
    // The converted image is already saved, just need to rename
    const originalPath = path.join(outputDir, `page-${i + 1}.${format}`);
    await fs.rename(originalPath, outputPath);
    
    const stats = await fs.stat(outputPath);
    
    results.push({
      filePath: outputPath,
      fileName: outputFileName,
      mimeType: format === 'png' ? 'image/png' : 'image/jpeg',
      size: stats.size,
    });
  }

  return results;
}

// Rotate PDF pages
export async function rotatePDF(
  filePath: string,
  rotation: 90 | 180 | 270,
  pages?: number[] // If not provided, rotate all pages
): Promise<ProcessResult> {
  const pdfBytes = await fs.readFile(filePath);
  const pdf = await PDFDocument.load(pdfBytes);

  const pageIndices = pages ? pages.map((p) => p - 1) : pdf.getPageIndices();

  pageIndices.forEach((pageIndex) => {
    const page = pdf.getPage(pageIndex);
    const currentRotation = page.getRotation().angle;
    page.setRotation({ angle: currentRotation + rotation });
  });

  const rotatedBytes = await pdf.save();
  
  const outputFileName = `rotated-${uuidv4()}.pdf`;
  const outputPath = path.join(process.cwd(), 'uploads', 'temp', outputFileName);
  
  await fs.writeFile(outputPath, rotatedBytes);

  const stats = await fs.stat(outputPath);

  return {
    filePath: outputPath,
    fileName: outputFileName,
    mimeType: 'application/pdf',
    size: stats.size,
    pageCount: pdf.getPageCount(),
  };
}

// Add e-signature placeholder to PDF
export async function addSignaturePlaceholder(
  filePath: string,
  signatureData: string, // Base64 image
  pageNumber: number,
  x: number,
  y: number,
  width: number,
  height: number
): Promise<ProcessResult> {
  const pdfBytes = await fs.readFile(filePath);
  const pdf = await PDFDocument.load(pdfBytes);

  // Get the page
  const page = pdf.getPage(pageNumber - 1);

  // Embed signature image
  const signatureImage = await pdf.embedPng(Buffer.from(signatureData, 'base64'));

  // Draw signature on page
  page.drawImage(signatureImage, {
    x,
    y,
    width,
    height,
  });

  const signedBytes = await pdf.save();
  
  const outputFileName = `signed-${uuidv4()}.pdf`;
  const outputPath = path.join(process.cwd(), 'uploads', 'temp', outputFileName);
  
  await fs.writeFile(outputPath, signedBytes);

  const stats = await fs.stat(outputPath);

  return {
    filePath: outputPath,
    fileName: outputFileName,
    mimeType: 'application/pdf',
    size: stats.size,
    pageCount: pdf.getPageCount(),
  };
}

// Get PDF info
export async function getPDFInfo(filePath: string): Promise<{
  pageCount: number;
  title?: string;
  author?: string;
  subject?: string;
  creator?: string;
  producer?: string;
  creationDate?: Date;
  modificationDate?: Date;
}> {
  const pdfBytes = await fs.readFile(filePath);
  const pdf = await PDFDocument.load(pdfBytes);

  return {
    pageCount: pdf.getPageCount(),
    title: pdf.getTitle() || undefined,
    author: pdf.getAuthor() || undefined,
    subject: pdf.getSubject() || undefined,
    creator: pdf.getCreator() || undefined,
    producer: pdf.getProducer() || undefined,
    creationDate: pdf.getCreationDate() || undefined,
    modificationDate: pdf.getModificationDate() || undefined,
  };
}

// Upload processed file to S3 or local storage
export async function uploadToS3(
  filePath: string,
  userId: string,
  originalName: string
): Promise<{ s3Key: string; s3Url: string }> {
  const fileContent = await fs.readFile(filePath);
  const s3Key = generateS3Key(userId, originalName);

  // If S3 not configured, save locally
  if (!s3Client) {
    const { saveFileLocally } = await import('../config/s3');
    const { url } = await saveFileLocally(fileContent, originalName);
    return { s3Key, s3Url: url };
  }

  await s3Client.send(
    new PutObjectCommand({
      Bucket: S3_BUCKET,
      Key: s3Key,
      Body: fileContent,
      ContentType: 'application/pdf',
    })
  );

  const s3Url = `${env.API_URL}/api/files/download/${path.basename(s3Key)}`;

  return { s3Key, s3Url };
}

// Cleanup temp files
export async function cleanupTempFiles(filePaths: string[]): Promise<void> {
  for (const filePath of filePaths) {
    try {
      await fs.unlink(filePath);
    } catch (err) {
      console.error(`Failed to cleanup file ${filePath}:`, err);
    }
  }
}

export default {
  mergePDFs,
  splitPDF,
  compressPDF,
  convertPDFToImages,
  rotatePDF,
  addSignaturePlaceholder,
  getPDFInfo,
  uploadToS3,
  cleanupTempFiles,
};
