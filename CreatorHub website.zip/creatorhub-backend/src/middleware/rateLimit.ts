import { Request, Response, NextFunction } from 'express';
import { env } from '../config/env';
import { rateLimit } from '../config/redis';
import { RateLimitError } from '../utils/errors';

// Rate limit windows in milliseconds
const RATE_LIMIT_WINDOWS = {
  SECOND: 1000,
  MINUTE: 60 * 1000,
  HOUR: 60 * 60 * 1000,
  DAY: 24 * 60 * 60 * 1000,
};

// Default rate limits by tier
const DEFAULT_LIMITS = {
  anonymous: { requests: 10, window: RATE_LIMIT_WINDOWS.MINUTE },
  free: { requests: 30, window: RATE_LIMIT_WINDOWS.MINUTE },
  basic: { requests: 100, window: RATE_LIMIT_WINDOWS.MINUTE },
  pro: { requests: 300, window: RATE_LIMIT_WINDOWS.MINUTE },
  enterprise: { requests: 1000, window: RATE_LIMIT_WINDOWS.MINUTE },
};

// Create rate limiter middleware
export function createRateLimiter(
  tier: keyof typeof DEFAULT_LIMITS = 'anonymous',
  customLimit?: { requests: number; window: number }
) {
  const limit = customLimit || DEFAULT_LIMITS[tier];

  return async (
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> => {
    try {
      // Get identifier (user ID or IP address)
      const identifier = req.user?.userId || req.ip || 'unknown';
      const key = `ratelimit:${tier}:${identifier}`;

      const result = await rateLimit.increment(key, limit.window);

      // Set rate limit headers
      res.setHeader('X-RateLimit-Limit', limit.requests);
      res.setHeader('X-RateLimit-Remaining', Math.max(0, limit.requests - result.count));
      res.setHeader('X-RateLimit-Reset', result.resetTime);

      if (result.count > limit.requests) {
        const retryAfter = Math.ceil((result.resetTime - Date.now()) / 1000);
        res.setHeader('Retry-After', retryAfter);
        throw new RateLimitError(
          `Rate limit exceeded. Try again in ${retryAfter} seconds`,
          retryAfter
        );
      }

      next();
    } catch (error) {
      if (error instanceof RateLimitError) {
        next(error);
      } else {
        // If Redis fails, allow the request but log the error
        console.error('Rate limiting error:', error);
        next();
      }
    }
  };
}

// Specific rate limiters
export const rateLimitAnonymous = createRateLimiter('anonymous');
export const rateLimitFree = createRateLimiter('free');
export const rateLimitBasic = createRateLimiter('basic');
export const rateLimitPro = createRateLimiter('pro');
export const rateLimitEnterprise = createRateLimiter('enterprise');

// Dynamic rate limiter based on user's plan
export function rateLimitByPlan(
  req: Request,
  res: Response,
  next: NextFunction
): void {
  const plan = req.user?.plan || 'FREE';
  
  const planToTier: Record<string, keyof typeof DEFAULT_LIMITS> = {
    FREE: 'free',
    BASIC: 'basic',
    PRO: 'pro',
    ENTERPRISE: 'enterprise',
  };

  const tier = planToTier[plan] || 'anonymous';
  const limiter = createRateLimiter(tier);
  
  limiter(req, res, next);
}

// Stricter rate limit for auth endpoints
export const rateLimitAuth = createRateLimiter('anonymous', {
  requests: 5,
  window: RATE_LIMIT_WINDOWS.MINUTE,
});

// Rate limit for file uploads
export const rateLimitUpload = createRateLimiter('free', {
  requests: 10,
  window: RATE_LIMIT_WINDOWS.MINUTE,
});

// Rate limit for AI operations
export const rateLimitAI = createRateLimiter('free', {
  requests: 5,
  window: RATE_LIMIT_WINDOWS.MINUTE,
});

// Rate limit for API endpoints
export const rateLimitAPI = createRateLimiter('pro', {
  requests: 1000,
  window: RATE_LIMIT_WINDOWS.HOUR,
});

// Sliding window rate limiter (more accurate but more expensive)
export function createSlidingWindowLimiter(
  requests: number,
  windowMs: number
) {
  return async (
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> => {
    try {
      const identifier = req.user?.userId || req.ip || 'unknown';
      const key = `sliding:${identifier}`;
      const now = Date.now();
      const windowStart = now - windowMs;

      // This would require Redis sorted sets for accurate sliding window
      // For now, use the simpler fixed window approach
      const limiter = createRateLimiter('anonymous', { requests, window: windowMs });
      limiter(req, res, next);
    } catch (error) {
      next(error);
    }
  };
}

// Burst rate limiter (allows bursts but limits sustained rate)
export function createBurstLimiter(
  burstLimit: number,
  sustainedLimit: number,
  windowMs: number
) {
  return async (
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> => {
    try {
      const identifier = req.user?.userId || req.ip || 'unknown';
      const burstKey = `burst:${identifier}`;
      const sustainedKey = `sustained:${identifier}`;

      // Check burst limit
      const burstResult = await rateLimit.increment(burstKey, 1000); // 1 second burst window
      if (burstResult.count > burstLimit) {
        throw new RateLimitError('Burst rate limit exceeded', 1);
      }

      // Check sustained limit
      const sustainedResult = await rateLimit.increment(sustainedKey, windowMs);
      if (sustainedResult.count > sustainedLimit) {
        const retryAfter = Math.ceil((sustainedResult.resetTime - Date.now()) / 1000);
        throw new RateLimitError(
          `Rate limit exceeded. Try again in ${retryAfter} seconds`,
          retryAfter
        );
      }

      next();
    } catch (error) {
      next(error);
    }
  };
}

export default createRateLimiter;
