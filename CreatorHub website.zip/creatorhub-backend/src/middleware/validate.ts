import { Request, Response, NextFunction } from 'express';
import { body, param, query, validationResult, ValidationChain } from 'express-validator';
import { ValidationError } from '../utils/errors';

// Handle validation errors
export function handleValidationErrors(
  req: Request,
  res: Response,
  next: NextFunction
): void {
  const errors = validationResult(req);
  
  if (!errors.isEmpty()) {
    const formattedErrors = errors.array().map((error) => ({
      field: error.type === 'field' ? error.path : 'general',
      message: error.msg,
    }));
    
    throw new ValidationError(formattedErrors);
  }
  
  next();
}

// Validate request body
export function validate(validations: ValidationChain[]) {
  return async (
    req: Request,
    res: Response,
    next: NextFunction
  ): Promise<void> => {
    await Promise.all(validations.map((validation) => validation.run(req)));
    handleValidationErrors(req, res, next);
  };
}

// Common validators
export const validators = {
  // Auth validators
  register: [
    body('email')
      .isEmail()
      .normalizeEmail()
      .withMessage('Please provide a valid email address'),
    body('password')
      .isLength({ min: 8 })
      .withMessage('Password must be at least 8 characters long')
      .matches(/[a-z]/)
      .withMessage('Password must contain at least one lowercase letter')
      .matches(/[A-Z]/)
      .withMessage('Password must contain at least one uppercase letter')
      .matches(/\d/)
      .withMessage('Password must contain at least one number')
      .matches(/[!@#$%^&*(),.?":{}|<>]/)
      .withMessage('Password must contain at least one special character'),
    body('name')
      .optional()
      .trim()
      .isLength({ min: 2, max: 50 })
      .withMessage('Name must be between 2 and 50 characters'),
  ],
  
  login: [
    body('email')
      .isEmail()
      .normalizeEmail()
      .withMessage('Please provide a valid email address'),
    body('password')
      .notEmpty()
      .withMessage('Password is required'),
  ],
  
  forgotPassword: [
    body('email')
      .isEmail()
      .normalizeEmail()
      .withMessage('Please provide a valid email address'),
  ],
  
  resetPassword: [
    body('token')
      .notEmpty()
      .withMessage('Reset token is required'),
    body('password')
      .isLength({ min: 8 })
      .withMessage('Password must be at least 8 characters long'),
  ],
  
  changePassword: [
    body('currentPassword')
      .notEmpty()
      .withMessage('Current password is required'),
    body('newPassword')
      .isLength({ min: 8 })
      .withMessage('New password must be at least 8 characters long'),
  ],
  
  // File validators
  fileUpload: [
    body('fileName')
      .optional()
      .trim()
      .isLength({ max: 255 })
      .withMessage('File name too long'),
  ],
  
  // PDF processing validators
  pdfMerge: [
    body('fileIds')
      .isArray({ min: 2 })
      .withMessage('At least 2 files are required for merging'),
    body('fileIds.*')
      .isUUID()
      .withMessage('Invalid file ID'),
  ],
  
  pdfSplit: [
    body('fileId')
      .isUUID()
      .withMessage('Invalid file ID'),
    body('pages')
      .isArray({ min: 1 })
      .withMessage('At least one page number is required'),
    body('pages.*')
      .isInt({ min: 1 })
      .withMessage('Page numbers must be positive integers'),
  ],
  
  pdfCompress: [
    body('fileId')
      .isUUID()
      .withMessage('Invalid file ID'),
    body('quality')
      .optional()
      .isIn(['low', 'medium', 'high'])
      .withMessage('Quality must be low, medium, or high'),
  ],
  
  // Image processing validators
  imageProcess: [
    body('fileId')
      .isUUID()
      .withMessage('Invalid file ID'),
    body('operation')
      .isIn(['compress', 'upscale', 'convert', 'remove-bg'])
      .withMessage('Invalid operation'),
  ],
  
  // AI validators
  generateHashtags: [
    body('content')
      .trim()
      .isLength({ min: 10, max: 1000 })
      .withMessage('Content must be between 10 and 1000 characters'),
    body('platform')
      .optional()
      .isIn(['instagram', 'twitter', 'tiktok', 'linkedin', 'facebook'])
      .withMessage('Invalid platform'),
    body('count')
      .optional()
      .isInt({ min: 5, max: 30 })
      .withMessage('Count must be between 5 and 30'),
  ],
  
  generateCaption: [
    body('content')
      .trim()
      .isLength({ min: 10, max: 1000 })
      .withMessage('Content must be between 10 and 1000 characters'),
    body('platform')
      .optional()
      .isIn(['instagram', 'twitter', 'tiktok', 'linkedin', 'facebook'])
      .withMessage('Invalid platform'),
    body('tone')
      .optional()
      .isIn(['professional', 'casual', 'funny', 'inspirational', 'promotional'])
      .withMessage('Invalid tone'),
    body('length')
      .optional()
      .isIn(['short', 'medium', 'long'])
      .withMessage('Length must be short, medium, or long'),
  ],
  
  generateBio: [
    body('niche')
      .trim()
      .isLength({ min: 3, max: 50 })
      .withMessage('Niche must be between 3 and 50 characters'),
    body('personality')
      .optional()
      .isIn(['professional', 'fun', 'creative', 'minimal', 'bold'])
      .withMessage('Invalid personality'),
    body('platform')
      .optional()
      .isIn(['instagram', 'twitter', 'tiktok', 'linkedin'])
      .withMessage('Invalid platform'),
  ],
  
  // Business tool validators
  generateQR: [
    body('data')
      .trim()
      .isLength({ min: 1, max: 2000 })
      .withMessage('Data must be between 1 and 2000 characters'),
    body('size')
      .optional()
      .isInt({ min: 100, max: 1000 })
      .withMessage('Size must be between 100 and 1000'),
    body('color')
      .optional()
      .matches(/^#[0-9A-Fa-f]{6}$/)
      .withMessage('Color must be a valid hex code'),
  ],
  
  generateInvoice: [
    body('clientName')
      .trim()
      .isLength({ min: 2, max: 100 })
      .withMessage('Client name must be between 2 and 100 characters'),
    body('clientEmail')
      .optional()
      .isEmail()
      .withMessage('Please provide a valid email address'),
    body('items')
      .isArray({ min: 1 })
      .withMessage('At least one item is required'),
    body('items.*.description')
      .trim()
      .isLength({ min: 1, max: 200 })
      .withMessage('Item description is required'),
    body('items.*.quantity')
      .isInt({ min: 1 })
      .withMessage('Quantity must be at least 1'),
    body('items.*.price')
      .isFloat({ min: 0 })
      .withMessage('Price must be a positive number'),
  ],
  
  calculateEMI: [
    body('principal')
      .isFloat({ min: 1000 })
      .withMessage('Principal amount must be at least 1000'),
    body('rate')
      .isFloat({ min: 0.1, max: 100 })
      .withMessage('Interest rate must be between 0.1 and 100'),
    body('tenure')
      .isInt({ min: 1, max: 360 })
      .withMessage('Tenure must be between 1 and 360 months'),
  ],
  
  // Query validators
  pagination: [
    query('page')
      .optional()
      .isInt({ min: 1 })
      .withMessage('Page must be a positive integer'),
    query('limit')
      .optional()
      .isInt({ min: 1, max: 100 })
      .withMessage('Limit must be between 1 and 100'),
    query('sort')
      .optional()
      .isIn(['createdAt', 'updatedAt', 'name', 'size'])
      .withMessage('Invalid sort field'),
    query('order')
      .optional()
      .isIn(['asc', 'desc'])
      .withMessage('Order must be asc or desc'),
  ],
  
  // Param validators
  uuidParam: (paramName: string) => [
    param(paramName)
      .isUUID()
      .withMessage(`Invalid ${paramName} format`),
  ],
};

export default validate;
