import multer from 'multer';
import path from 'path';
import { Request } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { env } from '../config/env';
import { PLAN_LIMITS, getMaxFileSize } from '../utils/planLimits';
import { Plan } from '../types';

// Allowed mime types
const ALLOWED_MIME_TYPES: Record<string, string[]> = {
  pdf: ['application/pdf'],
  image: ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml'],
  document: [
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'text/plain',
    'text/csv',
  ],
  video: ['video/mp4', 'video/webm', 'video/quicktime'],
  audio: ['audio/mpeg', 'audio/wav', 'audio/ogg'],
};

// Flatten allowed types
const ALL_ALLOWED_TYPES = Object.values(ALLOWED_MIME_TYPES).flat();

// Storage configuration
const storage = multer.diskStorage({
  destination: (
    _req: Request,
    _file: Express.Multer.File,
    cb: (error: Error | null, destination: string) => void
  ) => {
    cb(null, path.join(process.cwd(), 'uploads', 'temp'));
  },
  filename: (
    _req: Request,
    file: Express.Multer.File,
    cb: (error: Error | null, filename: string) => void
  ) => {
    const uniqueName = `${uuidv4()}-${Date.now()}${path.extname(file.originalname)}`;
    cb(null, uniqueName);
  },
});

// File filter
function fileFilter(
  allowedTypes: string[] = ALL_ALLOWED_TYPES
): multer.Options['fileFilter'] {
  return (
    _req: Request,
    file: Express.Multer.File,
    cb: multer.FileFilterCallback
  ) => {
    if (allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(
        new Error(
          `Invalid file type. Allowed types: ${allowedTypes.join(', ')}`
        )
      );
    }
  };
}

// Get max file size for request
function getRequestMaxFileSize(req: Request): number {
  const userPlan = (req.user?.plan as Plan) || Plan.FREE;
  return getMaxFileSize(userPlan);
}

// Create multer instance with dynamic limits
function createUpload(
  allowedTypes?: string[],
  maxFiles: number = 1
): multer.Multer {
  return multer({
    storage,
    fileFilter: fileFilter(allowedTypes),
    limits: {
      fileSize: 500 * 1024 * 1024, // Will be checked dynamically
      files: maxFiles,
    },
  });
}

// Upload middlewares
export const upload = {
  // Single file upload
  single: (fieldName: string, allowedTypes?: string[]) => {
    const multerUpload = createUpload(allowedTypes, 1);
    return (req: Request, res: any, next: any) => {
      multerUpload.single(fieldName)(req, res, (err: any) => {
        if (err) return next(err);
        
        // Check file size against plan limit
        if (req.file) {
          const maxSize = getRequestMaxFileSize(req);
          if (req.file.size > maxSize) {
            return next(
              new Error(
                `File size exceeds your plan limit of ${maxSize / (1024 * 1024)}MB`
              )
            );
          }
        }
        next();
      });
    };
  },

  // Multiple files upload
  array: (fieldName: string, maxCount: number, allowedTypes?: string[]) => {
    const multerUpload = createUpload(allowedTypes, maxCount);
    return (req: Request, res: any, next: any) => {
      multerUpload.array(fieldName, maxCount)(req, res, (err: any) => {
        if (err) return next(err);
        
        // Check file sizes against plan limit
        if (req.files && Array.isArray(req.files)) {
          const maxSize = getRequestMaxFileSize(req);
          for (const file of req.files) {
            if (file.size > maxSize) {
              return next(
                new Error(
                  `File "${file.originalname}" exceeds your plan limit of ${maxSize / (1024 * 1024)}MB`
                )
              );
            }
          }
        }
        next();
      });
    };
  },

  // Multiple fields upload
  fields: (fields: multer.Field[], allowedTypes?: string[]) => {
    const maxFiles = fields.reduce((sum, f) => sum + f.maxCount, 0);
    const multerUpload = createUpload(allowedTypes, maxFiles);
    return (req: Request, res: any, next: any) => {
      multerUpload.fields(fields)(req, res, (err: any) => {
        if (err) return next(err);
        next();
      });
    };
  },
};

// Specific upload middlewares
export const uploadPDF = upload.single('file', ALLOWED_MIME_TYPES.pdf);
export const uploadPDFs = upload.array('files', 10, ALLOWED_MIME_TYPES.pdf);
export const uploadImage = upload.single('file', ALLOWED_MIME_TYPES.image);
export const uploadImages = upload.array('files', 20, ALLOWED_MIME_TYPES.image);
export const uploadDocument = upload.single('file', ALLOWED_MIME_TYPES.document);
export const uploadAny = upload.single('file');

// Memory storage for small files (for processing without saving to disk)
const memoryStorage = multer.memoryStorage();

export const uploadToMemory = multer({
  storage: memoryStorage,
  limits: {
    fileSize: 50 * 1024 * 1024, // 50MB max for memory
  },
});

// Cleanup middleware
export function cleanupUploads(
  req: Request,
  res: Response,
  next: NextFunction
): void {
  // Store files to cleanup
  const filesToCleanup: string[] = [];

  if (req.file) {
    filesToCleanup.push(req.file.path);
  }

  if (req.files) {
    if (Array.isArray(req.files)) {
      filesToCleanup.push(...req.files.map((f) => f.path));
    } else {
      Object.values(req.files).forEach((fileArray) => {
        filesToCleanup.push(...fileArray.map((f) => f.path));
      });
    }
  }

  // Cleanup function
  const cleanup = () => {
    const fs = require('fs');
    filesToCleanup.forEach((filepath) => {
      try {
        if (fs.existsSync(filepath)) {
          fs.unlinkSync(filepath);
        }
      } catch (err) {
        console.error('Failed to cleanup upload:', err);
      }
    });
  };

  // Cleanup on response finish
  res.on('finish', cleanup);
  res.on('close', cleanup);

  next();
}

// File metadata middleware
export function addFileMetadata(
  req: Request,
  _res: Response,
  next: NextFunction
): void {
  if (req.file) {
    (req.file as any).metadata = {
      uploadedAt: new Date().toISOString(),
      uploadedBy: req.user?.userId || 'anonymous',
      originalName: req.file.originalname,
    };
  }

  if (req.files) {
    const addMetadata = (file: Express.Multer.File) => {
      (file as any).metadata = {
        uploadedAt: new Date().toISOString(),
        uploadedBy: req.user?.userId || 'anonymous',
        originalName: file.originalname,
      };
    };

    if (Array.isArray(req.files)) {
      req.files.forEach(addMetadata);
    } else {
      Object.values(req.files).forEach((fileArray) => {
        fileArray.forEach(addMetadata);
      });
    }
  }

  next();
}

export default upload;
