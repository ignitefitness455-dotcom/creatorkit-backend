import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { env } from '../config/env';
import { prisma } from '../config/database';
import { JwtPayload, Plan } from '../types';
import { UnauthorizedError, ForbiddenError } from '../utils/errors';
import { handleJWTError } from '../utils/errors';

// Extend Express Request
declare global {
  namespace Express {
    interface Request {
      user?: JwtPayload;
    }
  }
}

// Verify access token
export function verifyToken(token: string): JwtPayload {
  try {
    return jwt.verify(token, env.JWT_SECRET) as JwtPayload;
  } catch (error) {
    throw handleJWTError(error);
  }
}

// Verify refresh token
export function verifyRefreshToken(token: string): JwtPayload {
  try {
    return jwt.verify(token, env.JWT_REFRESH_SECRET) as JwtPayload;
  } catch (error) {
    throw handleJWTError(error);
  }
}

// Generate tokens
export function generateTokens(payload: Omit<JwtPayload, 'iat' | 'exp'>): {
  accessToken: string;
  refreshToken: string;
  expiresIn: number;
} {
  const expiresIn = 15 * 60; // 15 minutes in seconds

  const accessToken = jwt.sign(payload, env.JWT_SECRET, {
    expiresIn: env.JWT_EXPIRES_IN,
  });

  const refreshToken = jwt.sign(
    { userId: payload.userId },
    env.JWT_REFRESH_SECRET,
    { expiresIn: env.JWT_REFRESH_EXPIRES_IN }
  );

  return { accessToken, refreshToken, expiresIn };
}

// Authentication middleware
export async function authenticate(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader?.startsWith('Bearer ')) {
      throw new UnauthorizedError('Access token required');
    }

    const token = authHeader.substring(7);
    const decoded = verifyToken(token);

    // Check if user still exists and is active
    const user = await prisma.user.findUnique({
      where: { id: decoded.userId },
      select: { id: true, email: true, emailVerified: true },
    });

    if (!user) {
      throw new UnauthorizedError('User not found');
    }

    if (!user.emailVerified) {
      throw new ForbiddenError('Email not verified', 'EMAIL_NOT_VERIFIED');
    }

    req.user = decoded;
    next();
  } catch (error) {
    next(error);
  }
}

// Optional authentication middleware
export async function optionalAuth(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const authHeader = req.headers.authorization;
    
    if (authHeader?.startsWith('Bearer ')) {
      const token = authHeader.substring(7);
      const decoded = verifyToken(token);
      req.user = decoded;
    }
    
    next();
  } catch {
    // Continue without user
    next();
  }
}

// Require specific plan
export function requirePlan(...allowedPlans: Plan[]) {
  return (req: Request, res: Response, next: NextFunction): void => {
    if (!req.user) {
      next(new UnauthorizedError('Authentication required'));
      return;
    }

    if (!allowedPlans.includes(req.user.plan)) {
      next(
        new ForbiddenError(
          `This feature requires ${allowedPlans.join(' or ')} plan`,
          'SUBSCRIPTION_REQUIRED'
        )
      );
      return;
    }

    next();
  };
}

// Check if email is verified
export function requireVerifiedEmail(
  req: Request,
  res: Response,
  next: NextFunction
): void {
  if (!req.user) {
    next(new UnauthorizedError('Authentication required'));
    return;
  }

  // Email verification check is done in authenticate middleware
  next();
}

// Refresh token middleware
export async function refreshAccessToken(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const { refreshToken } = req.body;

    if (!refreshToken) {
      throw new UnauthorizedError('Refresh token required');
    }

    const decoded = verifyRefreshToken(refreshToken);

    // Get user with subscription
    const user = await prisma.user.findUnique({
      where: { id: decoded.userId },
      include: { subscription: true },
    });

    if (!user) {
      throw new UnauthorizedError('User not found');
    }

    // Generate new tokens
    const tokens = generateTokens({
      userId: user.id,
      email: user.email,
      plan: (user.subscription?.plan as Plan) || Plan.FREE,
    });

    res.json({
      success: true,
      data: tokens,
    });
  } catch (error) {
    next(error);
  }
}

// Logout middleware
export async function logout(
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    // In a more complex setup, you might want to blacklist the token
    // For now, we just return success and let the client remove the token
    res.json({
      success: true,
      message: 'Logged out successfully',
    });
  } catch (error) {
    next(error);
  }
}

export default authenticate;
