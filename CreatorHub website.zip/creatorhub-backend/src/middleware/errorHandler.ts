import { Request, Response, NextFunction } from 'express';
import { env } from '../config/env';
import { AppError, ValidationError, RateLimitError } from '../utils/errors';
import { Prisma } from '@prisma/client';

// Error response interface
interface ErrorResponse {
  success: false;
  error: string;
  code: string;
  message: string;
  errors?: Array<{ field: string; message: string }>;
  stack?: string;
  retryAfter?: number;
}

// Global error handler
export function errorHandler(
  err: Error | AppError,
  req: Request,
  res: Response,
  _next: NextFunction
): void {
  // Default error values
  let statusCode = 500;
  let errorCode = 'INTERNAL_ERROR';
  let message = 'An unexpected error occurred';
  let errors: Array<{ field: string; message: string }> | undefined;
  let retryAfter: number | undefined;

  // Handle AppError
  if (err instanceof AppError) {
    statusCode = err.statusCode;
    errorCode = err.code;
    message = err.message;

    if (err instanceof ValidationError) {
      errors = err.errors;
    }

    if (err instanceof RateLimitError) {
      retryAfter = err.retryAfter;
    }
  }
  // Handle Prisma errors
  else if (err instanceof Prisma.PrismaClientKnownRequestError) {
    statusCode = 400;
    errorCode = 'DATABASE_ERROR';
    
    switch (err.code) {
      case 'P2002':
        statusCode = 409;
        errorCode = 'UNIQUE_CONSTRAINT_VIOLATION';
        message = 'A record with this value already exists';
        break;
      case 'P2025':
        statusCode = 404;
        errorCode = 'RECORD_NOT_FOUND';
        message = 'Record not found';
        break;
      case 'P2003':
        statusCode = 400;
        errorCode = 'FOREIGN_KEY_CONSTRAINT';
        message = 'Foreign key constraint failed';
        break;
      default:
        message = 'Database error occurred';
    }
  }
  // Handle Prisma validation errors
  else if (err instanceof Prisma.PrismaClientValidationError) {
    statusCode = 400;
    errorCode = 'VALIDATION_ERROR';
    message = 'Invalid data provided';
  }
  // Handle JWT errors
  else if (err.name === 'JsonWebTokenError') {
    statusCode = 401;
    errorCode = 'INVALID_TOKEN';
    message = 'Invalid authentication token';
  } else if (err.name === 'TokenExpiredError') {
    statusCode = 401;
    errorCode = 'TOKEN_EXPIRED';
    message = 'Authentication token has expired';
  }
  // Handle multer errors
  else if (err.name === 'MulterError') {
    statusCode = 400;
    errorCode = 'FILE_UPLOAD_ERROR';
    
    switch (err.message) {
      case 'LIMIT_FILE_SIZE':
        message = 'File size exceeds the limit';
        break;
      case 'LIMIT_FILE_COUNT':
        message = 'Too many files uploaded';
        break;
      case 'LIMIT_UNEXPECTED_FILE':
        message = 'Unexpected file field';
        break;
      default:
        message = 'File upload error';
    }
  }
  // Handle syntax errors (JSON parsing)
  else if (err instanceof SyntaxError && 'body' in err) {
    statusCode = 400;
    errorCode = 'INVALID_JSON';
    message = 'Invalid JSON in request body';
  }

  // Build error response
  const errorResponse: ErrorResponse = {
    success: false,
    error: err.message || message,
    code: errorCode,
    message,
  };

  // Add validation errors if present
  if (errors) {
    errorResponse.errors = errors;
  }

  // Add retry after for rate limits
  if (retryAfter) {
    errorResponse.retryAfter = retryAfter;
  }

  // Add stack trace in development
  if (env.NODE_ENV === 'development') {
    errorResponse.stack = err.stack;
  }

  // Log error
  if (statusCode >= 500) {
    console.error('Server error:', err);
  } else if (env.NODE_ENV === 'development') {
    console.log('Client error:', err.message);
  }

  // Send response
  res.status(statusCode).json(errorResponse);
}

// 404 handler
export function notFoundHandler(
  req: Request,
  res: Response,
  _next: NextFunction
): void {
  res.status(404).json({
    success: false,
    error: `Route ${req.originalUrl} not found`,
    code: 'ROUTE_NOT_FOUND',
    message: 'The requested resource was not found',
  });
}

// Async handler wrapper
export function asyncHandler(
  fn: (req: Request, res: Response, next: NextFunction) => Promise<void>
) {
  return (req: Request, res: Response, next: NextFunction): void => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}

// Request timeout handler
export function timeoutHandler(timeoutMs: number = 30000) {
  return (req: Request, res: Response, next: NextFunction): void => {
    const timeout = setTimeout(() => {
      if (!res.headersSent) {
        res.status(408).json({
          success: false,
          error: 'Request timeout',
          code: 'REQUEST_TIMEOUT',
          message: 'The request took too long to process',
        });
      }
    }, timeoutMs);

    res.on('finish', () => {
      clearTimeout(timeout);
    });

    next();
  };
}

export default errorHandler;
