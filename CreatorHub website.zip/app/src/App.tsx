import { useEffect } from 'react';
import { Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { Hero } from '@/sections/Hero';
import { ToolsGrid } from '@/sections/ToolsGrid';
import { Features } from '@/sections/Features';
import { Pricing } from '@/sections/Pricing';
import { AuthModals } from '@/components/AuthModals';
import { ToolModal } from '@/components/ToolModal';
import { useAuthStore } from '@/store/authStore';
import { useThemeStore } from '@/store/themeStore';
import { Toaster } from '@/components/ui/sonner';

function App() {
  const { isLoginModalOpen, isSignupModalOpen, closeModals } = useAuthStore();
  const { setTheme } = useThemeStore();

  // Initialize theme
  useEffect(() => {
    const savedTheme = localStorage.getItem('theme-storage');
    if (savedTheme) {
      const parsed = JSON.parse(savedTheme);
      if (parsed.state.theme) {
        setTheme(parsed.state.theme);
      }
    } else {
      // Default to dark mode
      document.documentElement.classList.add('dark');
    }
  }, [setTheme]);

  return (
    <div className="min-h-screen bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100">
      <Navbar />
      
      <main>
        <Hero />
        <ToolsGrid />
        <Features />
        <Pricing />
      </main>

      <Footer />

      {/* Modals */}
      <AuthModals 
        isOpen={isLoginModalOpen || isSignupModalOpen} 
        onClose={closeModals}
        defaultTab={isSignupModalOpen ? 'signup' : 'login'}
      />

      <ToolModal />

      <Toaster position="bottom-right" />
    </div>
  );
}

export default App;
