import { create } from 'zustand';
import type { ToolCategory, FileItem } from '@/types';

interface ToolState {
  selectedCategory: ToolCategory;
  searchQuery: string;
  selectedTool: string | null;
  isToolModalOpen: boolean;
  uploadedFiles: FileItem[];
  processingStatus: 'idle' | 'processing' | 'completed' | 'error';
  processingProgress: number;
  
  // Actions
  setSelectedCategory: (category: ToolCategory) => void;
  setSearchQuery: (query: string) => void;
  selectTool: (toolId: string | null) => void;
  openToolModal: (toolId: string) => void;
  closeToolModal: () => void;
  addUploadedFile: (file: FileItem) => void;
  removeUploadedFile: (fileId: string) => void;
  clearUploadedFiles: () => void;
  setProcessingStatus: (status: 'idle' | 'processing' | 'completed' | 'error') => void;
  setProcessingProgress: (progress: number) => void;
}

export const useToolStore = create<ToolState>((set) => ({
  selectedCategory: 'all',
  searchQuery: '',
  selectedTool: null,
  isToolModalOpen: false,
  uploadedFiles: [],
  processingStatus: 'idle',
  processingProgress: 0,

  setSelectedCategory: (category) => set({ selectedCategory: category }),
  
  setSearchQuery: (query) => set({ searchQuery: query }),
  
  selectTool: (toolId) => set({ selectedTool: toolId }),
  
  openToolModal: (toolId) => set({ selectedTool: toolId, isToolModalOpen: true }),
  
  closeToolModal: () => set({ selectedTool: null, isToolModalOpen: false, uploadedFiles: [], processingStatus: 'idle', processingProgress: 0 }),
  
  addUploadedFile: (file) => set((state) => ({ uploadedFiles: [...state.uploadedFiles, file] })),
  
  removeUploadedFile: (fileId) => set((state) => ({ uploadedFiles: state.uploadedFiles.filter((f) => f.id !== fileId) })),
  
  clearUploadedFiles: () => set({ uploadedFiles: [] }),
  
  setProcessingStatus: (status) => set({ processingStatus: status }),
  
  setProcessingProgress: (progress) => set({ processingProgress: progress }),
}));
