import { create } from 'zustand';
import type { User, UserPlan } from '@/types';

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoginModalOpen: boolean;
  isSignupModalOpen: boolean;
  activeModal: 'login' | 'signup' | null;
  
  // Actions
  setUser: (user: User | null) => void;
  login: (user: User) => void;
  logout: () => void;
  openLoginModal: () => void;
  openSignupModal: () => void;
  closeModals: () => void;
  switchModal: (modal: 'login' | 'signup') => void;
  updatePlan: (plan: UserPlan) => void;
  updateCredits: (credits: number) => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  isAuthenticated: false,
  isLoginModalOpen: false,
  isSignupModalOpen: false,
  activeModal: null,

  setUser: (user) => set({ user, isAuthenticated: !!user }),
  
  login: (user) => set({ user, isAuthenticated: true, isLoginModalOpen: false, isSignupModalOpen: false, activeModal: null }),
  
  logout: () => set({ user: null, isAuthenticated: false }),
  
  openLoginModal: () => set({ isLoginModalOpen: true, isSignupModalOpen: false, activeModal: 'login' }),
  
  openSignupModal: () => set({ isLoginModalOpen: false, isSignupModalOpen: true, activeModal: 'signup' }),
  
  closeModals: () => set({ isLoginModalOpen: false, isSignupModalOpen: false, activeModal: null }),
  
  switchModal: (modal) => {
    if (modal === 'login') {
      set({ isLoginModalOpen: true, isSignupModalOpen: false, activeModal: 'login' });
    } else {
      set({ isLoginModalOpen: false, isSignupModalOpen: true, activeModal: 'signup' });
    }
  },
  
  updatePlan: (plan) => set((state) => ({
    user: state.user ? { ...state.user, plan } : null,
  })),
  
  updateCredits: (credits) => set((state) => ({
    user: state.user ? { ...state.user, credits } : null,
  })),
}));
