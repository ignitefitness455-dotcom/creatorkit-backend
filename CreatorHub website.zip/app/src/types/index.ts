export type ToolCategory = 'pdf' | 'image' | 'social' | 'business' | 'all';
export type UserPlan = 'free' | 'pro' | 'business';

export interface Tool {
  id: string;
  name: string;
  description: string;
  category: ToolCategory;
  icon: string;
  color: string;
  isPremium: boolean;
  plan: UserPlan;
  maxFileSize?: number;
  allowedTypes?: string[];
  rating: number;
  usageCount: number;
}

export interface User {
  id: string;
  email: string;
  name: string;
  image?: string;
  plan: UserPlan;
  credits: number;
  createdAt: Date;
}

export interface FileItem {
  id: string;
  name: string;
  originalName: string;
  type: 'pdf' | 'image' | 'video' | 'audio' | 'document';
  mimeType: string;
  size: number;
  url: string;
  thumbnailUrl?: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  toolId?: string;
  errorMessage?: string;
  createdAt: Date;
}

export interface Subscription {
  id: string;
  userId: string;
  stripeCustomerId?: string;
  stripePriceId?: string;
  stripeSubscriptionId?: string;
  status: 'active' | 'canceled' | 'past_due' | 'unpaid' | 'incomplete';
  currentPeriodEnd?: Date;
}

export interface PricingPlan {
  id: UserPlan;
  name: string;
  price: number;
  description: string;
  features: string[];
  credits: number;
  maxFileSize: number;
  popular?: boolean;
}

export interface NavItem {
  label: string;
  href: string;
}
