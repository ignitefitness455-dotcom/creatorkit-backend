import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  FileText, Image, Share2, Briefcase, Star, Crown, 
  Search, Sparkles, ArrowRight,
  FileDown, Combine, Scissors, ScanText, RotateCw, Signature,
  ImageDown, Wand2, Maximize2, Camera, FileImage, Palette,
  Hash, PenTool, Link, Smartphone, Video, TrendingUp,
  QrCode, Receipt, Calculator, Key
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { TOOLS, CATEGORY_COLORS, CATEGORY_LABELS } from '@/data/tools';
import type { ToolCategory, Tool } from '@/types';
import { useToolStore } from '@/store/toolStore';
import { useAuthStore } from '@/store/authStore';
import { cn } from '@/lib/utils';

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  FileDown, Combine, Scissors, FileText, Image, ScanText, RotateCw, Signature,
  ImageDown, Wand2, Maximize2, Camera, FileImage, Palette,
  Hash, PenTool, Link, Smartphone, Video, TrendingUp,
  QrCode, Receipt, Calculator, Key
};

const categories: { id: ToolCategory; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: 'all', icon: Sparkles },
  { id: 'pdf', icon: FileText },
  { id: 'image', icon: Image },
  { id: 'social', icon: Share2 },
  { id: 'business', icon: Briefcase },
];

function ToolCard({ tool, index }: { tool: Tool; index: number }) {
  const cardRef = useRef<HTMLDivElement>(null);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);
  const { openToolModal } = useToolStore();
  const { isAuthenticated, openSignupModal } = useAuthStore();

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    setMousePosition({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    });
  };

  const handleClick = () => {
    if (tool.isPremium && !isAuthenticated) {
      openSignupModal();
      return;
    }
    openToolModal(tool.id);
  };

  const Icon = iconMap[tool.icon] || FileText;

  return (
    <motion.div
      ref={cardRef}
      layout
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.9 }}
      transition={{ duration: 0.3, delay: index * 0.05 }}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={handleClick}
      className="relative group cursor-pointer"
    >
      {/* Spotlight Effect */}
      <div
        className="absolute -inset-px rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none"
        style={{
          background: isHovered
            ? `radial-gradient(400px circle at ${mousePosition.x}px ${mousePosition.y}px, rgba(139, 92, 246, 0.15), transparent 40%)`
            : 'none',
        }}
      />

      <div className="relative h-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 hover:border-purple-500/50 dark:hover:border-purple-500/50 transition-all duration-300 hover:shadow-xl hover:shadow-purple-500/10">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${tool.color} flex items-center justify-center shadow-lg`}>
            <Icon className="w-6 h-6 text-white" />
          </div>
          <div className="flex items-center gap-2">
            {tool.isPremium && (
              <Badge variant="secondary" className="bg-amber-500/10 text-amber-600 dark:text-amber-400 border-amber-500/20">
                <Crown className="w-3 h-3 mr-1" />
                PRO
              </Badge>
            )}
            <Badge variant="outline" className={CATEGORY_COLORS[tool.category]}>
              {CATEGORY_LABELS[tool.category]}
            </Badge>
          </div>
        </div>

        {/* Content */}
        <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-2 group-hover:text-purple-600 dark:group-hover:text-purple-400 transition-colors">
          {tool.name}
        </h3>
        <p className="text-sm text-slate-600 dark:text-slate-400 mb-4 line-clamp-2">
          {tool.description}
        </p>

        {/* Footer */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1">
            <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
            <span className="text-sm font-medium text-slate-700 dark:text-slate-300">
              {tool.rating}
            </span>
            <span className="text-xs text-slate-500">
              ({(tool.usageCount / 1000000).toFixed(1)}M)
            </span>
          </div>
          <Button
            variant="ghost"
            size="sm"
            className="opacity-0 group-hover:opacity-100 transition-opacity text-purple-600 hover:text-purple-700 hover:bg-purple-50 dark:hover:bg-purple-950"
          >
            Use Tool
            <ArrowRight className="w-4 h-4 ml-1" />
          </Button>
        </div>
      </div>
    </motion.div>
  );
}

export function ToolsGrid() {
  const { selectedCategory, setSelectedCategory, searchQuery, setSearchQuery } = useToolStore();

  const filteredTools = TOOLS.filter((tool) => {
    const matchesCategory = selectedCategory === 'all' || tool.category === selectedCategory;
    const matchesSearch = 
      tool.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tool.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <section id="tools" className="py-24 relative">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-slate-50/50 dark:via-slate-900/50 to-transparent" />

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <Badge variant="outline" className="mb-4 px-4 py-1.5 text-sm border-purple-500/30 text-purple-600 dark:text-purple-400">
              <Sparkles className="w-4 h-4 mr-2" />
              All Tools
            </Badge>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-slate-900 dark:text-white mb-4">
              Everything You Need to{' '}
              <span className="bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 bg-clip-text text-transparent">
                Create
              </span>
            </h2>
            <p className="text-lg text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
              24+ powerful tools to handle all your creative needs. From PDF editing to AI image processing.
            </p>
          </motion.div>
        </div>

        {/* Search and Filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="flex flex-col sm:flex-row gap-4 mb-10"
        >
          {/* Search */}
          <div className="relative flex-1 max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
            <Input
              type="text"
              placeholder="Search tools..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 h-12 rounded-xl"
            />
          </div>

          {/* Category Pills */}
          <div className="flex flex-wrap gap-2">
            {categories.map(({ id, icon: Icon }) => (
              <Button
                key={id}
                variant={selectedCategory === id ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSelectedCategory(id)}
                className={cn(
                  'rounded-full px-4 h-10 transition-all duration-300',
                  selectedCategory === id
                    ? 'bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 text-white shadow-lg shadow-purple-500/25'
                    : 'hover:border-purple-500/50'
                )}
              >
                <Icon className="w-4 h-4 mr-2" />
                {CATEGORY_LABELS[id]}
              </Button>
            ))}
          </div>
        </motion.div>

        {/* Tools Grid */}
        <motion.div
          layout
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
        >
          <AnimatePresence mode="popLayout">
            {filteredTools.map((tool, index) => (
              <ToolCard key={tool.id} tool={tool} index={index} />
            ))}
          </AnimatePresence>
        </motion.div>

        {/* Empty State */}
        {filteredTools.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="text-center py-20"
          >
            <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center">
              <Search className="w-10 h-10 text-slate-400" />
            </div>
            <h3 className="text-xl font-semibold text-slate-900 dark:text-white mb-2">
              No tools found
            </h3>
            <p className="text-slate-600 dark:text-slate-400">
              Try adjusting your search or filter
            </p>
          </motion.div>
        )}
      </div>
    </section>
  );
}
