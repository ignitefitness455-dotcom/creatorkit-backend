import { motion } from 'framer-motion';
import { Check, Sparkles, Zap, Building2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { PRICING_PLANS } from '@/data/tools';
import { useAuthStore } from '@/store/authStore';
import { cn } from '@/lib/utils';

const planIcons = {
  free: Sparkles,
  pro: Zap,
  business: Building2,
};

const planColors = {
  free: 'from-slate-500 to-slate-600',
  pro: 'from-blue-500 via-purple-500 to-pink-500',
  business: 'from-amber-500 to-orange-500',
};

export function Pricing() {
  const { isAuthenticated, openSignupModal } = useAuthStore();

  const handlePlanClick = (planId: string) => {
    if (!isAuthenticated) {
      openSignupModal();
      return;
    }
    // Handle plan selection
    console.log('Selected plan:', planId);
  };

  return (
    <section id="pricing" className="py-24 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-to-r from-blue-500/10 via-purple-500/10 to-pink-500/10 rounded-full blur-3xl" />
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <Badge variant="outline" className="mb-4 px-4 py-1.5 text-sm border-pink-500/30 text-pink-600 dark:text-pink-400">
              <Sparkles className="w-4 h-4 mr-2" />
              Pricing
            </Badge>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-slate-900 dark:text-white mb-4">
              Simple,{' '}
              <span className="bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 bg-clip-text text-transparent">
                Transparent
              </span>{' '}
              Pricing
            </h2>
            <p className="text-lg text-slate-600 dark:text-slate-400 max-w-2xl mx-auto">
              Start free, upgrade when you need more. No hidden fees, cancel anytime.
            </p>
          </motion.div>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {PRICING_PLANS.map((plan, index) => {
            const Icon = planIcons[plan.id];
            const isPopular = plan.popular;

            return (
              <motion.div
                key={plan.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className={cn(
                  'relative group',
                  isPopular && 'md:-mt-4 md:mb-4'
                )}
              >
                {/* Popular Badge */}
                {isPopular && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 z-10">
                    <Badge className="bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 text-white border-0 px-4 py-1">
                      Most Popular
                    </Badge>
                  </div>
                )}

                <div
                  className={cn(
                    'h-full rounded-2xl p-6 lg:p-8 transition-all duration-300',
                    isPopular
                      ? 'bg-white dark:bg-slate-900 border-2 border-purple-500 shadow-xl shadow-purple-500/20'
                      : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-purple-500/50'
                  )}
                >
                  {/* Plan Header */}
                  <div className="text-center mb-6">
                    <div className={cn(
                      'w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br flex items-center justify-center mb-4',
                      planColors[plan.id]
                    )}>
                      <Icon className="w-8 h-8 text-white" />
                    </div>
                    <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">
                      {plan.name}
                    </h3>
                    <p className="text-sm text-slate-600 dark:text-slate-400">
                      {plan.description}
                    </p>
                  </div>

                  {/* Price */}
                  <div className="text-center mb-6">
                    <div className="flex items-baseline justify-center gap-1">
                      <span className="text-4xl lg:text-5xl font-bold text-slate-900 dark:text-white">
                        ${plan.price}
                      </span>
                      {plan.price > 0 && (
                        <span className="text-slate-500 dark:text-slate-400">/mo</span>
                      )}
                    </div>
                  </div>

                  {/* Features */}
                  <ul className="space-y-3 mb-8">
                    {plan.features.map((feature, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <div className={cn(
                          'w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5',
                          plan.id === 'free' ? 'bg-slate-100 dark:bg-slate-800' : 'bg-purple-500/10'
                        )}>
                          <Check className={cn(
                            'w-3 h-3',
                            plan.id === 'free' ? 'text-slate-500' : 'text-purple-600 dark:text-purple-400'
                          )} />
                        </div>
                        <span className="text-sm text-slate-600 dark:text-slate-400">
                          {feature}
                        </span>
                      </li>
                    ))}
                  </ul>

                  {/* CTA Button */}
                  <Button
                    onClick={() => handlePlanClick(plan.id)}
                    className={cn(
                      'w-full',
                      isPopular
                        ? 'bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 text-white hover:opacity-90'
                        : plan.id === 'free'
                        ? 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white hover:bg-slate-200 dark:hover:bg-slate-700'
                        : 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 hover:bg-slate-800 dark:hover:bg-slate-100'
                    )}
                  >
                    {plan.id === 'free' ? 'Get Started Free' : `Upgrade to ${plan.name}`}
                  </Button>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Trust Badges */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.4 }}
          className="mt-16 text-center"
        >
          <div className="flex flex-wrap items-center justify-center gap-6 text-sm text-slate-500 dark:text-slate-400">
            <div className="flex items-center gap-2">
              <Check className="w-4 h-4 text-green-500" />
              No credit card required
            </div>
            <div className="flex items-center gap-2">
              <Check className="w-4 h-4 text-green-500" />
              Cancel anytime
            </div>
            <div className="flex items-center gap-2">
              <Check className="w-4 h-4 text-green-500" />
              14-day money-back guarantee
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
