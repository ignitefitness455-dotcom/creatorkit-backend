import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  X, Upload, Image, FileText, Loader2, 
  Check, Download, Crown,
  FileDown, Combine, Scissors, ScanText, RotateCw, Signature,
  ImageDown, Wand2, Maximize2, Camera, FileImage, Palette,
  Hash, PenTool, Link, Smartphone, Video, TrendingUp,
  QrCode, Receipt, Calculator, Key
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { useToolStore } from '@/store/toolStore';
import { useAuthStore } from '@/store/authStore';
import { TOOLS } from '@/data/tools';
import { cn } from '@/lib/utils';

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  FileDown, Combine, Scissors, FileText, Image, ScanText, RotateCw, Signature,
  ImageDown, Wand2, Maximize2, Camera, FileImage, Palette,
  Hash, PenTool, Link, Smartphone, Video, TrendingUp,
  QrCode, Receipt, Calculator, Key
};

export function ToolModal() {
  const { 
    selectedTool, 
    isToolModalOpen, 
    closeToolModal, 
    uploadedFiles, 
    addUploadedFile, 
    removeUploadedFile,
    processingStatus,
    setProcessingStatus,
    processingProgress,
    setProcessingProgress
  } = useToolStore();
  const { user, openSignupModal } = useAuthStore();
  const [isDragging, setIsDragging] = useState(false);

  const tool = TOOLS.find(t => t.id === selectedTool);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = Array.from(e.dataTransfer.files);
    handleFiles(files);
  }, []);

  const handleFileInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files ? Array.from(e.target.files) : [];
    handleFiles(files);
  }, []);

  const handleFiles = (files: globalThis.File[]) => {
    files.forEach(file => {
      const fileType: 'image' | 'pdf' = file.type.startsWith('image/') ? 'image' : 'pdf';
      const newFile = {
        id: Math.random().toString(36).substring(7),
        name: file.name,
        originalName: file.name,
        type: fileType,
        mimeType: file.type,
        size: file.size,
        url: URL.createObjectURL(file),
        status: 'pending' as const,
        createdAt: new Date(),
      };
      addUploadedFile(newFile);
    });
  };

  const handleProcess = async () => {
    setProcessingStatus('processing');
    
    // Simulate processing
    for (let i = 0; i <= 100; i += 10) {
      setProcessingProgress(i);
      await new Promise(resolve => setTimeout(resolve, 300));
    }
    
    setProcessingStatus('completed');
  };

  const handleDownload = () => {
    // Simulate download
    console.log('Downloading processed file...');
  };

  if (!tool || !isToolModalOpen) return null;

  const Icon = iconMap[tool.icon] || FileText;

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <AnimatePresence>
      {isToolModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={closeToolModal}
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ duration: 0.2 }}
            className="relative w-full max-w-2xl max-h-[90vh] overflow-auto bg-white dark:bg-slate-900 rounded-2xl shadow-2xl"
          >
            {/* Header */}
            <div className="sticky top-0 z-10 flex items-center justify-between p-6 border-b border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-slate-900/80 backdrop-blur-sm">
              <div className="flex items-center gap-4">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${tool.color} flex items-center justify-center`}>
                  <Icon className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                    {tool.name}
                  </h2>
                  <p className="text-sm text-slate-600 dark:text-slate-400">
                    {tool.description}
                  </p>
                </div>
              </div>
              <button
                onClick={closeToolModal}
                className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5 text-slate-500" />
              </button>
            </div>

            {/* Content */}
            <div className="p-6">
              {/* Premium Warning */}
              {tool.isPremium && user?.plan === 'free' && (
                <div className="mb-6 p-4 rounded-xl bg-amber-500/10 border border-amber-500/20">
                  <div className="flex items-start gap-3">
                    <Crown className="w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-semibold text-amber-700 dark:text-amber-400">
                        Pro Feature
                      </h4>
                      <p className="text-sm text-amber-600 dark:text-amber-300 mt-1">
                        This tool requires a Pro subscription. Upgrade to unlock all premium features.
                      </p>
                      <Button
                        onClick={openSignupModal}
                        size="sm"
                        className="mt-3 bg-amber-500 hover:bg-amber-600 text-white"
                      >
                        Upgrade to Pro
                      </Button>
                    </div>
                  </div>
                </div>
              )}

              {/* Upload Zone */}
              {processingStatus === 'idle' && (
                <>
                  <div
                    onDragOver={handleDragOver}
                    onDragLeave={handleDragLeave}
                    onDrop={handleDrop}
                    className={cn(
                      'relative border-2 border-dashed rounded-2xl p-10 text-center transition-all duration-300',
                      isDragging
                        ? 'border-purple-500 bg-purple-500/5'
                        : 'border-slate-300 dark:border-slate-700 hover:border-purple-500/50'
                    )}
                  >
                    <input
                      type="file"
                      multiple
                      onChange={handleFileInput}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                      accept={tool.allowedTypes?.join(',')}
                    />
                    <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-purple-500/10 flex items-center justify-center">
                      <Upload className="w-8 h-8 text-purple-500" />
                    </div>
                    <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-2">
                      Drop your files here
                    </h3>
                    <p className="text-sm text-slate-600 dark:text-slate-400 mb-4">
                      or click to browse from your computer
                    </p>
                    <Badge variant="outline" className="text-xs">
                      Max file size: {formatFileSize(tool.maxFileSize || 0)}
                    </Badge>
                  </div>

                  {/* Uploaded Files */}
                  {uploadedFiles.length > 0 && (
                    <div className="mt-6 space-y-3">
                      <h4 className="font-semibold text-slate-900 dark:text-white">
                        Uploaded Files ({uploadedFiles.length})
                      </h4>
                      {uploadedFiles.map((file) => (
                        <div
                          key={file.id}
                          className="flex items-center justify-between p-3 rounded-lg bg-slate-50 dark:bg-slate-800"
                        >
                          <div className="flex items-center gap-3">
                            {file.type === 'image' ? (
                              <Image className="w-5 h-5 text-blue-500" />
                            ) : (
                              <FileText className="w-5 h-5 text-red-500" />
                            )}
                            <div>
                              <p className="text-sm font-medium text-slate-900 dark:text-white truncate max-w-[200px]">
                                {file.name}
                              </p>
                              <p className="text-xs text-slate-500">
                                {formatFileSize(file.size)}
                              </p>
                            </div>
                          </div>
                          <button
                            onClick={() => removeUploadedFile(file.id)}
                            className="p-2 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                          >
                            <X className="w-4 h-4 text-slate-500" />
                          </button>
                        </div>
                      ))}

                      <Button
                        onClick={handleProcess}
                        disabled={tool.isPremium && user?.plan === 'free'}
                        className="w-full bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 text-white hover:opacity-90"
                      >
                        Process Files
                      </Button>
                    </div>
                  )}
                </>
              )}

              {/* Processing */}
              {processingStatus === 'processing' && (
                <div className="text-center py-10">
                  <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-purple-500/10 flex items-center justify-center">
                    <Loader2 className="w-10 h-10 text-purple-500 animate-spin" />
                  </div>
                  <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-2">
                    Processing your files...
                  </h3>
                  <p className="text-sm text-slate-600 dark:text-slate-400 mb-6">
                    This may take a few moments
                  </p>
                  <div className="max-w-xs mx-auto">
                    <Progress value={processingProgress} className="h-2" />
                    <p className="text-sm text-slate-500 mt-2">{processingProgress}%</p>
                  </div>
                </div>
              )}

              {/* Completed */}
              {processingStatus === 'completed' && (
                <div className="text-center py-10">
                  <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-green-500/10 flex items-center justify-center">
                    <Check className="w-10 h-10 text-green-500" />
                  </div>
                  <h3 className="text-lg font-semibold text-slate-900 dark:text-white mb-2">
                    Processing complete!
                  </h3>
                  <p className="text-sm text-slate-600 dark:text-slate-400 mb-6">
                    Your files have been processed successfully
                  </p>
                  <Button
                    onClick={handleDownload}
                    className="bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 text-white hover:opacity-90"
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Download Result
                  </Button>
                </div>
              )}
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
