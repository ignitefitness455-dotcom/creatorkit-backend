/** @type {import('next').NextConfig} */
const nextConfig = {
  distDir: '/tmp/creatorhub-dist',
  images: {
    unoptimized: true,
  },
}

module.exports = nextConfig
