# CreatorHub - File Processing & Tools System

## Overview

This document describes the complete file upload, processing, and tools system built for CreatorHub.

## Features Implemented

### 1. AWS S3 / Cloudflare R2 Integration

**Location**: `src/lib/s3.ts`

- **Presigned URL Generation**: Secure direct-to-S3 uploads without server bottleneck
- **File Validation**: MIME type and size validation
- **Multiple Storage Providers**: Support for both AWS S3 and Cloudflare R2
- **File Size Limits by Plan**:
  - FREE: 10MB
  - PRO: 100MB
  - BUSINESS: 500MB

**Environment Variables**:
```env
STORAGE_PROVIDER="s3"  # or "r2"
AWS_REGION="us-east-1"
AWS_ACCESS_KEY_ID=""
AWS_SECRET_ACCESS_KEY=""
AWS_BUCKET_NAME="creatorhub-uploads"
R2_ENDPOINT=""
R2_PUBLIC_URL=""
```

### 2. File Processing Queue (BullMQ + Redis)

**Location**: `src/lib/queue.ts`

- **Background Job Processing**: Non-blocking file operations
- **Job Types**: pdf-compress, pdf-merge, image-convert, video-compress, etc.
- **Status Tracking**: PENDING → PROCESSING → COMPLETED/FAILED
- **Progress Updates**: Real-time progress (0-100%)
- **Retry Logic**: Exponential backoff for failed jobs

**Redis Configuration**:
```env
REDIS_URL="redis://localhost:6379"
# Or Upstash: redis://default:<password>@<host>:<port>
```

### 3. Tool Data Structure (24 Tools)

**Location**: `src/data/tools.ts`

#### Categories & Tools:

**PDF Tools (6)**:
- PDF Compressor (FREE)
- PDF Merger (FREE)
- PDF Splitter (FREE)
- PDF to Word (PRO)
- PDF to Image (FREE)
- PDF OCR (PRO)

**Image Tools (6)**:
- Image Compressor (FREE)
- Image Converter (FREE)
- Image Resizer (FREE)
- Background Remover (PRO) - AI-powered
- AI Image Upscaler (PRO)
- Watermark Tool (PRO)

**Video Tools (3)**:
- Video Compressor (PRO)
- Video to GIF (FREE)
- Video Trimmer (PRO)

**Audio Tools (3)**:
- Audio Converter (FREE)
- Audio Trimmer (FREE)
- Audio Joiner (PRO)

**Social Media Tools (3)**:
- Social Media Resizer (FREE)
- Instagram Story Maker (PRO)
- YouTube Thumbnail Maker (PRO)

**Business Tools (3)**:
- QR Code Generator (FREE)
- Invoice Generator (PRO)
- Presentation Maker (PRO)

**Tool Schema**:
```typescript
interface Tool {
  id: string
  name: string
  description: string
  category: "pdf" | "image" | "video" | "audio" | "social" | "business"
  icon: LucideIcon
  color: string
  gradient: string
  maxFileSize: number
  allowedTypes: string[]
  isPremium: boolean
  rating: number
  reviewCount: number
  features: string[]
}
```

### 4. Tool Card Component

**Location**: `src/components/tools/tool-card.tsx`

**Features**:
- **Hover Spotlight Effect**: Mouse-tracking gradient glow
- **Category Badge**: Color-coded by category (PDF: red, Image: blue, etc.)
- **Premium Badge**: Crown icon with "PRO" label
- **Star Rating**: 4.5-5.0 rating display with review count
- **Feature Tags**: First 2 features + count
- **Smooth Animations**: Framer Motion entrance and hover effects
- **Gradient Icon Background**: Category-specific gradients

### 5. Category Filter

**Location**: `src/components/tools/category-filter.tsx`

**Features**:
- **Animated Pills**: Smooth layout transition with `layoutId`
- **Categories**: All, PDF, Image, Video, Audio, Social, Business
- **Active State**: Gradient background with shadow
- **Hover Effects**: Scale and color transitions

### 6. Upload Zone Component

**Location**: `src/components/tools/upload-zone.tsx`

**Features**:
- **Drag & Drop**: react-dropzone integration
- **File Type Validation**: Shows allowed formats
- **Size Validation**: Displays max file size
- **Progress Bar**: Animated upload progress
- **Image Preview**: Thumbnail for image files
- **Error Handling**: Invalid type/size error messages
- **File List**: Manage multiple files
- **Remove Files**: Individual file removal

**Props**:
```typescript
interface UploadZoneProps {
  allowedTypes?: string[]
  maxFileSize?: number
  maxFiles?: number
  onUpload?: (files: UploadFile[]) => void
  onFileSelect?: (file: File) => void
}
```

### 7. API Routes

#### POST /api/upload/presigned
Generate presigned URL for direct S3 upload.

**Request**:
```json
{
  "fileName": "document.pdf",
  "fileType": "application/pdf",
  "fileSize": 5242880,
  "toolId": "pdf-compress"
}
```

**Response**:
```json
{
  "presignedUrl": "https://s3.amazonaws.com/...",
  "fileId": "cl...",
  "key": "uploads/user-id/...",
  "expiresIn": 300
}
```

**Features**:
- Credit check before upload
- File size validation by plan
- File type validation
- Automatic credit deduction

#### GET /api/files
Get user's files with pagination.

**Query Params**:
- `status`: PENDING | PROCESSING | COMPLETED | FAILED
- `toolId`: Filter by tool
- `limit`: Number of results (default: 20)
- `offset`: Pagination offset

**Response**:
```json
{
  "files": [...],
  "pagination": {
    "total": 100,
    "limit": 20,
    "offset": 0,
    "hasMore": true
  }
}
```

#### POST /api/files
Create file record after upload.

#### GET /api/files/:id
Get file details with job status and download URL.

**Response**:
```json
{
  "file": { ... },
  "jobStatus": {
    "id": "...",
    "state": "completed",
    "progress": 100
  },
  "downloadUrl": "https://s3.amazonaws.com/..."
}
```

#### PATCH /api/files/:id
Update file status, URL, metadata.

#### DELETE /api/files/:id
Delete file (DB + S3).

### 8. Tools Page

**Location**: `src/app/tools/page.tsx`

**Features**:
- **Hero Section**: Gradient title with tool count
- **Sticky Filter Bar**: Category pills + search
- **Responsive Grid**: 1-4 columns based on screen size
- **Animated Grid**: Framer Motion layout animations
- **Search**: Real-time tool filtering
- **Tool Modal**: Opens on card click with upload zone
- **Empty State**: No results message

### 9. Database Schema Updates

**Location**: `prisma/schema.prisma`

#### File Model:
```prisma
model File {
  id           String     @id @default(cuid())
  userId       String
  name         String
  originalName String
  type         FileType   // PDF | IMAGE | VIDEO | AUDIO | DOCUMENT
  mimeType     String
  size         Int
  url          String
  thumbnailUrl String?
  status       FileStatus @default(PENDING)
  metadata     Json?      // Tool-specific data
  toolId       String?
  errorMessage String?
  createdAt    DateTime   @default(now())
  updatedAt    DateTime   @updatedAt
  
  user User @relation(fields: [userId], references: [id], onDelete: Cascade)
  
  @@index([userId])
  @@index([status])
  @@index([toolId])
}
```

#### Job Model:
```prisma
model Job {
  id          String   @id @default(cuid())
  fileId      String   @unique
  type        String
  status      String
  progress    Int      @default(0)
  result      Json?
  error       String?
  startedAt   DateTime?
  completedAt DateTime?
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
  
  @@index([status])
  @@index([fileId])
}
```

## File Upload Flow

```
1. User selects file in Tool Modal
   ↓
2. Frontend requests presigned URL
   POST /api/upload/presigned
   ↓
3. Server validates:
   - User authentication
   - Credit balance
   - File size (plan-based)
   - File type
   ↓
4. Server creates File record (status: PENDING)
   Deducts 1 credit
   ↓
5. Server returns presigned URL
   ↓
6. Frontend uploads directly to S3
   ↓
7. On success, frontend updates File status
   PATCH /api/files/:id { status: "PROCESSING" }
   ↓
8. Server adds job to BullMQ queue
   ↓
9. Worker processes file
   Updates progress (0-100%)
   ↓
10. On completion:
    - Update File status: COMPLETED
    - Update Job status: COMPLETED
    - Generate download URL
```

## Usage Example

```typescript
import { UploadZone } from "@/components/tools/upload-zone"
import { getToolById } from "@/data/tools"

const tool = getToolById("image-compress")

function ToolPage() {
  const handleFileSelect = async (file: File) => {
    // 1. Get presigned URL
    const { presignedUrl, fileId } = await fetch("/api/upload/presigned", {
      method: "POST",
      body: JSON.stringify({
        fileName: file.name,
        fileType: file.type,
        fileSize: file.size,
        toolId: tool.id,
      }),
    }).then(r => r.json())

    // 2. Upload to S3
    await fetch(presignedUrl, {
      method: "PUT",
      body: file,
      headers: { "Content-Type": file.type },
    })

    // 3. Start processing
    await fetch(`/api/files/${fileId}`, {
      method: "PATCH",
      body: JSON.stringify({ status: "PROCESSING" }),
    })
  }

  return (
    <UploadZone
      allowedTypes={tool.allowedTypes}
      maxFileSize={tool.maxFileSize}
      onFileSelect={handleFileSelect}
    />
  )
}
```

## Environment Setup

```bash
# 1. Install dependencies
npm install

# 2. Setup PostgreSQL
docker-compose up -d db

# 3. Setup Redis (optional, for queue)
docker run -d -p 6379:6379 redis:alpine

# 4. Configure environment
cp .env.example .env
# Edit .env with your credentials

# 5. Setup database
npx prisma generate
npx prisma db push

# 6. Run development server
npm run dev
```

## File Structure

```
src/
├── app/
│   ├── api/
│   │   ├── upload/
│   │   │   └── presigned/
│   │   │       └── route.ts
│   │   └── files/
│   │       ├── route.ts
│   │       └── [id]/
│   │           └── route.ts
│   └── tools/
│       └── page.tsx
├── components/
│   └── tools/
│       ├── tool-card.tsx
│       ├── category-filter.tsx
│       └── upload-zone.tsx
├── data/
│   └── tools.ts
├── lib/
│   ├── s3.ts
│   └── queue.ts
└── ...
```

## Next Steps

1. **Implement actual file processing**: Replace `simulateProcessing` with real tool logic
2. **Add WebSocket/SSE**: Real-time progress updates to client
3. **Implement tool processors**: PDF-lib, Sharp, FFmpeg integration
4. **Add file cleanup**: Cron job to delete old files
5. **Add usage analytics**: Track tool usage, popular files
6. **Implement batch processing**: Multiple files at once
