# CreatorHub Tools - Implementation Guide

## Overview

This document describes all 14 implemented tools (8 PDF + 6 Image) with their API endpoints, processing logic, and usage examples.

## PDF Tools (8)

### 1. PDF Merge
**Endpoint**: `POST /api/tools/pdf/merge`

Merge multiple PDFs into a single document.

**Request**:
```json
{
  "fileIds": ["file-id-1", "file-id-2", "file-id-3"]
}
```

**Response**:
```json
{
  "success": true,
  "downloadUrl": "https://s3.amazonaws.com/...",
  "outputKey": "processed/user-id/merged-123.pdf",
  "pageCount": 15,
  "fileSize": 2456789
}
```

**Processor**: `src/lib/processors/pdf/merge.ts`
- Uses `pdf-lib` to merge PDFs
- Preserves all page content
- Progress tracking: 5% → 10% → 65% → 75% → 90% → 100%

---

### 2. PDF Split
**Endpoint**: `POST /api/tools/pdf/split`

Extract specific pages or split by ranges.

**Request**:
```json
{
  "fileId": "file-id-1",
  "ranges": [
    { "start": 1, "end": 5 },
    { "start": 6, "end": 10 }
  ]
}
```

**Response**:
```json
{
  "success": true,
  "results": [
    {
      "downloadUrl": "https://s3.amazonaws.com/...",
      "pageCount": 5,
      "range": "1-5"
    },
    {
      "downloadUrl": "https://s3.amazonaws.com/...",
      "pageCount": 5,
      "range": "6-10"
    }
  ],
  "totalPages": 10
}
```

**Processor**: `src/lib/processors/pdf/split.ts`
- Validates page ranges
- Creates separate PDFs for each range

---

### 3. PDF Compress
**Endpoint**: `POST /api/tools/pdf/compress`

Reduce PDF file size.

**Request**:
```json
{
  "fileId": "file-id-1",
  "quality": "medium"  // "low" | "medium" | "high"
}
```

**Response**:
```json
{
  "success": true,
  "downloadUrl": "https://s3.amazonaws.com/...",
  "originalSize": 5242880,
  "compressedSize": 2097152,
  "compressionRatio": "60.0%",
  "pageCount": 10
}
```

**Processor**: `src/lib/processors/pdf/compress.ts`
- Uses `pdf-lib` object stream compression
- For better compression, integrate Ghostscript

---

### 4. PDF to Images (JPG/PNG)
**Endpoint**: `POST /api/tools/pdf/to-images`

Convert PDF pages to images.

**Request**:
```json
{
  "fileId": "file-id-1",
  "format": "png",
  "dpi": 150,
  "pageRange": { "start": 1, "end": 5 }  // Optional
}
```

**Response**:
```json
{
  "success": true,
  "downloadUrl": "https://s3.amazonaws.com/...",
  "format": "png",
  "pageCount": 5,
  "isZip": true
}
```

**Processor**: `src/lib/processors/pdf/to-images.ts`
- Uses `pdf2pic` for conversion
- Returns ZIP for multiple pages
- Supports JPG, PNG, WebP

---

### 5. PDF to Word (DOCX)
**Endpoint**: `POST /api/tools/pdf/to-word`

Convert PDF to editable Word document.

**Request**:
```json
{
  "fileId": "file-id-1",
  "format": "docx"
}
```

**Response**:
```json
{
  "success": true,
  "downloadUrl": "https://s3.amazonaws.com/...",
  "format": "docx",
  "originalSize": 1048576,
  "convertedSize": 524288
}
```

**Processor**: `src/lib/processors/pdf/to-word.ts`
- Tries LibreOffice first
- Fallback to text extraction
- For production: Use dedicated PDF-to-DOCX service

---

### 6. PDF to Excel
**Endpoint**: `POST /api/tools/pdf/to-excel`

Extract tables from PDF to Excel/CSV.

**Request**:
```json
{
  "fileId": "file-id-1",
  "format": "xlsx",
  "extractTables": true
}
```

**Response**:
```json
{
  "success": true,
  "downloadUrl": "https://s3.amazonaws.com/...",
  "format": "xlsx",
  "rowCount": 150,
  "pageCount": 3
}
```

**Processor**: `src/lib/processors/pdf/to-excel.ts`
- Uses `pdf-parse` for text extraction
- Auto-detects table delimiters
- Generates XLSX with `xlsx` library

---

### 7. PDF Rotate
**Endpoint**: `POST /api/tools/pdf/rotate`

Rotate PDF pages.

**Request**:
```json
{
  "fileId": "file-id-1",
  "angle": 90,  // 90 | 180 | 270
  "pages": "all"  // "all" | [1, 3, 5]
}
```

**Response**:
```json
{
  "success": true,
  "downloadUrl": "https://s3.amazonaws.com/...",
  "rotatedPages": 10,
  "angle": 90,
  "pageCount": 10
}
```

**Processor**: `src/lib/processors/pdf/rotate.ts`
- Uses `pdf-lib` rotation
- Supports specific pages or all

---

### 8. PDF eSign
**Endpoint**: `POST /api/tools/pdf/esign`

Add signature image to PDF.

**Request**:
```json
{
  "fileId": "file-id-1",
  "signatureBase64": "data:image/png;base64,iVBORw0KGgo...",
  "position": {
    "page": 1,
    "x": 100,
    "y": 100,
    "width": 150,
    "height": 50
  }
}
```

**Response**:
```json
{
  "success": true,
  "downloadUrl": "https://s3.amazonaws.com/...",
  "pageNumber": 1,
  "position": { "x": 100, "y": 100, "width": 150, "height": 50 }
}
```

**Processor**: `src/lib/processors/pdf/esign.ts`
- Embeds PNG signature
- Position in PDF coordinates

---

## Image Tools (6)

### 1. Image Compress
**Endpoint**: `POST /api/tools/image/compress`

Compress images with quality control.

**Request**:
```json
{
  "fileId": "file-id-1",
  "quality": 80,  // 1-100
  "format": "webp",
  "maxWidth": 1920,
  "maxHeight": 1080
}
```

**Response**:
```json
{
  "success": true,
  "downloadUrl": "https://s3.amazonaws.com/...",
  "format": "webp",
  "quality": 80,
  "originalSize": 2097152,
  "compressedSize": 524288,
  "compressionRatio": "75.0%",
  "width": 1920,
  "height": 1080
}
```

**Processor**: `src/lib/processors/image/compress.ts`
- Uses `sharp` library
- Supports JPEG, PNG, WebP
- Lanczos3 resampling

---

### 2. Background Remover
**Endpoint**: `POST /api/tools/image/remove-bg`

Remove image background using AI.

**Request**:
```json
{
  "fileId": "file-id-1"
}
```

**Response**:
```json
{
  "success": true,
  "downloadUrl": "https://s3.amazonaws.com/...",
  "format": "png",
  "hasTransparency": true
}
```

**Processor**: `src/lib/processors/image/remove-bg.ts`
- Primary: `remove.bg` API
- Alternative: Replicate SAM model
- Returns transparent PNG

**Environment**:
```env
REMOVE_BG_API_KEY="your-api-key"
# or
REPLICATE_API_TOKEN="your-token"
```

---

### 3. AI Image Upscaler
**Endpoint**: `POST /api/tools/image/upscale`

Upscale images 2x or 4x.

**Request**:
```json
{
  "fileId": "file-id-1",
  "scale": 4,  // 2 | 4
  "useAI": true
}
```

**Response**:
```json
{
  "success": true,
  "downloadUrl": "https://s3.amazonaws.com/...",
  "scale": 4,
  "method": "AI (Real-ESRGAN)",
  "width": 3840,
  "height": 2160
}
```

**Processor**: `src/lib/processors/image/upscale.ts`
- AI mode: Replicate Real-ESRGAN
- Fallback: Sharp Lanczos3
- Face enhancement option

---

### 4. Screenshot Pro
**Endpoint**: `POST /api/tools/image/screenshot`

Capture webpage screenshots.

**Request**:
```json
{
  "url": "https://example.com",
  "fullPage": true,
  "width": 1920,
  "height": 1080,
  "delay": 2000,
  "format": "png",
  "quality": 90
}
```

**Response**:
```json
{
  "success": true,
  "downloadUrl": "https://s3.amazonaws.com/...",
  "url": "https://example.com",
  "format": "png",
  "fullPage": true,
  "width": 1920,
  "height": 1080
}
```

**Processor**: `src/lib/processors/image/screenshot.ts`
- Uses Puppeteer
- Headless Chrome
- Auto-accepts cookies
- Retina quality (2x)

---

### 5. Images to PDF
**Endpoint**: `POST /api/tools/image/to-pdf`

Convert multiple images to PDF.

**Request**:
```json
{
  "fileIds": ["file-id-1", "file-id-2"],
  "pageSize": "A4",  // "A4" | "Letter" | "Original"
  "orientation": "portrait"
}
```

**Response**:
```json
{
  "success": true,
  "downloadUrl": "https://s3.amazonaws.com/...",
  "imageCount": 2,
  "pageCount": 2,
  "pageSize": "A4",
  "orientation": "portrait"
}
```

**Processor**: `src/lib/processors/image/to-pdf.ts`
- Uses `sharp` + `pdf-lib`
- Auto-centers images
- Maintains aspect ratio

---

### 6. Color Extractor
**Endpoint**: `POST /api/tools/image/extract-colors`

Extract dominant colors from image.

**Request**:
```json
{
  "fileId": "file-id-1",
  "colorCount": 6
}
```

**Response**:
```json
{
  "success": true,
  "colors": [
    {
      "hex": "#FF5733",
      "rgb": { "r": 255, "g": 87, "b": 51 },
      "population": 2456,
      "name": "Vibrant"
    }
  ],
  "dominantColor": { "hex": "#FF5733", ... },
  "colorCount": 6
}
```

**Processor**: `src/lib/processors/image/color-extractor.ts`
- Uses `node-vibrant`
- Returns Vibrant, Muted, Dark/Light variants
- Sorted by population (dominance)

---

## File Cleanup

**Location**: `src/lib/cleanup.ts`

Automatically deletes processed files after 1 hour.

```typescript
// Start scheduler (in server startup)
import { startCleanupScheduler } from "@/lib/cleanup"
startCleanupScheduler()

// Manual cleanup
import { manualCleanup, getCleanupStats } from "@/lib/cleanup"
const { deleted, failed, total } = await manualCleanup(2) // 2 hours
const stats = await getCleanupStats()
```

---

## Progress Tracking

All tools support progress callbacks:

```typescript
const result = await mergePDFs({
  fileIds: ["id1", "id2"],
  userId: "user-id",
  onProgress: (progress) => {
    // Send to client via SSE or WebSocket
    console.log(`${progress}%`)
  },
})
```

---

## Error Handling

All APIs return consistent error format:

```json
{
  "error": "Human-readable error message"
}
```

Common HTTP status codes:
- `400` - Invalid input
- `401` - Unauthorized
- `404` - File not found
- `413` - File too large
- `415` - Unsupported file type
- `500` - Processing error

---

## Environment Variables

```env
# Storage
AWS_BUCKET_NAME="creatorhub-uploads"
AWS_REGION="us-east-1"
AWS_ACCESS_KEY_ID=""
AWS_SECRET_ACCESS_KEY=""

# External APIs
REMOVE_BG_API_KEY=""
REPLICATE_API_TOKEN=""

# Redis (for queue)
REDIS_URL="redis://localhost:6379"
```

---

## Testing Tools

```bash
# Test PDF merge
curl -X POST http://localhost:3000/api/tools/pdf/merge \
  -H "Content-Type: application/json" \
  -H "Cookie: next-auth.session-token=..." \
  -d '{"fileIds": ["id1", "id2"]}'

# Test image compress
curl -X POST http://localhost:3000/api/tools/image/compress \
  -H "Content-Type: application/json" \
  -H "Cookie: next-auth.session-token=..." \
  -d '{"fileId": "id1", "quality": 80}'
```
