# CreatorHub - Full-Stack Creative Tools Platform

A powerful SaaS platform with 30+ creative tools including PDF processing, image editing, AI content generation, and social media tools.

## Features

### PDF Tools
- PDF Merge, Split, Compress
- PDF to Word/Excel/PPT conversion
- PDF to JPG conversion
- PDF Rotate

### Image Tools
- Image Compress, Convert, Resize
- Image Crop, Rotate, Flip
- Watermark addition
- Background removal

### AI Tools
- Text generation
- Image generation (DALL-E)
- Code generation
- Translation
- Summarization

### Social Media Tools
- Caption generator
- Hashtag generator
- Bio generator
- Engagement calculator

### Business Tools
- QR Code generator
- Invoice generator
- Password generator
- EMI calculator
- Unit converter

## Tech Stack

### Frontend
- React 18 + TypeScript
- Vite (build tool)
- Tailwind CSS
- shadcn/ui components
- Framer Motion (animations)
- Zustand (state management)

### Backend
- Express.js + TypeScript
- Prisma ORM
- PostgreSQL
- JWT Authentication
- Stripe Payments
- OpenAI Integration

## Project Structure

```
creatorhub-fullstack/
├── backend/              # Express.js API
│   ├── src/
│   │   ├── config/       # Database, Redis, Env config
│   │   ├── middleware/   # Auth, error handling, rate limiting
│   │   ├── routes/       # API routes
│   │   ├── services/     # Business logic
│   │   ├── types/        # TypeScript types
│   │   └── utils/        # Helper functions
│   ├── prisma/           # Database schema & migrations
│   ├── uploads/          # Upload directory
│   ├── outputs/          # Output directory
│   ├── railway.toml      # Railway deployment config
│   └── nixpacks.toml     # Nixpacks build config
│
├── frontend/             # React SPA
│   ├── src/
│   │   ├── components/   # UI components
│   │   ├── pages/        # Route pages
│   │   ├── hooks/        # Custom React hooks
│   │   ├── lib/          # Utilities
│   │   ├── services/     # API calls
│   │   ├── store/        # Zustand stores
│   │   └── types/        # TypeScript types
│   └── public/           # Static assets
│
└── DEPLOYMENT.md         # Full deployment guide
```

## Quick Start (Local Development)

### Prerequisites
- Node.js 18+
- PostgreSQL database

### 1. Clone and Install

```bash
git clone https://github.com/yourusername/creatorhub.git
cd creatorhub-fullstack

# Install all dependencies
npm run install:all
```

### 2. Setup Database

```bash
# Copy environment file
cd backend
cp .env.example .env

# Edit .env with your database URL
DATABASE_URL="postgresql://user:password@localhost:5432/creatorhub"
JWT_SECRET="your-secret-key"
JWT_REFRESH_SECRET="your-refresh-secret"

# Generate Prisma client
npx prisma generate

# Run migrations
npx prisma migrate dev

# Seed database (optional)
npx prisma db seed
```

### 3. Start Development Servers

```bash
# From root directory
npm run dev

# Or start separately
cd backend && npm run dev
cd frontend && npm run dev
```

- Frontend: http://localhost:5173
- Backend: http://localhost:5000

## Deployment

See [DEPLOYMENT.md](./DEPLOYMENT.md) for detailed deployment instructions.

### Quick Deploy

**Backend (Railway)**:
1. Push backend to GitHub
2. Create Railway project from GitHub repo
3. Add PostgreSQL database
4. Set environment variables
5. Deploy

**Frontend (Vercel)**:
1. Push frontend to GitHub
2. Import to Vercel
3. Set `VITE_API_URL` to your backend URL
4. Deploy

## Environment Variables

### Backend
```env
DATABASE_URL=postgresql://...
JWT_SECRET=your-secret
JWT_REFRESH_SECRET=your-refresh-secret
FRONTEND_URL=https://your-frontend.com
STRIPE_SECRET_KEY=sk_...
OPENAI_API_KEY=sk-...
```

### Frontend
```env
VITE_API_URL=https://your-backend.com/api
```

## API Endpoints

### Auth
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user
- `POST /api/auth/refresh` - Refresh access token
- `GET /api/auth/me` - Get current user

### Tools
- `GET /api/tools` - List all tools
- `GET /api/tools/:id` - Get tool details
- `POST /api/tools/pdf-merge` - Merge PDFs
- `POST /api/tools/image-compress` - Compress images
- `POST /api/tools/qr-generator` - Generate QR codes
- `POST /api/tools/ai-text` - Generate text with AI

### User
- `GET /api/user/dashboard` - Get dashboard data
- `GET /api/user/files` - List user files
- `GET /api/user/payments` - List payments

### Payments
- `GET /api/payments/config` - Get payment config
- `POST /api/payments/checkout` - Create checkout session

## License

MIT License - feel free to use for personal or commercial projects.

## Support

For issues or questions, please open a GitHub issue.
