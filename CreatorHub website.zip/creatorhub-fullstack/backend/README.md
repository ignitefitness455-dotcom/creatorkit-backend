# CreatorHub Backend API

A powerful backend API for CreatorHub - a comprehensive content creation toolkit with PDF tools, image processing, AI features, and more.

## Features

- **Authentication**: JWT-based auth with access and refresh tokens
- **PDF Tools**: Merge, split, compress, rotate, convert PDFs
- **Image Tools**: Compress, convert, resize, crop, watermark images
- **AI Tools**: Text generation, image generation, code generation, translation
- **Social Media Tools**: Hashtag generator, caption writer, bio generator
- **Business Tools**: QR code generator, password generator, EMI calculator
- **Payments**: Stripe integration for subscriptions
- **File Storage**: Local storage with optional AWS S3 integration

## Tech Stack

- **Runtime**: Node.js 18+
- **Language**: TypeScript
- **Framework**: Express.js
- **Database**: PostgreSQL with Prisma ORM
- **Cache**: Redis (optional, with in-memory fallback)
- **File Processing**: Sharp (images), pdf-lib (PDFs)
- **AI**: OpenAI GPT-4 & DALL-E
- **Payments**: Stripe

## Quick Start

### Prerequisites

- Node.js 18 or higher
- PostgreSQL database
- (Optional) Redis server
- (Optional) AWS S3 bucket
- (Optional) Stripe account
- (Optional) OpenAI API key

### Installation

1. Clone the repository:
```bash
git clone <your-repo-url>
cd creatorhub-backend
```

2. Install dependencies:
```bash
npm install
```

3. Set up environment variables:
```bash
cp .env.example .env
# Edit .env with your configuration
```

4. Set up the database:
```bash
npx prisma migrate deploy
npx prisma generate
```

5. (Optional) Seed the database:
```bash
npm run db:seed
```

6. Start the server:
```bash
# Development
npm run dev

# Production
npm run build
npm start
```

## Environment Variables

See `.env.example` for all available environment variables.

### Required Variables

| Variable | Description |
|----------|-------------|
| `DATABASE_URL` | PostgreSQL connection string |
| `JWT_SECRET` | Secret key for JWT signing (min 32 chars) |
| `JWT_REFRESH_SECRET` | Secret key for refresh tokens (min 32 chars) |

### Optional Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `NODE_ENV` | Environment mode | `development` |
| `PORT` | Server port | `5000` |
| `FRONTEND_URL` | Frontend URL for CORS | `http://localhost:5173` |
| `REDIS_URL` | Redis connection URL | - |
| `AWS_*` | AWS S3 configuration | - |
| `STRIPE_*` | Stripe payment configuration | - |
| `OPENAI_API_KEY` | OpenAI API key | - |

## API Documentation

### Base URL

```
http://localhost:5000/api
```

### Endpoints

#### Health Check
- `GET /health` - Check server health

#### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user
- `POST /api/auth/refresh` - Refresh access token
- `GET /api/auth/me` - Get current user
- `PATCH /api/auth/profile` - Update profile
- `POST /api/auth/change-password` - Change password
- `POST /api/auth/logout` - Logout user

#### Tools
- `GET /api/tools` - List all tools
- `GET /api/tools/:id` - Get tool details
- `GET /api/tools/categories` - Get tool categories
- `POST /api/tools/pdf-merge` - Merge PDFs
- `POST /api/tools/pdf-split` - Split PDF
- `POST /api/tools/pdf-compress` - Compress PDF
- `POST /api/tools/image-compress` - Compress image
- `POST /api/tools/image-convert` - Convert image format
- `POST /api/tools/qr-generator` - Generate QR code
- `POST /api/tools/ai-text` - Generate AI text
- `POST /api/tools/ai-image` - Generate AI image
- ... and more

#### User
- `GET /api/user/dashboard` - Get dashboard data
- `GET /api/user/files` - Get user files
- `GET /api/user/payments` - Get payment history
- `GET /api/user/stats` - Get user statistics
- `DELETE /api/user/files/:id` - Delete a file

#### Payments
- `GET /api/payments/config` - Get payment configuration
- `POST /api/payments/checkout` - Create checkout session
- `POST /api/payments/portal` - Create customer portal session
- `GET /api/payments/subscription/:id` - Get subscription details
- `POST /api/payments/subscription/:id/cancel` - Cancel subscription

## Deployment

### Railway (Recommended)

1. Push your code to GitHub
2. Connect your GitHub repo to Railway
3. Add environment variables in Railway dashboard
4. Add PostgreSQL database from Railway
5. Deploy!

See `DEPLOYMENT.md` for detailed instructions.

### Other Platforms

The backend can be deployed to any platform that supports Node.js:
- Heroku
- Render
- DigitalOcean App Platform
- AWS Elastic Beanstalk
- Google Cloud Run

## Database Schema

```prisma
model User {
  id        String   @id @default(uuid())
  email     String   @unique
  password  String?
  name      String?
  image     String?
  plan      Plan     @default(FREE)
  credits   Int      @default(50)
  files     File[]
  payments  Payment[]
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
}

model File {
  id           String     @id @default(uuid())
  userId       String
  user         User       @relation(fields: [userId], references: [id])
  name         String
  originalName String
  mimeType     String
  size         Int
  url          String
  toolId       String?
  status       FileStatus @default(PENDING)
  createdAt    DateTime   @default(now())
}

model Payment {
  id        String        @id @default(uuid())
  userId    String
  user      User          @relation(fields: [userId], references: [id])
  amount    Int
  currency  String        @default("usd")
  status    PaymentStatus @default(PENDING)
  plan      Plan
  createdAt DateTime      @default(now())
}
```

## File Structure

```
backend/
├── src/
│   ├── config/         # Configuration files
│   ├── middleware/     # Express middleware
│   ├── routes/         # API routes
│   ├── services/       # Business logic
│   ├── types/          # TypeScript types
│   ├── utils/          # Utility functions
│   └── server.ts       # Entry point
├── prisma/
│   ├── schema.prisma   # Database schema
│   └── migrations/     # Database migrations
├── uploads/            # Uploaded files (gitignored)
├── outputs/            # Processed files (gitignored)
├── .env.example        # Example environment variables
├── package.json        # Dependencies
├── tsconfig.json       # TypeScript config
├── railway.toml        # Railway deployment config
└── nixpacks.toml       # Nixpacks build config
```

## Scripts

| Command | Description |
|---------|-------------|
| `npm run dev` | Start development server with hot reload |
| `npm run build` | Build for production |
| `npm start` | Start production server |
| `npm run db:migrate` | Run database migrations |
| `npm run db:generate` | Generate Prisma client |
| `npm run db:studio` | Open Prisma Studio |
| `npm run db:seed` | Seed database |
| `npm run clean` | Remove build directory |

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## License

MIT License - see LICENSE file for details

## Support

For support, email support@creatorhub.com or join our Discord community.
