#!/bin/bash

# CreatorHub Backend Deployment Script for Railway

echo "🚀 Starting deployment process..."

# Install dependencies
echo "📦 Installing dependencies..."
npm ci

# Generate Prisma client
echo "🔧 Generating Prisma client..."
npx prisma generate

# Run database migrations
echo "🗄️  Running database migrations..."
npx prisma migrate deploy

# Build TypeScript
echo "🏗️  Building TypeScript..."
npm run build

# Create necessary directories
echo "📁 Creating directories..."
mkdir -p uploads outputs

# Start the server
echo "✅ Starting server..."
npm run start
