# Railway Deployment Guide for CreatorHub Backend

## Prerequisites

1. Railway account (https://railway.app)
2. GitHub account (to push your code)

## Step-by-Step Deployment

### 1. Push Code to GitHub

```bash
cd /mnt/okcomputer/output/creatorhub-fullstack/backend
git init
git add .
git commit -m "Initial commit"
git branch -M main
# Create a new repository on GitHub and push
git remote add origin https://github.com/YOUR_USERNAME/creatorhub-backend.git
git push -u origin main
```

### 2. Create Railway Project

1. Go to https://railway.app/dashboard
2. Click "New Project"
3. Select "Deploy from GitHub repo"
4. Choose your repository

### 3. Add PostgreSQL Database

1. In your Railway project, click "New"
2. Select "Database" → "Add PostgreSQL"
3. Railway will automatically create the database and set `DATABASE_URL`

### 4. Configure Environment Variables

Go to your service Variables tab and add these (Railway may auto-generate some):

```
# Required
DATABASE_URL=${{Postgres.DATABASE_URL}}  # This is auto-set by Railway
JWT_SECRET=your-super-secret-jwt-key-min-32-characters-long
JWT_REFRESH_SECRET=your-super-secret-refresh-key-min-32-characters-long

# Optional but recommended
NODE_ENV=production
FRONTEND_URL=https://your-frontend-url.vercel.app
PORT=5000
```

### 5. Deploy

Railway will automatically deploy when you push to GitHub, or you can:
1. Go to your service
2. Click "Deploy" button

### 6. Check Logs

If deployment fails:
1. Go to your service
2. Click "Deployments" tab
3. Check the logs for errors

## Common Issues and Solutions

### Issue 1: "Cannot find module '@prisma/client'"

**Solution**: The `postinstall` script should run `prisma generate`. Check that it's in package.json:
```json
"postinstall": "prisma generate || true"
```

### Issue 2: Database connection failed

**Solution**: 
- Ensure PostgreSQL is added to your project
- Check that `DATABASE_URL` is set correctly
- The URL format should be: `postgresql://user:password@host:port/database`

### Issue 3: Health check failing

**Solution**: 
- The `/health` endpoint is configured in server.ts
- Make sure the server starts on the correct PORT (5000)

### Issue 4: "Cannot find dist/server.js"

**Solution**: 
- The build process should create `dist/server.js`
- Check nixpacks.toml has the correct build commands

## Testing the Deployment

After successful deployment:

1. **Health Check**: Visit `https://your-app.railway.app/health`
   Should return: `{"status":"healthy","database":"connected"}`

2. **API Info**: Visit `https://your-app.railway.app/api`
   Should return API information

## Frontend Configuration

Update your frontend `.env` to point to the backend:

```
VITE_API_URL=https://your-app.railway.app/api
```

## Support

If you encounter issues:
1. Check Railway logs first
2. Ensure all environment variables are set
3. Verify the database is connected
