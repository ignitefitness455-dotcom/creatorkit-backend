import { Router } from 'express';
import { body, param, query, validationResult } from 'express-validator';
import { authenticate, optionalAuth } from '../middleware/auth';
import { uploadPdfMemory, uploadImageMemory } from '../middleware/upload';
import { toolRateLimiter } from '../middleware/rateLimiter';
import { prisma } from '../config/database';
import { tools, getToolById, getToolsByCategory, searchTools } from '../services/toolsData';
import { PdfService } from '../services/pdfService';
import { ImageService } from '../services/imageService';
import { QrService } from '../services/qrService';
import { AiService } from '../services/aiService';
import { FileService } from '../services/fileService';
import { BadRequestError, NotFoundError, UnauthorizedError } from '../utils/errors';

const router = Router();

// Validation middleware
const validate = (req: any, res: any, next: any) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({
      success: false,
      error: 'Validation failed',
      details: errors.array(),
    });
  }
  next();
};

/**
 * Get all tools
 * GET /api/tools
 */
router.get('/', optionalAuth, (req, res) => {
  const { category, search } = req.query;
  
  let result = tools;
  
  if (category && category !== 'all') {
    result = getToolsByCategory(category as string);
  }
  
  if (search) {
    result = searchTools(search as string);
  }
  
  res.json({
    success: true,
    tools: result,
    total: result.length,
  });
});

/**
 * Get tool by ID
 * GET /api/tools/:id
 */
router.get(
  '/:id',
  [param('id').notEmpty().withMessage('Tool ID required'), validate],
  (req, res, next) => {
    try {
      const tool = getToolById(req.params.id);
      
      if (!tool) {
        throw new NotFoundError('Tool not found');
      }
      
      res.json({
        success: true,
        tool,
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * Get tool categories
 * GET /api/tools/categories
 */
router.get('/categories', (req, res) => {
  const categories = [
    { id: 'all', name: 'All Tools', icon: 'LayoutGrid' },
    { id: 'pdf', name: 'PDF Tools', icon: 'FileText' },
    { id: 'image', name: 'Image Tools', icon: 'Image' },
    { id: 'social', name: 'Social Media', icon: 'Share2' },
    { id: 'business', name: 'Business Tools', icon: 'Briefcase' },
    { id: 'ai', name: 'AI Tools', icon: 'Sparkles' },
  ];
  
  res.json({
    success: true,
    categories,
  });
});

// Helper function to deduct credits
async function deductCredits(userId: string, amount: number): Promise<boolean> {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: { credits: true },
  });
  
  if (!user || user.credits < amount) {
    return false;
  }
  
  await prisma.user.update({
    where: { id: userId },
    data: { credits: { decrement: amount } },
  });
  
  return true;
}

// Helper function to save file from memory
async function saveFileFromMemory(file: Express.Multer.File): Promise<string> {
  const result = await FileService.saveLocalFile(
    file.buffer,
    file.originalname,
    file.mimetype
  );
  return `${FileService.getUploadDir()}/${result.name}`;
}

/**
 * PDF Merge
 * POST /api/tools/pdf-merge
 */
router.post(
  '/pdf-merge',
  authenticate,
  toolRateLimiter,
  uploadPdfMemory.array('files', 10),
  async (req, res, next) => {
    try {
      const files = req.files as Express.Multer.File[];
      
      if (!files || files.length < 2) {
        throw new BadRequestError('At least 2 PDF files required');
      }
      
      const tool = getToolById('pdf-merge')!;
      
      // Check credits
      if (!await deductCredits(req.user!.id, tool.creditCost)) {
        throw new UnauthorizedError('Insufficient credits');
      }
      
      // Save files temporarily
      const filePaths = await Promise.all(
        files.map(file => saveFileFromMemory(file))
      );
      
      // Process
      const result = await PdfService.merge({ files: filePaths });
      
      // Clean up temp files
      await Promise.all(filePaths.map(path => FileService.deleteLocalFile(path)));
      
      if (!result.success) {
        throw new BadRequestError(result.error || 'Merge failed');
      }
      
      res.json({
        success: true,
        result,
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * PDF Split
 * POST /api/tools/pdf-split
 */
router.post(
  '/pdf-split',
  authenticate,
  toolRateLimiter,
  uploadPdfMemory.single('file'),
  [
    body('pages').optional(),
    body('mode').isIn(['extract', 'split']).withMessage('Invalid mode'),
    validate,
  ],
  async (req, res, next) => {
    try {
      const file = req.file;
      const { pages, mode } = req.body;
      
      if (!file) {
        throw new BadRequestError('PDF file required');
      }
      
      const tool = getToolById('pdf-split')!;
      
      if (!await deductCredits(req.user!.id, tool.creditCost)) {
        throw new UnauthorizedError('Insufficient credits');
      }
      
      const filePath = await saveFileFromMemory(file);
      
      const pageNumbers = pages ? JSON.parse(pages).map((p: number) => parseInt(p)) : 'all';
      
      const result = await PdfService.split({
        file: filePath,
        pages: pageNumbers,
        mode,
      });
      
      await FileService.deleteLocalFile(filePath);
      
      if (!result.success) {
        throw new BadRequestError(result.error || 'Split failed');
      }
      
      res.json({
        success: true,
        result,
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * PDF Compress
 * POST /api/tools/pdf-compress
 */
router.post(
  '/pdf-compress',
  authenticate,
  toolRateLimiter,
  uploadPdfMemory.single('file'),
  [body('quality').isIn(['low', 'medium', 'high']).withMessage('Invalid quality'), validate],
  async (req, res, next) => {
    try {
      const file = req.file;
      const { quality } = req.body;
      
      if (!file) {
        throw new BadRequestError('PDF file required');
      }
      
      const tool = getToolById('pdf-compress')!;
      
      if (!await deductCredits(req.user!.id, tool.creditCost)) {
        throw new UnauthorizedError('Insufficient credits');
      }
      
      const filePath = await saveFileFromMemory(file);
      
      const result = await PdfService.compress({
        file: filePath,
        quality,
      });
      
      await FileService.deleteLocalFile(filePath);
      
      if (!result.success) {
        throw new BadRequestError(result.error || 'Compression failed');
      }
      
      res.json({
        success: true,
        result,
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * PDF Rotate
 * POST /api/tools/pdf-rotate
 */
router.post(
  '/pdf-rotate',
  authenticate,
  toolRateLimiter,
  uploadPdfMemory.single('file'),
  [
    body('angle').isIn([90, 180, 270]).withMessage('Invalid rotation angle'),
    validate,
  ],
  async (req, res, next) => {
    try {
      const file = req.file;
      const { angle, pages } = req.body;
      
      if (!file) {
        throw new BadRequestError('PDF file required');
      }
      
      const tool = getToolById('pdf-rotate')!;
      
      if (!await deductCredits(req.user!.id, tool.creditCost)) {
        throw new UnauthorizedError('Insufficient credits');
      }
      
      const filePath = await saveFileFromMemory(file);
      
      const pageNumbers = pages ? JSON.parse(pages).map((p: number) => parseInt(p)) : undefined;
      
      const result = await PdfService.rotate(filePath, angle, pageNumbers);
      
      await FileService.deleteLocalFile(filePath);
      
      if (!result.success) {
        throw new BadRequestError(result.error || 'Rotation failed');
      }
      
      res.json({
        success: true,
        result,
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * Image Compress
 * POST /api/tools/image-compress
 */
router.post(
  '/image-compress',
  authenticate,
  toolRateLimiter,
  uploadImageMemory.single('file'),
  [
    body('quality').isInt({ min: 1, max: 100 }).withMessage('Quality must be 1-100'),
    validate,
  ],
  async (req, res, next) => {
    try {
      const file = req.file;
      const { quality, format } = req.body;
      
      if (!file) {
        throw new BadRequestError('Image file required');
      }
      
      const tool = getToolById('image-compress')!;
      
      if (!await deductCredits(req.user!.id, tool.creditCost)) {
        throw new UnauthorizedError('Insufficient credits');
      }
      
      const filePath = await saveFileFromMemory(file);
      
      const result = await ImageService.compress({
        file: filePath,
        quality: parseInt(quality),
        format: format || undefined,
      });
      
      await FileService.deleteLocalFile(filePath);
      
      if (!result.success) {
        throw new BadRequestError(result.error || 'Compression failed');
      }
      
      res.json({
        success: true,
        result,
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * Image Convert
 * POST /api/tools/image-convert
 */
router.post(
  '/image-convert',
  authenticate,
  toolRateLimiter,
  uploadImageMemory.single('file'),
  [
    body('format').isIn(['jpeg', 'png', 'webp', 'gif', 'avif']).withMessage('Invalid format'),
    validate,
  ],
  async (req, res, next) => {
    try {
      const file = req.file;
      const { format } = req.body;
      
      if (!file) {
        throw new BadRequestError('Image file required');
      }
      
      const tool = getToolById('image-convert')!;
      
      if (!await deductCredits(req.user!.id, tool.creditCost)) {
        throw new UnauthorizedError('Insufficient credits');
      }
      
      const filePath = await saveFileFromMemory(file);
      
      const result = await ImageService.convert(filePath, format);
      
      await FileService.deleteLocalFile(filePath);
      
      if (!result.success) {
        throw new BadRequestError(result.error || 'Conversion failed');
      }
      
      res.json({
        success: true,
        result,
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * Image Resize
 * POST /api/tools/image-resize
 */
router.post(
  '/image-resize',
  authenticate,
  toolRateLimiter,
  uploadImageMemory.single('file'),
  [
    body('width').optional().isInt({ min: 1 }),
    body('height').optional().isInt({ min: 1 }),
    body('maintainAspectRatio').isBoolean(),
    validate,
  ],
  async (req, res, next) => {
    try {
      const file = req.file;
      const { width, height, maintainAspectRatio } = req.body;
      
      if (!file) {
        throw new BadRequestError('Image file required');
      }
      
      if (!width && !height) {
        throw new BadRequestError('Width or height required');
      }
      
      const tool = getToolById('image-resize')!;
      
      if (!await deductCredits(req.user!.id, tool.creditCost)) {
        throw new UnauthorizedError('Insufficient credits');
      }
      
      const filePath = await saveFileFromMemory(file);
      
      const result = await ImageService.resize({
        file: filePath,
        width: width ? parseInt(width) : undefined,
        height: height ? parseInt(height) : undefined,
        maintainAspectRatio: maintainAspectRatio === 'true' || maintainAspectRatio === true,
      });
      
      await FileService.deleteLocalFile(filePath);
      
      if (!result.success) {
        throw new BadRequestError(result.error || 'Resize failed');
      }
      
      res.json({
        success: true,
        result,
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * Image Crop
 * POST /api/tools/image-crop
 */
router.post(
  '/image-crop',
  authenticate,
  toolRateLimiter,
  uploadImageMemory.single('file'),
  [
    body('left').isInt({ min: 0 }),
    body('top').isInt({ min: 0 }),
    body('width').isInt({ min: 1 }),
    body('height').isInt({ min: 1 }),
    validate,
  ],
  async (req, res, next) => {
    try {
      const file = req.file;
      const { left, top, width, height } = req.body;
      
      if (!file) {
        throw new BadRequestError('Image file required');
      }
      
      const tool = getToolById('image-crop')!;
      
      if (!await deductCredits(req.user!.id, tool.creditCost)) {
        throw new UnauthorizedError('Insufficient credits');
      }
      
      const filePath = await saveFileFromMemory(file);
      
      const result = await ImageService.crop(
        filePath,
        parseInt(left),
        parseInt(top),
        parseInt(width),
        parseInt(height)
      );
      
      await FileService.deleteLocalFile(filePath);
      
      if (!result.success) {
        throw new BadRequestError(result.error || 'Crop failed');
      }
      
      res.json({
        success: true,
        result,
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * Image Watermark
 * POST /api/tools/image-watermark
 */
router.post(
  '/image-watermark',
  authenticate,
  toolRateLimiter,
  uploadImageMemory.single('file'),
  [
    body('text').optional(),
    body('position').isIn(['top-left', 'top-right', 'bottom-left', 'bottom-right', 'center']),
    body('opacity').isInt({ min: 1, max: 100 }),
    body('size').isInt({ min: 1, max: 100 }),
    validate,
  ],
  async (req, res, next) => {
    try {
      const file = req.file;
      const { text, position, opacity, size } = req.body;
      
      if (!file) {
        throw new BadRequestError('Image file required');
      }
      
      if (!text) {
        throw new BadRequestError('Watermark text required');
      }
      
      const tool = getToolById('image-watermark')!;
      
      if (!await deductCredits(req.user!.id, tool.creditCost)) {
        throw new UnauthorizedError('Insufficient credits');
      }
      
      const filePath = await saveFileFromMemory(file);
      
      const result = await ImageService.addWatermark({
        file: filePath,
        text,
        position,
        opacity: parseInt(opacity),
        size: parseInt(size),
      });
      
      await FileService.deleteLocalFile(filePath);
      
      if (!result.success) {
        throw new BadRequestError(result.error || 'Watermark failed');
      }
      
      res.json({
        success: true,
        result,
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * QR Code Generator
 * POST /api/tools/qr-generator
 */
router.post(
  '/qr-generator',
  authenticate,
  toolRateLimiter,
  [
    body('text').notEmpty().withMessage('Text required'),
    body('size').optional().isInt({ min: 50, max: 1000 }),
    body('color').optional().isHexColor(),
    body('bgColor').optional().isHexColor(),
    validate,
  ],
  async (req, res, next) => {
    try {
      const { text, size, color, bgColor } = req.body;
      
      const tool = getToolById('qr-generator')!;
      
      if (!await deductCredits(req.user!.id, tool.creditCost)) {
        throw new UnauthorizedError('Insufficient credits');
      }
      
      const result = await QrService.generate({
        text,
        size: size ? parseInt(size) : undefined,
        color,
        bgColor,
      });
      
      if (!result.success) {
        throw new BadRequestError(result.error || 'QR generation failed');
      }
      
      res.json({
        success: true,
        result,
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * QR Code WiFi
 * POST /api/tools/qr-wifi
 */
router.post(
  '/qr-wifi',
  authenticate,
  toolRateLimiter,
  [
    body('ssid').notEmpty(),
    body('password').notEmpty(),
    body('encryption').optional().isIn(['WPA', 'WEP', 'nopass']),
    validate,
  ],
  async (req, res, next) => {
    try {
      const { ssid, password, encryption, hidden } = req.body;
      
      const tool = getToolById('qr-generator')!;
      
      if (!await deductCredits(req.user!.id, tool.creditCost)) {
        throw new UnauthorizedError('Insufficient credits');
      }
      
      const result = await QrService.generateWiFi(
        ssid,
        password,
        encryption || 'WPA',
        hidden === 'true' || hidden === true
      );
      
      if (!result.success) {
        throw new BadRequestError(result.error || 'WiFi QR generation failed');
      }
      
      res.json({
        success: true,
        result,
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * AI Text Generator
 * POST /api/tools/ai-text
 */
router.post(
  '/ai-text',
  authenticate,
  toolRateLimiter,
  [
    body('prompt').notEmpty().withMessage('Prompt required'),
    body('maxTokens').optional().isInt({ min: 10, max: 4000 }),
    validate,
  ],
  async (req, res, next) => {
    try {
      const { prompt, maxTokens, temperature } = req.body;
      
      const tool = getToolById('ai-text')!;
      
      if (!await deductCredits(req.user!.id, tool.creditCost)) {
        throw new UnauthorizedError('Insufficient credits');
      }
      
      const result = await AiService.generateText(prompt, {
        maxTokens: maxTokens ? parseInt(maxTokens) : undefined,
        temperature: temperature ? parseFloat(temperature) : undefined,
      });
      
      if (!result.success) {
        throw new BadRequestError(result.error || 'Text generation failed');
      }
      
      res.json({
        success: true,
        result,
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * AI Image Generator
 * POST /api/tools/ai-image
 */
router.post(
  '/ai-image',
  authenticate,
  toolRateLimiter,
  [
    body('prompt').notEmpty().withMessage('Prompt required'),
    body('size').optional().isIn(['1024x1024', '1792x1024', '1024x1792']),
    validate,
  ],
  async (req, res, next) => {
    try {
      const { prompt, size, quality, style } = req.body;
      
      const tool = getToolById('ai-image')!;
      
      if (!await deductCredits(req.user!.id, tool.creditCost)) {
        throw new UnauthorizedError('Insufficient credits');
      }
      
      const result = await AiService.generateImage(prompt, {
        size: size || '1024x1024',
        quality: quality || 'standard',
        style: style || 'vivid',
      });
      
      if (!result.success) {
        throw new BadRequestError(result.error || 'Image generation failed');
      }
      
      res.json({
        success: true,
        result,
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * AI Caption Generator
 * POST /api/tools/caption-writer
 */
router.post(
  '/caption-writer',
  authenticate,
  toolRateLimiter,
  [
    body('topic').notEmpty(),
    body('platform').isIn(['instagram', 'twitter', 'facebook', 'linkedin']),
    body('tone').optional().isIn(['professional', 'casual', 'funny', 'inspirational']),
    validate,
  ],
  async (req, res, next) => {
    try {
      const { topic, platform, tone } = req.body;
      
      const tool = getToolById('caption-writer')!;
      
      if (!await deductCredits(req.user!.id, tool.creditCost)) {
        throw new UnauthorizedError('Insufficient credits');
      }
      
      const result = await AiService.generateCaption(
        topic,
        platform,
        tone || 'casual'
      );
      
      if (!result.success) {
        throw new BadRequestError(result.error || 'Caption generation failed');
      }
      
      res.json({
        success: true,
        result,
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * Hashtag Generator
 * POST /api/tools/hashtag-generator
 */
router.post(
  '/hashtag-generator',
  authenticate,
  toolRateLimiter,
  [
    body('topic').notEmpty(),
    body('count').optional().isInt({ min: 1, max: 30 }),
    validate,
  ],
  async (req, res, next) => {
    try {
      const { topic, count } = req.body;
      
      const tool = getToolById('hashtag-generator')!;
      
      if (!await deductCredits(req.user!.id, tool.creditCost)) {
        throw new UnauthorizedError('Insufficient credits');
      }
      
      const result = await AiService.generateHashtags(
        topic,
        count ? parseInt(count) : 10
      );
      
      if (!result.success) {
        throw new BadRequestError(result.error || 'Hashtag generation failed');
      }
      
      res.json({
        success: true,
        result,
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * Bio Generator
 * POST /api/tools/bio-generator
 */
router.post(
  '/bio-generator',
  authenticate,
  toolRateLimiter,
  [
    body('name').notEmpty(),
    body('profession').notEmpty(),
    body('interests').optional(),
    body('platform').isIn(['instagram', 'twitter', 'linkedin', 'general']),
    validate,
  ],
  async (req, res, next) => {
    try {
      const { name, profession, interests, platform } = req.body;
      
      const tool = getToolById('bio-generator')!;
      
      if (!await deductCredits(req.user!.id, tool.creditCost)) {
        throw new UnauthorizedError('Insufficient credits');
      }
      
      const result = await AiService.generateBio(
        name,
        profession,
        interests ? JSON.parse(interests) : [],
        platform
      );
      
      if (!result.success) {
        throw new BadRequestError(result.error || 'Bio generation failed');
      }
      
      res.json({
        success: true,
        result,
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * AI Code Generator
 * POST /api/tools/ai-code
 */
router.post(
  '/ai-code',
  authenticate,
  toolRateLimiter,
  [
    body('description').notEmpty(),
    body('language').notEmpty(),
    validate,
  ],
  async (req, res, next) => {
    try {
      const { description, language } = req.body;
      
      const tool = getToolById('ai-code')!;
      
      if (!await deductCredits(req.user!.id, tool.creditCost)) {
        throw new UnauthorizedError('Insufficient credits');
      }
      
      const result = await AiService.generateCode(description, language);
      
      if (!result.success) {
        throw new BadRequestError(result.error || 'Code generation failed');
      }
      
      res.json({
        success: true,
        result,
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * AI Translate
 * POST /api/tools/ai-translate
 */
router.post(
  '/ai-translate',
  authenticate,
  toolRateLimiter,
  [
    body('text').notEmpty(),
    body('targetLanguage').notEmpty(),
    body('sourceLanguage').optional(),
    validate,
  ],
  async (req, res, next) => {
    try {
      const { text, targetLanguage, sourceLanguage } = req.body;
      
      const tool = getToolById('ai-translate')!;
      
      if (!await deductCredits(req.user!.id, tool.creditCost)) {
        throw new UnauthorizedError('Insufficient credits');
      }
      
      const result = await AiService.translate(text, targetLanguage, sourceLanguage);
      
      if (!result.success) {
        throw new BadRequestError(result.error || 'Translation failed');
      }
      
      res.json({
        success: true,
        result,
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * AI Summarize
 * POST /api/tools/ai-summarize
 */
router.post(
  '/ai-summarize',
  authenticate,
  toolRateLimiter,
  [
    body('text').notEmpty(),
    body('maxLength').optional().isInt({ min: 10, max: 1000 }),
    validate,
  ],
  async (req, res, next) => {
    try {
      const { text, maxLength } = req.body;
      
      const tool = getToolById('ai-summarize')!;
      
      if (!await deductCredits(req.user!.id, tool.creditCost)) {
        throw new UnauthorizedError('Insufficient credits');
      }
      
      const result = await AiService.summarize(text, maxLength ? parseInt(maxLength) : 200);
      
      if (!result.success) {
        throw new BadRequestError(result.error || 'Summarization failed');
      }
      
      res.json({
        success: true,
        result,
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * Password Generator
 * POST /api/tools/password-generator
 */
router.post(
  '/password-generator',
  authenticate,
  [
    body('length').optional().isInt({ min: 4, max: 128 }),
    body('includeUppercase').optional().isBoolean(),
    body('includeNumbers').optional().isBoolean(),
    body('includeSymbols').optional().isBoolean(),
    validate,
  ],
  async (req, res, next) => {
    try {
      const {
        length = 16,
        includeUppercase = true,
        includeNumbers = true,
        includeSymbols = true,
      } = req.body;
      
      const tool = getToolById('password-generator')!;
      
      if (!await deductCredits(req.user!.id, tool.creditCost)) {
        throw new UnauthorizedError('Insufficient credits');
      }
      
      // Generate password
      const lowercase = 'abcdefghijklmnopqrstuvwxyz';
      const uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
      const numbers = '0123456789';
      const symbols = '!@#$%^&*()_+-=[]{}|;:,.<>?';
      
      let chars = lowercase;
      if (includeUppercase) chars += uppercase;
      if (includeNumbers) chars += numbers;
      if (includeSymbols) chars += symbols;
      
      let password = '';
      for (let i = 0; i < length; i++) {
        password += chars.charAt(Math.floor(Math.random() * chars.length));
      }
      
      res.json({
        success: true,
        result: { password },
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * EMI Calculator
 * POST /api/tools/emi-calculator
 */
router.post(
  '/emi-calculator',
  authenticate,
  [
    body('principal').isFloat({ min: 0 }),
    body('rate').isFloat({ min: 0 }),
    body('tenure').isInt({ min: 1 }),
    validate,
  ],
  async (req, res, next) => {
    try {
      const { principal, rate, tenure } = req.body;
      
      const tool = getToolById('emi-calculator')!;
      
      if (!await deductCredits(req.user!.id, tool.creditCost)) {
        throw new UnauthorizedError('Insufficient credits');
      }
      
      const p = parseFloat(principal);
      const r = parseFloat(rate) / 100 / 12; // Monthly interest rate
      const n = parseInt(tenure) * 12; // Total months
      
      // EMI Formula: P * r * (1 + r)^n / ((1 + r)^n - 1)
      const emi = p * r * Math.pow(1 + r, n) / (Math.pow(1 + r, n) - 1);
      const totalPayment = emi * n;
      const totalInterest = totalPayment - p;
      
      res.json({
        success: true,
        result: {
          emi: Math.round(emi * 100) / 100,
          totalPayment: Math.round(totalPayment * 100) / 100,
          totalInterest: Math.round(totalInterest * 100) / 100,
          principal: p,
        },
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * Unit Converter
 * POST /api/tools/unit-converter
 */
router.post(
  '/unit-converter',
  authenticate,
  [
    body('value').isFloat(),
    body('from').notEmpty(),
    body('to').notEmpty(),
    body('category').isIn(['length', 'weight', 'temperature', 'volume', 'area']),
    validate,
  ],
  async (req, res, next) => {
    try {
      const { value, from, to, category } = req.body;
      
      const tool = getToolById('unit-converter')!;
      
      if (!await deductCredits(req.user!.id, tool.creditCost)) {
        throw new UnauthorizedError('Insufficient credits');
      }
      
      const val = parseFloat(value);
      let result = 0;
      
      // Conversion factors
      const conversions: Record<string, Record<string, number>> = {
        length: {
          meter: 1,
          kilometer: 1000,
          centimeter: 0.01,
          millimeter: 0.001,
          inch: 0.0254,
          foot: 0.3048,
          yard: 0.9144,
          mile: 1609.34,
        },
        weight: {
          kilogram: 1,
          gram: 0.001,
          milligram: 0.000001,
          pound: 0.453592,
          ounce: 0.0283495,
          ton: 1000,
        },
        volume: {
          liter: 1,
          milliliter: 0.001,
          gallon: 3.78541,
          quart: 0.946353,
          pint: 0.473176,
          cup: 0.236588,
          fluid_ounce: 0.0295735,
        },
        area: {
          square_meter: 1,
          square_kilometer: 1000000,
          square_foot: 0.092903,
          square_yard: 0.836127,
          acre: 4046.86,
          hectare: 10000,
        },
      };
      
      if (category === 'temperature') {
        // Temperature conversions
        if (from === 'celsius' && to === 'fahrenheit') {
          result = (val * 9 / 5) + 32;
        } else if (from === 'fahrenheit' && to === 'celsius') {
          result = (val - 32) * 5 / 9;
        } else if (from === 'celsius' && to === 'kelvin') {
          result = val + 273.15;
        } else if (from === 'kelvin' && to === 'celsius') {
          result = val - 273.15;
        } else {
          result = val;
        }
      } else {
        const conv = conversions[category];
        if (conv && conv[from] && conv[to]) {
          result = val * conv[from] / conv[to];
        } else {
          throw new BadRequestError('Invalid units');
        }
      }
      
      res.json({
        success: true,
        result: {
          value: result,
          from,
          to,
          category,
        },
      });
    } catch (error) {
      next(error);
    }
  }
);

export default router;
