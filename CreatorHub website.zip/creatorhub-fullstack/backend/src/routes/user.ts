import { Router } from 'express';
import { body, validationResult } from 'express-validator';
import { authenticate } from '../middleware/auth';
import { prisma } from '../config/database';
import { BadRequestError, NotFoundError } from '../utils/errors';
import { formatBytes } from '../utils/helpers';

const router = Router();

// Validation middleware
const validate = (req: any, res: any, next: any) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({
      success: false,
      error: 'Validation failed',
      details: errors.array(),
    });
  }
  next();
};

/**
 * Get user dashboard data
 * GET /api/user/dashboard
 */
router.get('/dashboard', authenticate, async (req, res, next) => {
  try {
    const userId = req.user!.id;
    
    // Get user stats
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: {
        id: true,
        email: true,
        name: true,
        plan: true,
        credits: true,
        image: true,
        createdAt: true,
        _count: {
          select: {
            files: true,
            payments: true,
          },
        },
      },
    });
    
    if (!user) {
      throw new NotFoundError('User not found');
    }
    
    // Get recent files
    const recentFiles = await prisma.file.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      take: 10,
      select: {
        id: true,
        name: true,
        originalName: true,
        mimeType: true,
        size: true,
        status: true,
        toolId: true,
        createdAt: true,
      },
    });
    
    // Get recent payments
    const recentPayments = await prisma.payment.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      take: 5,
      select: {
        id: true,
        amount: true,
        currency: true,
        status: true,
        plan: true,
        createdAt: true,
      },
    });
    
    // Calculate usage stats
    const totalFiles = user._count.files;
    const totalPayments = user._count.payments;
    
    // Get files by status
    const filesByStatus = await prisma.file.groupBy({
      by: ['status'],
      where: { userId },
      _count: {
        status: true,
      },
    });
    
    res.json({
      success: true,
      dashboard: {
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          plan: user.plan,
          credits: user.credits,
          image: user.image,
          memberSince: user.createdAt,
        },
        stats: {
          totalFiles,
          totalPayments,
          filesByStatus: filesByStatus.reduce((acc, curr) => {
            acc[curr.status] = curr._count.status;
            return acc;
          }, {} as Record<string, number>),
        },
        recentFiles: recentFiles.map(file => ({
          ...file,
          sizeFormatted: formatBytes(file.size),
        })),
        recentPayments: recentPayments.map(payment => ({
          ...payment,
          amountFormatted: `$${(payment.amount / 100).toFixed(2)}`,
        })),
      },
    });
  } catch (error) {
    next(error);
  }
});

/**
 * Get user files
 * GET /api/user/files
 */
router.get('/files', authenticate, async (req, res, next) => {
  try {
    const userId = req.user!.id;
    const { page = '1', limit = '20', status } = req.query;
    
    const pageNum = parseInt(page as string);
    const limitNum = parseInt(limit as string);
    const skip = (pageNum - 1) * limitNum;
    
    const where: any = { userId };
    if (status) {
      where.status = status;
    }
    
    const [files, total] = await Promise.all([
      prisma.file.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip,
        take: limitNum,
        select: {
          id: true,
          name: true,
          originalName: true,
          mimeType: true,
          size: true,
          url: true,
          toolId: true,
          status: true,
          createdAt: true,
        },
      }),
      prisma.file.count({ where }),
    ]);
    
    res.json({
      success: true,
      files: files.map(file => ({
        ...file,
        sizeFormatted: formatBytes(file.size),
      })),
      pagination: {
        page: pageNum,
        limit: limitNum,
        total,
        totalPages: Math.ceil(total / limitNum),
      },
    });
  } catch (error) {
    next(error);
  }
});

/**
 * Get user payments
 * GET /api/user/payments
 */
router.get('/payments', authenticate, async (req, res, next) => {
  try {
    const userId = req.user!.id;
    const { page = '1', limit = '20' } = req.query;
    
    const pageNum = parseInt(page as string);
    const limitNum = parseInt(limit as string);
    const skip = (pageNum - 1) * limitNum;
    
    const [payments, total] = await Promise.all([
      prisma.payment.findMany({
        where: { userId },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limitNum,
        select: {
          id: true,
          amount: true,
          currency: true,
          status: true,
          plan: true,
          createdAt: true,
        },
      }),
      prisma.payment.count({ where: { userId } }),
    ]);
    
    res.json({
      success: true,
      payments: payments.map(payment => ({
        ...payment,
        amountFormatted: `$${(payment.amount / 100).toFixed(2)}`,
      })),
      pagination: {
        page: pageNum,
        limit: limitNum,
        total,
        totalPages: Math.ceil(total / limitNum),
      },
    });
  } catch (error) {
    next(error);
  }
});

/**
 * Update user profile
 * PATCH /api/user/profile
 */
router.patch(
  '/profile',
  authenticate,
  [
    body('name').optional().trim().isLength({ min: 2 }),
    body('image').optional().isURL(),
    validate,
  ],
  async (req, res, next) => {
    try {
      const userId = req.user!.id;
      const { name, image } = req.body;
      
      const updateData: any = {};
      if (name !== undefined) updateData.name = name;
      if (image !== undefined) updateData.image = image;
      
      const user = await prisma.user.update({
        where: { id: userId },
        data: updateData,
        select: {
          id: true,
          email: true,
          name: true,
          plan: true,
          credits: true,
          image: true,
        },
      });
      
      res.json({
        success: true,
        message: 'Profile updated successfully',
        user,
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * Get user stats
 * GET /api/user/stats
 */
router.get('/stats', authenticate, async (req, res, next) => {
  try {
    const userId = req.user!.id;
    
    // Get file stats
    const fileStats = await prisma.file.groupBy({
      by: ['toolId'],
      where: { userId },
      _count: {
        toolId: true,
      },
    });
    
    // Get monthly usage
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    const monthlyUsage = await prisma.file.groupBy({
      by: ['status'],
      where: {
        userId,
        createdAt: {
          gte: thirtyDaysAgo,
        },
      },
      _count: {
        status: true,
      },
    });
    
    // Get total storage used
    const files = await prisma.file.findMany({
      where: { userId },
      select: { size: true },
    });
    
    const totalStorage = files.reduce((sum, file) => sum + file.size, 0);
    
    res.json({
      success: true,
      stats: {
        fileStats: fileStats.map(stat => ({
          toolId: stat.toolId,
          count: stat._count.toolId,
        })),
        monthlyUsage: monthlyUsage.reduce((acc, curr) => {
          acc[curr.status] = curr._count.status;
          return acc;
        }, {} as Record<string, number>),
        totalStorage,
        totalStorageFormatted: formatBytes(totalStorage),
      },
    });
  } catch (error) {
    next(error);
  }
});

/**
 * Delete file
 * DELETE /api/user/files/:id
 */
router.delete('/files/:id', authenticate, async (req, res, next) => {
  try {
    const userId = req.user!.id;
    const fileId = req.params.id;
    
    // Check file ownership
    const file = await prisma.file.findFirst({
      where: { id: fileId, userId },
    });
    
    if (!file) {
      throw new NotFoundError('File not found');
    }
    
    // Delete from database
    await prisma.file.delete({
      where: { id: fileId },
    });
    
    // Delete file from storage (optional)
    // await FileService.deleteLocalFile(file.url);
    
    res.json({
      success: true,
      message: 'File deleted successfully',
    });
  } catch (error) {
    next(error);
  }
});

/**
 * Get user activity
 * GET /api/user/activity
 */
router.get('/activity', authenticate, async (req, res, next) => {
  try {
    const userId = req.user!.id;
    
    // Get activity for last 30 days
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    const files = await prisma.file.findMany({
      where: {
        userId,
        createdAt: {
          gte: thirtyDaysAgo,
        },
      },
      select: {
        createdAt: true,
      },
    });
    
    // Group by date
    const activityMap = new Map<string, { date: string; filesProcessed: number; creditsUsed: number }>();
    
    files.forEach(file => {
      const date = file.createdAt.toISOString().split('T')[0];
      if (activityMap.has(date)) {
        const entry = activityMap.get(date)!;
        entry.filesProcessed++;
        entry.creditsUsed += 1; // Assume 1 credit per file
      } else {
        activityMap.set(date, {
          date,
          filesProcessed: 1,
          creditsUsed: 1,
        });
      }
    });
    
    const activity = Array.from(activityMap.values())
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
      .slice(0, 10);
    
    res.json({
      success: true,
      activity,
    });
  } catch (error) {
    next(error);
  }
});

export default router;
