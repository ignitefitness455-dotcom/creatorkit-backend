import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { body, validationResult } from 'express-validator';
import { prisma } from '../config/database';
import { generateTokens, verifyRefreshToken } from '../middleware/auth';
import { BadRequestError, UnauthorizedError } from '../utils/errors';
import { isValidEmail } from '../utils/helpers';

const router = Router();

// Validation middleware
const validate = (req: any, res: any, next: any) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({
      success: false,
      error: 'Validation failed',
      details: errors.array(),
    });
  }
  next();
};

/**
 * Register new user
 * POST /api/auth/register
 */
router.post(
  '/register',
  [
    body('email').isEmail().normalizeEmail().withMessage('Valid email required'),
    body('password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters'),
    body('name').optional().trim().isLength({ min: 2 }).withMessage('Name must be at least 2 characters'),
    validate,
  ],
  async (req, res, next) => {
    try {
      const { email, password, name } = req.body;
      
      // Check if user exists
      const existingUser = await prisma.user.findUnique({
        where: { email },
      });
      
      if (existingUser) {
        throw new BadRequestError('Email already registered');
      }
      
      // Hash password
      const hashedPassword = await bcrypt.hash(password, 10);
      
      // Create user
      const user = await prisma.user.create({
        data: {
          email,
          password: hashedPassword,
          name: name || email.split('@')[0],
          emailVerified: true, // Skip email verification for now
        },
        select: {
          id: true,
          email: true,
          name: true,
          plan: true,
          credits: true,
          createdAt: true,
        },
      });
      
      // Generate tokens
      const tokens = generateTokens({
        userId: user.id,
        email: user.email,
        plan: user.plan,
      });
      
      res.status(201).json({
        success: true,
        message: 'Registration successful',
        user,
        ...tokens,
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * Login user
 * POST /api/auth/login
 */
router.post(
  '/login',
  [
    body('email').isEmail().normalizeEmail().withMessage('Valid email required'),
    body('password').notEmpty().withMessage('Password required'),
    validate,
  ],
  async (req, res, next) => {
    try {
      const { email, password } = req.body;
      
      // Find user
      const user = await prisma.user.findUnique({
        where: { email },
      });
      
      if (!user || !user.password) {
        throw new UnauthorizedError('Invalid credentials');
      }
      
      // Verify password
      const isValid = await bcrypt.compare(password, user.password);
      
      if (!isValid) {
        throw new UnauthorizedError('Invalid credentials');
      }
      
      // Generate tokens
      const tokens = generateTokens({
        userId: user.id,
        email: user.email,
        plan: user.plan,
      });
      
      res.json({
        success: true,
        message: 'Login successful',
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          plan: user.plan,
          credits: user.credits,
          image: user.image,
        },
        ...tokens,
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * Refresh token
 * POST /api/auth/refresh
 */
router.post('/refresh', async (req, res, next) => {
  try {
    const { refreshToken: token } = req.body;
    
    if (!token) {
      throw new UnauthorizedError('Refresh token required');
    }
    
    // Verify refresh token
    const decoded = verifyRefreshToken(token);
    
    // Get user
    const user = await prisma.user.findUnique({
      where: { id: decoded.userId },
      select: {
        id: true,
        email: true,
        plan: true,
      },
    });
    
    if (!user) {
      throw new UnauthorizedError('User not found');
    }
    
    // Generate new tokens
    const tokens = generateTokens({
      userId: user.id,
      email: user.email,
      plan: user.plan,
    });
    
    res.json({
      success: true,
      ...tokens,
    });
  } catch (error) {
    next(error);
  }
});

/**
 * Get current user
 * GET /api/auth/me
 */
router.get('/me', authenticate, async (req, res, next) => {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.user!.id },
      select: {
        id: true,
        email: true,
        name: true,
        plan: true,
        credits: true,
        image: true,
        createdAt: true,
      },
    });
    
    if (!user) {
      throw new UnauthorizedError('User not found');
    }
    
    res.json({
      success: true,
      user,
    });
  } catch (error) {
    next(error);
  }
});

/**
 * Update user profile
 * PATCH /api/auth/profile
 */
router.patch('/profile', authenticate, async (req, res, next) => {
  try {
    const { name, image } = req.body;
    
    const user = await prisma.user.update({
      where: { id: req.user!.id },
      data: {
        ...(name && { name }),
        ...(image && { image }),
      },
      select: {
        id: true,
        email: true,
        name: true,
        plan: true,
        credits: true,
        image: true,
      },
    });
    
    res.json({
      success: true,
      message: 'Profile updated',
      user,
    });
  } catch (error) {
    next(error);
  }
});

/**
 * Change password
 * POST /api/auth/change-password
 */
router.post(
  '/change-password',
  authenticate,
  [
    body('currentPassword').notEmpty().withMessage('Current password required'),
    body('newPassword').isLength({ min: 6 }).withMessage('New password must be at least 6 characters'),
    validate,
  ],
  async (req, res, next) => {
    try {
      const { currentPassword, newPassword } = req.body;
      
      // Get user with password
      const user = await prisma.user.findUnique({
        where: { id: req.user!.id },
      });
      
      if (!user || !user.password) {
        throw new UnauthorizedError('User not found');
      }
      
      // Verify current password
      const isValid = await bcrypt.compare(currentPassword, user.password);
      
      if (!isValid) {
        throw new UnauthorizedError('Current password is incorrect');
      }
      
      // Hash new password
      const hashedPassword = await bcrypt.hash(newPassword, 10);
      
      // Update password
      await prisma.user.update({
        where: { id: req.user!.id },
        data: { password: hashedPassword },
      });
      
      res.json({
        success: true,
        message: 'Password changed successfully',
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * Logout
 * POST /api/auth/logout
 */
router.post('/logout', async (req, res) => {
  // Client-side should clear tokens
  res.json({
    success: true,
    message: 'Logged out successfully',
  });
});

export default router;
