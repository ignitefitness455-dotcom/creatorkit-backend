import { Router } from 'express';
import { body, validationResult } from 'express-validator';
import { authenticate } from '../middleware/auth';
import { PaymentService } from '../services/paymentService';
import { BadRequestError } from '../utils/errors';

const router = Router();

// Validation middleware
const validate = (req: any, res: any, next: any) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({
      success: false,
      error: 'Validation failed',
      details: errors.array(),
    });
  }
  next();
};

/**
 * Get payment configuration
 * GET /api/payments/config
 */
router.get('/config', (req, res) => {
  res.json({
    success: true,
    config: {
      stripeEnabled: PaymentService.isConfigured(),
      prices: {
        pro: 999, // $9.99 in cents
        business: 2999, // $29.99 in cents
      },
    },
  });
});

/**
 * Create checkout session
 * POST /api/payments/checkout
 */
router.post(
  '/checkout',
  authenticate,
  [
    body('plan').isIn(['PRO', 'BUSINESS']).withMessage('Invalid plan'),
    body('successUrl').isURL().withMessage('Valid success URL required'),
    body('cancelUrl').isURL().withMessage('Valid cancel URL required'),
    validate,
  ],
  async (req, res, next) => {
    try {
      const { plan, successUrl, cancelUrl } = req.body;
      const userId = req.user!.id;
      
      const result = await PaymentService.createCheckoutSession(
        userId,
        plan,
        successUrl,
        cancelUrl
      );
      
      if (!result.success) {
        throw new BadRequestError(result.error || 'Failed to create checkout session');
      }
      
      res.json({
        success: true,
        sessionId: result.sessionId,
        url: result.url,
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * Create customer portal session
 * POST /api/payments/portal
 */
router.post(
  '/portal',
  authenticate,
  [
    body('returnUrl').isURL().withMessage('Valid return URL required'),
    validate,
  ],
  async (req, res, next) => {
    try {
      const { returnUrl } = req.body;
      
      // Get or create customer
      const customerResult = await PaymentService.getOrCreateCustomer(req.user!.email);
      
      if (!customerResult.success || !customerResult.customerId) {
        throw new BadRequestError(customerResult.error || 'Failed to get customer');
      }
      
      const result = await PaymentService.createPortalSession(
        customerResult.customerId,
        returnUrl
      );
      
      if (!result.success) {
        throw new BadRequestError(result.error || 'Failed to create portal session');
      }
      
      res.json({
        success: true,
        url: result.url,
      });
    } catch (error) {
      next(error);
    }
  }
);

/**
 * Get subscription details
 * GET /api/payments/subscription/:id
 */
router.get('/subscription/:id', authenticate, async (req, res, next) => {
  try {
    const { id } = req.params;
    
    const result = await PaymentService.getSubscription(id);
    
    if (!result.success) {
      throw new BadRequestError(result.error || 'Failed to get subscription');
    }
    
    res.json({
      success: true,
      subscription: result.subscription,
    });
  } catch (error) {
    next(error);
  }
});

/**
 * Cancel subscription
 * POST /api/payments/subscription/:id/cancel
 */
router.post('/subscription/:id/cancel', authenticate, async (req, res, next) => {
  try {
    const { id } = req.params;
    
    const result = await PaymentService.cancelSubscription(id);
    
    if (!result.success) {
      throw new BadRequestError(result.error || 'Failed to cancel subscription');
    }
    
    res.json({
      success: true,
      message: 'Subscription cancelled successfully',
      subscription: result.subscription,
    });
  } catch (error) {
    next(error);
  }
});

export default router;
