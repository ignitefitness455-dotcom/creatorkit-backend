import { z } from 'zod';

const envSchema = z.object({
  // Required - but with defaults for Railway
  DATABASE_URL: z.string().min(1),
  JWT_SECRET: z.string().min(1).default('your-super-secret-jwt-key-for-development-only-change-in-production'),
  JWT_REFRESH_SECRET: z.string().min(1).default('your-super-secret-refresh-key-for-development-only-change-in-production'),
  
  // Optional with defaults
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  PORT: z.string().transform((val) => parseInt(val, 10)).default('5000'),
  FRONTEND_URL: z.string().default('http://localhost:5173'),
  UPLOAD_DIR: z.string().default('./uploads'),
  OUTPUT_DIR: z.string().default('./outputs'),
  
  // Optional - OAuth
  GOOGLE_CLIENT_ID: z.string().optional(),
  GOOGLE_CLIENT_SECRET: z.string().optional(),
  GITHUB_CLIENT_ID: z.string().optional(),
  GITHUB_CLIENT_SECRET: z.string().optional(),
  
  // Optional - AWS S3
  AWS_ACCESS_KEY_ID: z.string().optional(),
  AWS_SECRET_ACCESS_KEY: z.string().optional(),
  AWS_REGION: z.string().default('us-east-1'),
  AWS_S3_BUCKET: z.string().optional(),
  
  // Optional - Redis
  REDIS_URL: z.string().optional(),
  
  // Optional - Email
  SMTP_HOST: z.string().optional(),
  SMTP_PORT: z.string().transform((val) => parseInt(val, 10)).default('587'),
  SMTP_USER: z.string().optional(),
  SMTP_PASS: z.string().optional(),
  
  // Optional - Stripe
  STRIPE_SECRET_KEY: z.string().optional(),
  STRIPE_WEBHOOK_SECRET: z.string().optional(),
  STRIPE_PRICE_PRO: z.string().optional(),
  STRIPE_PRICE_BUSINESS: z.string().optional(),
  
  // Optional - OpenAI
  OPENAI_API_KEY: z.string().optional(),
  
  // Optional - SSLCommerz (Bangladesh Payment Gateway)
  SSLCOMMERZ_STORE_ID: z.string().optional(),
  SSLCOMMERZ_STORE_PASSWD: z.string().optional(),
  SSLCOMMERZ_IS_SANDBOX: z.string().default('true'),
});

const parsedEnv = envSchema.safeParse(process.env);

if (!parsedEnv.success) {
  console.error('❌ Invalid environment variables:');
  parsedEnv.error.issues.forEach((issue) => {
    console.error(`  - ${issue.path.join('.')}: ${issue.message}`);
  });
  
  // Don't exit in production - Railway might have different env setup
  if (process.env.NODE_ENV === 'production') {
    console.warn('⚠️  Running in production with invalid env vars. Using defaults where possible.');
  } else {
    process.exit(1);
  }
}

export const env = parsedEnv.success ? parsedEnv.data : ({} as any);
