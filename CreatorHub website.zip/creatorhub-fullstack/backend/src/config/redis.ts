import Redis from 'ioredis';
import { env } from './env';

let redis: Redis | null = null;

export function getRedis(): Redis | null {
  if (redis) return redis;
  
  if (!env.REDIS_URL) {
    console.log('⚠️  Redis not configured, using in-memory fallback');
    return null;
  }
  
  try {
    redis = new Redis(env.REDIS_URL, {
      maxRetriesPerRequest: 3,
      enableReadyCheck: false,
    });
    
    redis.on('error', (err) => {
      console.error('Redis error:', err.message);
      redis = null;
    });
    
    redis.on('connect', () => {
      console.log('✅ Redis connected');
    });
    
    return redis;
  } catch (error) {
    console.error('❌ Redis connection failed:', error);
    return null;
  }
}

// In-memory fallback for when Redis is not available
const memoryCache = new Map<string, { value: string; expiry: number }>();

export const cache = {
  async get(key: string): Promise<string | null> {
    const client = getRedis();
    if (client) {
      return client.get(key);
    }
    
    const item = memoryCache.get(key);
    if (!item) return null;
    if (Date.now() > item.expiry) {
      memoryCache.delete(key);
      return null;
    }
    return item.value;
  },
  
  async set(key: string, value: string, ttlSeconds?: number): Promise<void> {
    const client = getRedis();
    if (client) {
      if (ttlSeconds) {
        await client.setex(key, ttlSeconds, value);
      } else {
        await client.set(key, value);
      }
      return;
    }
    
    memoryCache.set(key, {
      value,
      expiry: ttlSeconds ? Date.now() + ttlSeconds * 1000 : Infinity,
    });
  },
  
  async del(key: string): Promise<void> {
    const client = getRedis();
    if (client) {
      await client.del(key);
      return;
    }
    memoryCache.delete(key);
  },
  
  async flush(): Promise<void> {
    const client = getRedis();
    if (client) {
      await client.flushall();
      return;
    }
    memoryCache.clear();
  },
};
