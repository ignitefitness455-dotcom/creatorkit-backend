import OpenAI from 'openai';
import fs from 'fs/promises';
import path from 'path';
import { env } from '../config/env';
import { generateId } from '../utils/helpers';
import type { ProcessResult } from '../types';

const OUTPUT_DIR = process.env.OUTPUT_DIR 
  ? path.resolve(process.env.OUTPUT_DIR) 
  : path.join(process.cwd(), 'outputs');

// Initialize OpenAI client only if API key is available
const openai = env.OPENAI_API_KEY 
  ? new OpenAI({ apiKey: env.OPENAI_API_KEY })
  : null;

export class AiService {
  /**
   * Check if OpenAI is configured
   */
  static isConfigured(): boolean {
    return !!openai;
  }
  
  /**
   * Generate text using GPT
   */
  static async generateText(
    prompt: string,
    options: {
      model?: string;
      maxTokens?: number;
      temperature?: number;
      systemPrompt?: string;
    } = {}
  ): Promise<{
    success: boolean;
    text?: string;
    tokens?: number;
    error?: string;
  }> {
    try {
      if (!openai) {
        return { success: false, error: 'OpenAI API key not configured' };
      }
      
      const {
        model = 'gpt-3.5-turbo',
        maxTokens = 1000,
        temperature = 0.7,
        systemPrompt = 'You are a helpful assistant.',
      } = options;
      
      const response = await openai.chat.completions.create({
        model,
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: prompt },
        ],
        max_tokens: maxTokens,
        temperature,
      });
      
      return {
        success: true,
        text: response.choices[0]?.message?.content || '',
        tokens: response.usage?.total_tokens,
      };
    } catch (error: any) {
      console.error('Text generation error:', error);
      return { success: false, error: error.message || 'Failed to generate text' };
    }
  }
  
  /**
   * Generate image using DALL-E
   */
  static async generateImage(
    prompt: string,
    options: {
      size?: '1024x1024' | '1792x1024' | '1024x1792';
      quality?: 'standard' | 'hd';
      style?: 'vivid' | 'natural';
    } = {}
  ): Promise<ProcessResult> {
    try {
      if (!openai) {
        return { success: false, error: 'OpenAI API key not configured' };
      }
      
      const {
        size = '1024x1024',
        quality = 'standard',
        style = 'vivid',
      } = options;
      
      const response = await openai.images.generate({
        model: 'dall-e-3',
        prompt,
        size,
        quality,
        style,
        n: 1,
      });
      
      const imageUrl = response.data[0]?.url;
      
      if (!imageUrl) {
        return { success: false, error: 'No image generated' };
      }
      
      // Download the image
      const imageResponse = await fetch(imageUrl);
      const imageBuffer = Buffer.from(await imageResponse.arrayBuffer());
      
      // Save to file
      const outputId = generateId();
      const outputPath = path.join(OUTPUT_DIR, `${outputId}.png`);
      await fs.mkdir(OUTPUT_DIR, { recursive: true });
      await fs.writeFile(outputPath, imageBuffer);
      
      const stats = await fs.stat(outputPath);
      
      return {
        success: true,
        fileUrl: `/outputs/${outputId}.png`,
        fileName: `generated_${outputId}.png`,
        mimeType: 'image/png',
        size: stats.size,
      };
    } catch (error: any) {
      console.error('Image generation error:', error);
      return { success: false, error: error.message || 'Failed to generate image' };
    }
  }
  
  /**
   * Generate code
   */
  static async generateCode(
    description: string,
    language: string,
    options: {
      maxTokens?: number;
    } = {}
  ): Promise<{
    success: boolean;
    code?: string;
    explanation?: string;
    error?: string;
  }> {
    try {
      if (!openai) {
        return { success: false, error: 'OpenAI API key not configured' };
      }
      
      const { maxTokens = 2000 } = options;
      
      const systemPrompt = `You are an expert programmer. Generate clean, well-documented ${language} code based on the user's description. Provide the code first, then a brief explanation of how it works.`;
      
      const response = await openai.chat.completions.create({
        model: 'gpt-4',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: `Generate ${language} code for: ${description}` },
        ],
        max_tokens: maxTokens,
        temperature: 0.3,
      });
      
      const content = response.choices[0]?.message?.content || '';
      
      // Try to separate code and explanation
      const codeMatch = content.match(/```[\w]*\n?([\s\S]*?)```/);
      const code = codeMatch ? codeMatch[1].trim() : content;
      const explanation = content.replace(/```[\w]*\n?[\s\S]*?```/, '').trim();
      
      return {
        success: true,
        code,
        explanation,
      };
    } catch (error: any) {
      console.error('Code generation error:', error);
      return { success: false, error: error.message || 'Failed to generate code' };
    }
  }
  
  /**
   * Generate social media caption
   */
  static async generateCaption(
    topic: string,
    platform: 'instagram' | 'twitter' | 'facebook' | 'linkedin',
    tone: 'professional' | 'casual' | 'funny' | 'inspirational' = 'casual'
  ): Promise<{
    success: boolean;
    caption?: string;
    hashtags?: string[];
    error?: string;
  }> {
    try {
      if (!openai) {
        return { success: false, error: 'OpenAI API key not configured' };
      }
      
      const platformGuidelines: Record<string, string> = {
        instagram: 'Instagram: Use emojis, engaging tone, up to 2200 characters, include relevant hashtags',
        twitter: 'Twitter/X: Concise, under 280 characters, punchy and engaging',
        facebook: 'Facebook: Conversational, can be longer, encourage engagement',
        linkedin: 'LinkedIn: Professional, industry insights, thought leadership',
      };
      
      const systemPrompt = `You are a social media expert. Generate an engaging ${platform} caption about the given topic with a ${tone} tone. ${platformGuidelines[platform]} Return the caption and 5-10 relevant hashtags separately.`;
      
      const response = await openai.chat.completions.create({
        model: 'gpt-3.5-turbo',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: `Generate a ${tone} caption for ${platform} about: ${topic}` },
        ],
        max_tokens: 500,
        temperature: 0.8,
      });
      
      const content = response.choices[0]?.message?.content || '';
      
      // Extract hashtags
      const hashtagRegex = /#[\w]+/g;
      const hashtags = content.match(hashtagRegex) || [];
      const caption = content.replace(hashtagRegex, '').trim();
      
      return {
        success: true,
        caption,
        hashtags,
      };
    } catch (error: any) {
      console.error('Caption generation error:', error);
      return { success: false, error: error.message || 'Failed to generate caption' };
    }
  }
  
  /**
   * Generate hashtags
   */
  static async generateHashtags(
    topic: string,
    count: number = 10
  ): Promise<{
    success: boolean;
    hashtags?: string[];
    error?: string;
  }> {
    try {
      if (!openai) {
        return { success: false, error: 'OpenAI API key not configured' };
      }
      
      const systemPrompt = `You are a social media marketing expert. Generate ${count} trending, relevant hashtags for the given topic. Return only the hashtags as a comma-separated list, no other text.`;
      
      const response = await openai.chat.completions.create({
        model: 'gpt-3.5-turbo',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: `Generate hashtags for: ${topic}` },
        ],
        max_tokens: 200,
        temperature: 0.7,
      });
      
      const content = response.choices[0]?.message?.content || '';
      const hashtags = content.split(/[,\s]+/).filter(h => h.startsWith('#'));
      
      return {
        success: true,
        hashtags: hashtags.slice(0, count),
      };
    } catch (error: any) {
      console.error('Hashtag generation error:', error);
      return { success: false, error: error.message || 'Failed to generate hashtags' };
    }
  }
  
  /**
   * Generate bio
   */
  static async generateBio(
    name: string,
    profession: string,
    interests: string[],
    platform: 'instagram' | 'twitter' | 'linkedin' | 'general'
  ): Promise<{
    success: boolean;
    bio?: string;
    error?: string;
  }> {
    try {
      if (!openai) {
        return { success: false, error: 'OpenAI API key not configured' };
      }
      
      const platformLimits: Record<string, number> = {
        instagram: 150,
        twitter: 160,
        linkedin: 2000,
        general: 200,
      };
      
      const systemPrompt = `You are a personal branding expert. Create an engaging ${platform} bio for ${name}, a ${profession}. Interests: ${interests.join(', ')}. Keep it under ${platformLimits[platform]} characters, engaging, and authentic.`;
      
      const response = await openai.chat.completions.create({
        model: 'gpt-3.5-turbo',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: `Generate a ${platform} bio` },
        ],
        max_tokens: 300,
        temperature: 0.8,
      });
      
      const bio = response.choices[0]?.message?.content?.trim() || '';
      
      return {
        success: true,
        bio,
      };
    } catch (error: any) {
      console.error('Bio generation error:', error);
      return { success: false, error: error.message || 'Failed to generate bio' };
    }
  }
  
  /**
   * Summarize text
   */
  static async summarize(
    text: string,
    maxLength: number = 200
  ): Promise<{
    success: boolean;
    summary?: string;
    error?: string;
  }> {
    try {
      if (!openai) {
        return { success: false, error: 'OpenAI API key not configured' };
      }
      
      const systemPrompt = `You are a summarization expert. Summarize the following text in under ${maxLength} words while keeping the key points.`;
      
      const response = await openai.chat.completions.create({
        model: 'gpt-3.5-turbo',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: text },
        ],
        max_tokens: Math.ceil(maxLength * 1.5),
        temperature: 0.5,
      });
      
      return {
        success: true,
        summary: response.choices[0]?.message?.content?.trim(),
      };
    } catch (error: any) {
      console.error('Summarization error:', error);
      return { success: false, error: error.message || 'Failed to summarize text' };
    }
  }
  
  /**
   * Translate text
   */
  static async translate(
    text: string,
    targetLanguage: string,
    sourceLanguage?: string
  ): Promise<{
    success: boolean;
    translation?: string;
    error?: string;
  }> {
    try {
      if (!openai) {
        return { success: false, error: 'OpenAI API key not configured' };
      }
      
      const sourceInfo = sourceLanguage ? `from ${sourceLanguage}` : '';
      const systemPrompt = `You are a professional translator. Translate the following text ${sourceInfo} to ${targetLanguage}. Maintain the original tone and meaning. Return only the translation, no explanations.`;
      
      const response = await openai.chat.completions.create({
        model: 'gpt-4',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: text },
        ],
        max_tokens: 2000,
        temperature: 0.3,
      });
      
      return {
        success: true,
        translation: response.choices[0]?.message?.content?.trim(),
      };
    } catch (error: any) {
      console.error('Translation error:', error);
      return { success: false, error: error.message || 'Failed to translate text' };
    }
  }
}

export default AiService;
