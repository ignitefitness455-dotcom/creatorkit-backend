import QRCode from 'qrcode';
import fs from 'fs/promises';
import path from 'path';
import { generateId } from '../utils/helpers';
import type { QrCodeOptions, ProcessResult } from '../types';

const OUTPUT_DIR = process.env.OUTPUT_DIR 
  ? path.resolve(process.env.OUTPUT_DIR) 
  : path.join(process.cwd(), 'outputs');

// Ensure directory exists
async function ensureDirectory() {
  try {
    await fs.mkdir(OUTPUT_DIR, { recursive: true });
  } catch (error) {
    console.error('Failed to create directory:', error);
  }
}

ensureDirectory();

export class QrService {
  /**
   * Generate QR Code
   */
  static async generate(options: QrCodeOptions): Promise<ProcessResult> {
    try {
      const { text, size = 300, color = '#000000', bgColor = '#FFFFFF' } = options;
      
      if (!text) {
        return { success: false, error: 'Text is required for QR code generation' };
      }
      
      const outputId = generateId();
      const outputPath = path.join(OUTPUT_DIR, `${outputId}.png`);
      
      // QR Code options
      const qrOptions: QRCode.QRCodeToFileOptions = {
        width: size,
        margin: 2,
        color: {
          dark: color,
          light: bgColor,
        },
        type: 'png',
      };
      
      await QRCode.toFile(outputPath, text, qrOptions);
      
      const stats = await fs.stat(outputPath);
      
      return {
        success: true,
        fileUrl: `/outputs/${outputId}.png`,
        fileName: `qrcode_${outputId}.png`,
        mimeType: 'image/png',
        size: stats.size,
      };
    } catch (error) {
      console.error('QR Code generation error:', error);
      return { success: false, error: 'Failed to generate QR code' };
    }
  }
  
  /**
   * Generate QR Code as data URL (for direct display)
   */
  static async generateDataUrl(options: QrCodeOptions): Promise<{
    success: boolean;
    dataUrl?: string;
    error?: string;
  }> {
    try {
      const { text, size = 300, color = '#000000', bgColor = '#FFFFFF' } = options;
      
      if (!text) {
        return { success: false, error: 'Text is required for QR code generation' };
      }
      
      const qrOptions: QRCode.QRCodeToDataURLOptions = {
        width: size,
        margin: 2,
        color: {
          dark: color,
          light: bgColor,
        },
        type: 'image/png',
      };
      
      const dataUrl = await QRCode.toDataURL(text, qrOptions);
      
      return {
        success: true,
        dataUrl,
      };
    } catch (error) {
      console.error('QR Code data URL error:', error);
      return { success: false, error: 'Failed to generate QR code' };
    }
  }
  
  /**
   * Generate WiFi QR Code
   */
  static async generateWiFi(
    ssid: string,
    password: string,
    encryption: 'WPA' | 'WEP' | 'nopass' = 'WPA',
    hidden: boolean = false
  ): Promise<ProcessResult> {
    try {
      const wifiString = `WIFI:T:${encryption};S:${ssid};P:${password};H:${hidden ? 'true' : 'false'};;`;
      return await this.generate({ text: wifiString });
    } catch (error) {
      console.error('WiFi QR error:', error);
      return { success: false, error: 'Failed to generate WiFi QR code' };
    }
  }
  
  /**
   * Generate vCard QR Code
   */
  static async generateVCard(data: {
    firstName: string;
    lastName: string;
    phone?: string;
    email?: string;
    organization?: string;
    title?: string;
    url?: string;
    address?: string;
  }): Promise<ProcessResult> {
    try {
      const vCard = [
        'BEGIN:VCARD',
        'VERSION:3.0',
        `N:${data.lastName};${data.firstName};;;`,
        `FN:${data.firstName} ${data.lastName}`,
        data.phone ? `TEL:${data.phone}` : '',
        data.email ? `EMAIL:${data.email}` : '',
        data.organization ? `ORG:${data.organization}` : '',
        data.title ? `TITLE:${data.title}` : '',
        data.url ? `URL:${data.url}` : '',
        data.address ? `ADR:;;${data.address};;;;` : '',
        'END:VCARD',
      ].filter(Boolean).join('\n');
      
      return await this.generate({ text: vCard });
    } catch (error) {
      console.error('vCard QR error:', error);
      return { success: false, error: 'Failed to generate vCard QR code' };
    }
  }
  
  /**
   * Generate Email QR Code
   */
  static async generateEmail(
    email: string,
    subject?: string,
    body?: string
  ): Promise<ProcessResult> {
    try {
      let mailtoString = `mailto:${email}`;
      if (subject || body) {
        const params = new URLSearchParams();
        if (subject) params.append('subject', subject);
        if (body) params.append('body', body);
        mailtoString += `?${params.toString()}`;
      }
      
      return await this.generate({ text: mailtoString });
    } catch (error) {
      console.error('Email QR error:', error);
      return { success: false, error: 'Failed to generate email QR code' };
    }
  }
  
  /**
   * Generate Phone QR Code
   */
  static async generatePhone(phone: string): Promise<ProcessResult> {
    try {
      return await this.generate({ text: `tel:${phone}` });
    } catch (error) {
      console.error('Phone QR error:', error);
      return { success: false, error: 'Failed to generate phone QR code' };
    }
  }
  
  /**
   * Generate SMS QR Code
   */
  static async generateSMS(phone: string, message?: string): Promise<ProcessResult> {
    try {
      const smsString = message 
        ? `sms:${phone}?body=${encodeURIComponent(message)}`
        : `sms:${phone}`;
      return await this.generate({ text: smsString });
    } catch (error) {
      console.error('SMS QR error:', error);
      return { success: false, error: 'Failed to generate SMS QR code' };
    }
  }
  
  /**
   * Generate Location QR Code
   */
  static async generateLocation(
    latitude: number,
    longitude: number,
    label?: string
  ): Promise<ProcessResult> {
    try {
      const geoString = label
        ? `geo:${latitude},${longitude}?q=${latitude},${longitude}(${encodeURIComponent(label)})`
        : `geo:${latitude},${longitude}`;
      return await this.generate({ text: geoString });
    } catch (error) {
      console.error('Location QR error:', error);
      return { success: false, error: 'Failed to generate location QR code' };
    }
  }
  
  /**
   * Generate Event QR Code
   */
  static async generateEvent(data: {
    title: string;
    startDate: Date;
    endDate: Date;
    location?: string;
    description?: string;
  }): Promise<ProcessResult> {
    try {
      const formatDate = (date: Date) => {
        return date.toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
      };
      
      const eventString = [
        'BEGIN:VEVENT',
        `SUMMARY:${data.title}`,
        `DTSTART:${formatDate(data.startDate)}`,
        `DTEND:${formatDate(data.endDate)}`,
        data.location ? `LOCATION:${data.location}` : '',
        data.description ? `DESCRIPTION:${data.description}` : '',
        'END:VEVENT',
      ].filter(Boolean).join('\n');
      
      return await this.generate({ text: eventString });
    } catch (error) {
      console.error('Event QR error:', error);
      return { success: false, error: 'Failed to generate event QR code' };
    }
  }
  
  /**
   * Generate Bitcoin QR Code
   */
  static async generateBitcoin(
    address: string,
    amount?: number,
    message?: string
  ): Promise<ProcessResult> {
    try {
      let bitcoinString = `bitcoin:${address}`;
      if (amount || message) {
        const params = new URLSearchParams();
        if (amount) params.append('amount', amount.toString());
        if (message) params.append('message', message);
        bitcoinString += `?${params.toString()}`;
      }
      
      return await this.generate({ text: bitcoinString });
    } catch (error) {
      console.error('Bitcoin QR error:', error);
      return { success: false, error: 'Failed to generate Bitcoin QR code' };
    }
  }
}

export default QrService;
