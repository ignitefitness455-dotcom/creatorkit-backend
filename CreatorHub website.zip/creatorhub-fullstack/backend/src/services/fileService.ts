import fs from 'fs/promises';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import { S3Client, PutObjectCommand, GetObjectCommand, DeleteObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { env } from '../config/env';
import { generateId, sanitizeFilename, getMimeType } from '../utils/helpers';
import type { FileUploadResult } from '../types';

const UPLOAD_DIR = process.env.UPLOAD_DIR 
  ? path.resolve(process.env.UPLOAD_DIR) 
  : path.join(process.cwd(), 'uploads');
const OUTPUT_DIR = process.env.OUTPUT_DIR 
  ? path.resolve(process.env.OUTPUT_DIR) 
  : path.join(process.cwd(), 'outputs');

// Initialize S3 client only if configured
const s3Client = env.AWS_ACCESS_KEY_ID && env.AWS_SECRET_ACCESS_KEY
  ? new S3Client({
      region: env.AWS_REGION,
      credentials: {
        accessKeyId: env.AWS_ACCESS_KEY_ID,
        secretAccessKey: env.AWS_SECRET_ACCESS_KEY,
      },
    })
  : null;

// Ensure directories exist
async function ensureDirectories() {
  try {
    await fs.mkdir(UPLOAD_DIR, { recursive: true });
    await fs.mkdir(OUTPUT_DIR, { recursive: true });
  } catch (error) {
    console.error('Failed to create directories:', error);
  }
}

ensureDirectories();

export class FileService {
  /**
   * Check if S3 is configured
   */
  static isS3Configured(): boolean {
    return !!s3Client && !!env.AWS_S3_BUCKET;
  }
  
  /**
   * Save uploaded file locally
   */
  static async saveLocalFile(
    buffer: Buffer,
    originalName: string,
    mimeType?: string
  ): Promise<FileUploadResult> {
    try {
      const id = generateId();
      const ext = path.extname(originalName);
      const filename = `${id}${ext}`;
      const filepath = path.join(UPLOAD_DIR, filename);
      
      await fs.writeFile(filepath, buffer);
      
      return {
        id,
        url: `/uploads/${filename}`,
        name: filename,
        originalName: sanitizeFilename(originalName),
        mimeType: mimeType || getMimeType(originalName),
        size: buffer.length,
      };
    } catch (error) {
      console.error('Save local file error:', error);
      throw new Error('Failed to save file');
    }
  }
  
  /**
   * Upload file to S3
   */
  static async uploadToS3(
    buffer: Buffer,
    originalName: string,
    mimeType?: string
  ): Promise<FileUploadResult> {
    try {
      if (!s3Client || !env.AWS_S3_BUCKET) {
        throw new Error('S3 not configured');
      }
      
      const id = generateId();
      const ext = path.extname(originalName);
      const key = `uploads/${id}${ext}`;
      
      await s3Client.send(
        new PutObjectCommand({
          Bucket: env.AWS_S3_BUCKET,
          Key: key,
          Body: buffer,
          ContentType: mimeType || getMimeType(originalName),
        })
      );
      
      return {
        id,
        url: `https://${env.AWS_S3_BUCKET}.s3.${env.AWS_REGION}.amazonaws.com/${key}`,
        name: key,
        originalName: sanitizeFilename(originalName),
        mimeType: mimeType || getMimeType(originalName),
        size: buffer.length,
      };
    } catch (error) {
      console.error('S3 upload error:', error);
      // Fallback to local storage
      return this.saveLocalFile(buffer, originalName, mimeType);
    }
  }
  
  /**
   * Upload file (auto-detects S3 or local)
   */
  static async uploadFile(
    buffer: Buffer,
    originalName: string,
    mimeType?: string
  ): Promise<FileUploadResult> {
    if (this.isS3Configured()) {
      return this.uploadToS3(buffer, originalName, mimeType);
    }
    return this.saveLocalFile(buffer, originalName, mimeType);
  }
  
  /**
   * Save output file locally
   */
  static async saveOutputFile(
    buffer: Buffer,
    filename: string,
    mimeType: string
  ): Promise<FileUploadResult> {
    try {
      const id = generateId();
      const ext = path.extname(filename) || '.bin';
      const outputFilename = `${id}${ext}`;
      const filepath = path.join(OUTPUT_DIR, outputFilename);
      
      await fs.writeFile(filepath, buffer);
      
      return {
        id,
        url: `/outputs/${outputFilename}`,
        name: outputFilename,
        originalName: filename,
        mimeType,
        size: buffer.length,
      };
    } catch (error) {
      console.error('Save output file error:', error);
      throw new Error('Failed to save output file');
    }
  }
  
  /**
   * Get file buffer from local storage
   */
  static async getLocalFile(filePath: string): Promise<Buffer> {
    try {
      const fullPath = filePath.startsWith('/')
        ? path.join(UPLOAD_DIR, path.basename(filePath))
        : filePath;
      return await fs.readFile(fullPath);
    } catch (error) {
      console.error('Get local file error:', error);
      throw new Error('File not found');
    }
  }
  
  /**
   * Delete local file
   */
  static async deleteLocalFile(filePath: string): Promise<void> {
    try {
      const fullPath = filePath.startsWith('/uploads/') || filePath.startsWith('/outputs/')
        ? path.join(process.cwd(), filePath)
        : filePath;
      await fs.unlink(fullPath);
    } catch (error) {
      console.error('Delete file error:', error);
    }
  }
  
  /**
   * Delete S3 file
   */
  static async deleteS3File(key: string): Promise<void> {
    try {
      if (!s3Client || !env.AWS_S3_BUCKET) {
        throw new Error('S3 not configured');
      }
      
      await s3Client.send(
        new DeleteObjectCommand({
          Bucket: env.AWS_S3_BUCKET,
          Key: key,
        })
      );
    } catch (error) {
      console.error('Delete S3 file error:', error);
    }
  }
  
  /**
   * Get file info
   */
  static async getFileInfo(filePath: string): Promise<{
    exists: boolean;
    size?: number;
    modified?: Date;
  }> {
    try {
      const stats = await fs.stat(filePath);
      return {
        exists: true,
        size: stats.size,
        modified: stats.mtime,
      };
    } catch (error) {
      return { exists: false };
    }
  }
  
  /**
   * Generate signed URL for S3
   */
  static async getSignedS3Url(key: string, expiresIn: number = 3600): Promise<string> {
    if (!s3Client || !env.AWS_S3_BUCKET) {
      throw new Error('S3 not configured');
    }
    
    const command = new GetObjectCommand({
      Bucket: env.AWS_S3_BUCKET,
      Key: key,
    });
    
    return getSignedUrl(s3Client, command, { expiresIn });
  }
  
  /**
   * Clean up old files
   */
  static async cleanupOldFiles(maxAgeHours: number = 24): Promise<number> {
    try {
      let deletedCount = 0;
      const now = Date.now();
      const maxAge = maxAgeHours * 60 * 60 * 1000;
      
      // Clean uploads
      const uploadFiles = await fs.readdir(UPLOAD_DIR);
      for (const file of uploadFiles) {
        const filePath = path.join(UPLOAD_DIR, file);
        const stats = await fs.stat(filePath);
        if (now - stats.mtime.getTime() > maxAge) {
          await fs.unlink(filePath);
          deletedCount++;
        }
      }
      
      // Clean outputs
      const outputFiles = await fs.readdir(OUTPUT_DIR);
      for (const file of outputFiles) {
        const filePath = path.join(OUTPUT_DIR, file);
        const stats = await fs.stat(filePath);
        if (now - stats.mtime.getTime() > maxAge) {
          await fs.unlink(filePath);
          deletedCount++;
        }
      }
      
      console.log(`Cleaned up ${deletedCount} old files`);
      return deletedCount;
    } catch (error) {
      console.error('Cleanup error:', error);
      return 0;
    }
  }
  
  /**
   * Get upload directory path
   */
  static getUploadDir(): string {
    return UPLOAD_DIR;
  }
  
  /**
   * Get output directory path
   */
  static getOutputDir(): string {
    return OUTPUT_DIR;
  }
}

export default FileService;
