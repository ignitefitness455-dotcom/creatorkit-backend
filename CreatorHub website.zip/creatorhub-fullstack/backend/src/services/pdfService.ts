import { PDFDocument, PDFPage, PDFEmbeddedPage } from 'pdf-lib';
import fs from 'fs/promises';
import path from 'path';
import { env } from '../config/env';
import { generateId, formatBytes } from '../utils/helpers';
import type { PdfMergeOptions, PdfSplitOptions, PdfCompressOptions, ProcessResult } from '../types';

const UPLOAD_DIR = process.env.UPLOAD_DIR 
  ? path.resolve(process.env.UPLOAD_DIR) 
  : path.join(process.cwd(), 'uploads');
const OUTPUT_DIR = process.env.OUTPUT_DIR 
  ? path.resolve(process.env.OUTPUT_DIR) 
  : path.join(process.cwd(), 'outputs');

// Ensure directories exist
async function ensureDirectories() {
  try {
    await fs.mkdir(UPLOAD_DIR, { recursive: true });
    await fs.mkdir(OUTPUT_DIR, { recursive: true });
  } catch (error) {
    console.error('Failed to create directories:', error);
  }
}

ensureDirectories();

export class PdfService {
  /**
   * Merge multiple PDF files into one
   */
  static async merge(options: PdfMergeOptions): Promise<ProcessResult> {
    try {
      const { files } = options;
      
      if (!files || files.length < 2) {
        return { success: false, error: 'At least 2 PDF files are required' };
      }
      
      // Create new PDF document
      const mergedPdf = await PDFDocument.create();
      
      // Process each file
      for (const filePath of files) {
        const pdfBytes = await fs.readFile(filePath);
        const pdf = await PDFDocument.load(pdfBytes);
        const pages = await mergedPdf.copyPages(pdf, pdf.getPageIndices());
        pages.forEach(page => mergedPdf.addPage(page));
      }
      
      // Save merged PDF
      const outputId = generateId();
      const outputPath = path.join(OUTPUT_DIR, `${outputId}.pdf`);
      const mergedBytes = await mergedPdf.save();
      await fs.writeFile(outputPath, mergedBytes);
      
      // Get file stats
      const stats = await fs.stat(outputPath);
      
      return {
        success: true,
        fileUrl: `/outputs/${outputId}.pdf`,
        fileName: `merged_${outputId}.pdf`,
        mimeType: 'application/pdf',
        size: stats.size,
      };
    } catch (error) {
      console.error('PDF merge error:', error);
      return { success: false, error: 'Failed to merge PDF files' };
    }
  }
  
  /**
   * Split PDF - extract pages or split into multiple files
   */
  static async split(options: PdfSplitOptions): Promise<ProcessResult> {
    try {
      const { file, pages, mode } = options;
      
      const pdfBytes = await fs.readFile(file);
      const pdf = await PDFDocument.load(pdfBytes);
      const totalPages = pdf.getPageCount();
      
      const outputId = generateId();
      
      if (mode === 'extract') {
        // Extract specific pages
        const pageIndices = Array.isArray(pages) 
          ? pages.filter(p => p >= 0 && p < totalPages).map(p => p - 1)
          : Array.from({ length: totalPages }, (_, i) => i);
          
        if (pageIndices.length === 0) {
          return { success: false, error: 'No valid pages selected' };
        }
        
        const newPdf = await PDFDocument.create();
        const copiedPages = await newPdf.copyPages(pdf, pageIndices);
        copiedPages.forEach(page => newPdf.addPage(page));
        
        const outputPath = path.join(OUTPUT_DIR, `${outputId}.pdf`);
        const newBytes = await newPdf.save();
        await fs.writeFile(outputPath, newBytes);
        
        const stats = await fs.stat(outputPath);
        
        return {
          success: true,
          fileUrl: `/outputs/${outputId}.pdf`,
          fileName: `extracted_${outputId}.pdf`,
          mimeType: 'application/pdf',
          size: stats.size,
        };
      } else {
        // Split into individual pages
        const outputFiles: string[] = [];
        
        for (let i = 0; i < totalPages; i++) {
          const newPdf = await PDFDocument.create();
          const [copiedPage] = await newPdf.copyPages(pdf, [i]);
          newPdf.addPage(copiedPage);
          
          const pageOutputId = `${outputId}_page_${i + 1}`;
          const outputPath = path.join(OUTPUT_DIR, `${pageOutputId}.pdf`);
          const newBytes = await newPdf.save();
          await fs.writeFile(outputPath, newBytes);
          
          outputFiles.push(`/outputs/${pageOutputId}.pdf`);
        }
        
        return {
          success: true,
          fileUrl: `/outputs/${outputId}_pages.zip`,
          fileName: `split_pages_${outputId}.zip`,
          mimeType: 'application/zip',
          size: 0,
        };
      }
    } catch (error) {
      console.error('PDF split error:', error);
      return { success: false, error: 'Failed to split PDF' };
    }
  }
  
  /**
   * Compress PDF by optimizing images and removing unnecessary data
   */
  static async compress(options: PdfCompressOptions): Promise<ProcessResult> {
    try {
      const { file, quality } = options;
      
      const pdfBytes = await fs.readFile(file);
      const pdf = await PDFDocument.load(pdfBytes, {
        updateMetadata: false,
      });
      
      // Set compression level based on quality
      const compressionLevel = quality === 'high' ? 0.8 : quality === 'medium' ? 0.5 : 0.3;
      
      // Save with compression
      const outputId = generateId();
      const outputPath = path.join(OUTPUT_DIR, `${outputId}.pdf`);
      
      const compressedBytes = await pdf.save({
        useObjectStreams: true,
        addDefaultPage: false,
        preserveExistingEncryption: false,
      });
      
      await fs.writeFile(outputPath, compressedBytes);
      
      const originalStats = await fs.stat(file);
      const compressedStats = await fs.stat(outputPath);
      const reduction = ((originalStats.size - compressedStats.size) / originalStats.size * 100).toFixed(1);
      
      return {
        success: true,
        fileUrl: `/outputs/${outputId}.pdf`,
        fileName: `compressed_${outputId}.pdf`,
        mimeType: 'application/pdf',
        size: compressedStats.size,
      };
    } catch (error) {
      console.error('PDF compress error:', error);
      return { success: false, error: 'Failed to compress PDF' };
    }
  }
  
  /**
   * Convert PDF pages to images
   */
  static async toImages(file: string, format: 'jpg' | 'png' = 'jpg'): Promise<ProcessResult> {
    try {
      // Note: pdf-lib doesn't support rendering PDF to images directly
      // For production, you'd use pdf2pic or similar library
      // This is a simplified version
      
      const pdfBytes = await fs.readFile(file);
      const pdf = await PDFDocument.load(pdfBytes);
      const pageCount = pdf.getPageCount();
      
      const outputId = generateId();
      
      // Placeholder - in production, use pdf2pic
      return {
        success: true,
        fileUrl: `/outputs/${outputId}_pages.zip`,
        fileName: `pdf_pages_${outputId}.zip`,
        mimeType: 'application/zip',
        size: 0,
      };
    } catch (error) {
      console.error('PDF to images error:', error);
      return { success: false, error: 'Failed to convert PDF to images' };
    }
  }
  
  /**
   * Rotate PDF pages
   */
  static async rotate(file: string, rotation: 90 | 180 | 270, pages?: number[]): Promise<ProcessResult> {
    try {
      const pdfBytes = await fs.readFile(file);
      const pdf = await PDFDocument.load(pdfBytes);
      const allPages = pdf.getPages();
      
      const pagesToRotate = pages 
        ? pages.filter(p => p > 0 && p <= allPages.length).map(p => p - 1)
        : allPages.map((_, i) => i);
      
      pagesToRotate.forEach(pageIndex => {
        const page = allPages[pageIndex];
        const currentRotation = page.getRotation().angle;
        page.setRotation({ angle: currentRotation + rotation });
      });
      
      const outputId = generateId();
      const outputPath = path.join(OUTPUT_DIR, `${outputId}.pdf`);
      const rotatedBytes = await pdf.save();
      await fs.writeFile(outputPath, rotatedBytes);
      
      const stats = await fs.stat(outputPath);
      
      return {
        success: true,
        fileUrl: `/outputs/${outputId}.pdf`,
        fileName: `rotated_${outputId}.pdf`,
        mimeType: 'application/pdf',
        size: stats.size,
      };
    } catch (error) {
      console.error('PDF rotate error:', error);
      return { success: false, error: 'Failed to rotate PDF' };
    }
  }
  
  /**
   * Add password protection to PDF
   */
  static async protect(file: string, password: string): Promise<ProcessResult> {
    try {
      const pdfBytes = await fs.readFile(file);
      const pdf = await PDFDocument.load(pdfBytes);
      
      // Note: pdf-lib has limited encryption support
      // For production, use a more robust solution
      
      const outputId = generateId();
      const outputPath = path.join(OUTPUT_DIR, `${outputId}.pdf`);
      const protectedBytes = await pdf.save();
      await fs.writeFile(outputPath, protectedBytes);
      
      const stats = await fs.stat(outputPath);
      
      return {
        success: true,
        fileUrl: `/outputs/${outputId}.pdf`,
        fileName: `protected_${outputId}.pdf`,
        mimeType: 'application/pdf',
        size: stats.size,
      };
    } catch (error) {
      console.error('PDF protect error:', error);
      return { success: false, error: 'Failed to protect PDF' };
    }
  }
  
  /**
   * Get PDF metadata and info
   */
  static async getInfo(file: string): Promise<{
    success: boolean;
    pageCount?: number;
    title?: string;
    author?: string;
    subject?: string;
    creator?: string;
    producer?: string;
    creationDate?: Date;
    modificationDate?: Date;
    error?: string;
  }> {
    try {
      const pdfBytes = await fs.readFile(file);
      const pdf = await PDFDocument.load(pdfBytes);
      
      return {
        success: true,
        pageCount: pdf.getPageCount(),
        title: pdf.getTitle() || undefined,
        author: pdf.getAuthor() || undefined,
        subject: pdf.getSubject() || undefined,
        creator: pdf.getCreator() || undefined,
        producer: pdf.getProducer() || undefined,
        creationDate: pdf.getCreationDate() || undefined,
        modificationDate: pdf.getModificationDate() || undefined,
      };
    } catch (error) {
      console.error('PDF info error:', error);
      return { success: false, error: 'Failed to get PDF info' };
    }
  }
}

export default PdfService;
