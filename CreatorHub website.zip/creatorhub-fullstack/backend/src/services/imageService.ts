import sharp from 'sharp';
import fs from 'fs/promises';
import path from 'path';
import { generateId, formatBytes } from '../utils/helpers';
import type { ImageResizeOptions, ImageCompressOptions, WatermarkOptions, ProcessResult } from '../types';

const UPLOAD_DIR = process.env.UPLOAD_DIR 
  ? path.resolve(process.env.UPLOAD_DIR) 
  : path.join(process.cwd(), 'uploads');
const OUTPUT_DIR = process.env.OUTPUT_DIR 
  ? path.resolve(process.env.OUTPUT_DIR) 
  : path.join(process.cwd(), 'outputs');

// Ensure directories exist
async function ensureDirectories() {
  try {
    await fs.mkdir(UPLOAD_DIR, { recursive: true });
    await fs.mkdir(OUTPUT_DIR, { recursive: true });
  } catch (error) {
    console.error('Failed to create directories:', error);
  }
}

ensureDirectories();

export class ImageService {
  /**
   * Resize an image
   */
  static async resize(options: ImageResizeOptions): Promise<ProcessResult> {
    try {
      const { file, width, height, maintainAspectRatio } = options;
      
      if (!width && !height) {
        return { success: false, error: 'Width or height must be specified' };
      }
      
      const image = sharp(file);
      const metadata = await image.metadata();
      
      let resizeOptions: sharp.ResizeOptions = {
        width,
        height,
        fit: maintainAspectRatio ? 'inside' : 'fill',
        withoutEnlargement: false,
      };
      
      const outputId = generateId();
      const ext = metadata.format || 'jpeg';
      const outputPath = path.join(OUTPUT_DIR, `${outputId}.${ext}`);
      
      await image.resize(resizeOptions).toFile(outputPath);
      
      const stats = await fs.stat(outputPath);
      
      return {
        success: true,
        fileUrl: `/outputs/${outputId}.${ext}`,
        fileName: `resized_${outputId}.${ext}`,
        mimeType: `image/${ext}`,
        size: stats.size,
      };
    } catch (error) {
      console.error('Image resize error:', error);
      return { success: false, error: 'Failed to resize image' };
    }
  }
  
  /**
   * Compress an image
   */
  static async compress(options: ImageCompressOptions): Promise<ProcessResult> {
    try {
      const { file, quality, format } = options;
      
      const image = sharp(file);
      const metadata = await image.metadata();
      
      const outputFormat = format || metadata.format || 'jpeg';
      const outputId = generateId();
      const outputPath = path.join(OUTPUT_DIR, `${outputId}.${outputFormat}`);
      
      let pipeline = image;
      
      // Apply compression based on format
      switch (outputFormat) {
        case 'jpeg':
        case 'jpg':
          pipeline = pipeline.jpeg({ quality, progressive: true, mozjpeg: true });
          break;
        case 'png':
          pipeline = pipeline.png({ 
            quality: Math.min(quality, 100),
            compressionLevel: 9,
            adaptiveFiltering: true,
          });
          break;
        case 'webp':
          pipeline = pipeline.webp({ quality, effort: 6 });
          break;
        default:
          pipeline = pipeline.jpeg({ quality });
      }
      
      await pipeline.toFile(outputPath);
      
      const originalStats = await fs.stat(file);
      const compressedStats = await fs.stat(outputPath);
      const reduction = ((originalStats.size - compressedStats.size) / originalStats.size * 100).toFixed(1);
      
      return {
        success: true,
        fileUrl: `/outputs/${outputId}.${outputFormat}`,
        fileName: `compressed_${outputId}.${outputFormat}`,
        mimeType: `image/${outputFormat}`,
        size: compressedStats.size,
      };
    } catch (error) {
      console.error('Image compress error:', error);
      return { success: false, error: 'Failed to compress image' };
    }
  }
  
  /**
   * Convert image format
   */
  static async convert(file: string, targetFormat: 'jpeg' | 'png' | 'webp' | 'gif' | 'avif'): Promise<ProcessResult> {
    try {
      const image = sharp(file);
      const outputId = generateId();
      const outputPath = path.join(OUTPUT_DIR, `${outputId}.${targetFormat}`);
      
      let pipeline = image;
      
      switch (targetFormat) {
        case 'jpeg':
        case 'jpg':
          pipeline = pipeline.jpeg({ quality: 90, progressive: true });
          break;
        case 'png':
          pipeline = pipeline.png({ compressionLevel: 9 });
          break;
        case 'webp':
          pipeline = pipeline.webp({ quality: 90 });
          break;
        case 'gif':
          // GIF conversion requires special handling
          pipeline = pipeline.gif();
          break;
        case 'avif':
          pipeline = pipeline.avif({ quality: 80 });
          break;
      }
      
      await pipeline.toFile(outputPath);
      
      const stats = await fs.stat(outputPath);
      
      return {
        success: true,
        fileUrl: `/outputs/${outputId}.${targetFormat}`,
        fileName: `converted_${outputId}.${targetFormat}`,
        mimeType: `image/${targetFormat}`,
        size: stats.size,
      };
    } catch (error) {
      console.error('Image convert error:', error);
      return { success: false, error: 'Failed to convert image' };
    }
  }
  
  /**
   * Crop an image
   */
  static async crop(
    file: string,
    left: number,
    top: number,
    width: number,
    height: number
  ): Promise<ProcessResult> {
    try {
      const image = sharp(file);
      const metadata = await image.metadata();
      const outputId = generateId();
      const ext = metadata.format || 'jpeg';
      const outputPath = path.join(OUTPUT_DIR, `${outputId}.${ext}`);
      
      await image
        .extract({ left, top, width, height })
        .toFile(outputPath);
      
      const stats = await fs.stat(outputPath);
      
      return {
        success: true,
        fileUrl: `/outputs/${outputId}.${ext}`,
        fileName: `cropped_${outputId}.${ext}`,
        mimeType: `image/${ext}`,
        size: stats.size,
      };
    } catch (error) {
      console.error('Image crop error:', error);
      return { success: false, error: 'Failed to crop image' };
    }
  }
  
  /**
   * Add watermark to image
   */
  static async addWatermark(options: WatermarkOptions): Promise<ProcessResult> {
    try {
      const { file, text, imageUrl, position, opacity, size } = options;
      
      const image = sharp(file);
      const metadata = await image.metadata();
      const imgWidth = metadata.width || 800;
      const imgHeight = metadata.height || 600;
      
      let watermarkBuffer: Buffer;
      
      if (text) {
        // Create text watermark using SVG
        const svgText = `
          <svg width="${imgWidth}" height="${imgHeight}">
            <text x="50%" y="50%" 
              font-family="Arial" 
              font-size="${Math.floor(imgWidth * size / 100)}" 
              fill="white" 
              opacity="${opacity / 100}"
              text-anchor="middle"
              dominant-baseline="middle"
            >${text}</text>
          </svg>
        `;
        watermarkBuffer = Buffer.from(svgText);
      } else if (imageUrl) {
        // Use image as watermark
        watermarkBuffer = await fs.readFile(imageUrl);
      } else {
        return { success: false, error: 'Text or image watermark required' };
      }
      
      // Calculate position
      let gravity: sharp.Gravity;
      switch (position) {
        case 'top-left':
          gravity = 'northwest';
          break;
        case 'top-right':
          gravity = 'northeast';
          break;
        case 'bottom-left':
          gravity = 'southwest';
          break;
        case 'bottom-right':
          gravity = 'southeast';
          break;
        case 'center':
        default:
          gravity = 'center';
      }
      
      const outputId = generateId();
      const ext = metadata.format || 'jpeg';
      const outputPath = path.join(OUTPUT_DIR, `${outputId}.${ext}`);
      
      await image
        .composite([{
          input: watermarkBuffer,
          gravity,
        }])
        .toFile(outputPath);
      
      const stats = await fs.stat(outputPath);
      
      return {
        success: true,
        fileUrl: `/outputs/${outputId}.${ext}`,
        fileName: `watermarked_${outputId}.${ext}`,
        mimeType: `image/${ext}`,
        size: stats.size,
      };
    } catch (error) {
      console.error('Watermark error:', error);
      return { success: false, error: 'Failed to add watermark' };
    }
  }
  
  /**
   * Remove background from image (placeholder - requires AI service)
   */
  static async removeBackground(file: string): Promise<ProcessResult> {
    try {
      // This requires an AI service like remove.bg API or local ML model
      // For now, return a placeholder response
      
      return {
        success: false,
        error: 'Background removal requires AI service integration. Please configure remove.bg API key.',
      };
    } catch (error) {
      console.error('Background removal error:', error);
      return { success: false, error: 'Failed to remove background' };
    }
  }
  
  /**
   * Rotate an image
   */
  static async rotate(file: string, angle: 90 | 180 | 270): Promise<ProcessResult> {
    try {
      const image = sharp(file);
      const metadata = await image.metadata();
      const outputId = generateId();
      const ext = metadata.format || 'jpeg';
      const outputPath = path.join(OUTPUT_DIR, `${outputId}.${ext}`);
      
      await image.rotate(angle).toFile(outputPath);
      
      const stats = await fs.stat(outputPath);
      
      return {
        success: true,
        fileUrl: `/outputs/${outputId}.${ext}`,
        fileName: `rotated_${outputId}.${ext}`,
        mimeType: `image/${ext}`,
        size: stats.size,
      };
    } catch (error) {
      console.error('Image rotate error:', error);
      return { success: false, error: 'Failed to rotate image' };
    }
  }
  
  /**
   * Flip an image
   */
  static async flip(file: string, direction: 'horizontal' | 'vertical'): Promise<ProcessResult> {
    try {
      const image = sharp(file);
      const metadata = await image.metadata();
      const outputId = generateId();
      const ext = metadata.format || 'jpeg';
      const outputPath = path.join(OUTPUT_DIR, `${outputId}.${ext}`);
      
      if (direction === 'horizontal') {
        await image.flop().toFile(outputPath);
      } else {
        await image.flip().toFile(outputPath);
      }
      
      const stats = await fs.stat(outputPath);
      
      return {
        success: true,
        fileUrl: `/outputs/${outputId}.${ext}`,
        fileName: `flipped_${outputId}.${ext}`,
        mimeType: `image/${ext}`,
        size: stats.size,
      };
    } catch (error) {
      console.error('Image flip error:', error);
      return { success: false, error: 'Failed to flip image' };
    }
  }
  
  /**
   * Get image metadata
   */
  static async getMetadata(file: string): Promise<{
    success: boolean;
    format?: string;
    width?: number;
    height?: number;
    size?: number;
    hasAlpha?: boolean;
    error?: string;
  }> {
    try {
      const metadata = await sharp(file).metadata();
      const stats = await fs.stat(file);
      
      return {
        success: true,
        format: metadata.format,
        width: metadata.width,
        height: metadata.height,
        size: stats.size,
        hasAlpha: metadata.hasAlpha,
      };
    } catch (error) {
      console.error('Metadata error:', error);
      return { success: false, error: 'Failed to get image metadata' };
    }
  }
  
  /**
   * Create thumbnail
   */
  static async createThumbnail(file: string, width: number = 200, height: number = 200): Promise<ProcessResult> {
    try {
      const image = sharp(file);
      const metadata = await image.metadata();
      const outputId = generateId();
      const ext = metadata.format || 'jpeg';
      const outputPath = path.join(OUTPUT_DIR, `thumb_${outputId}.${ext}`);
      
      await image
        .resize(width, height, { fit: 'cover', position: 'center' })
        .toFile(outputPath);
      
      const stats = await fs.stat(outputPath);
      
      return {
        success: true,
        fileUrl: `/outputs/thumb_${outputId}.${ext}`,
        fileName: `thumbnail_${outputId}.${ext}`,
        mimeType: `image/${ext}`,
        size: stats.size,
      };
    } catch (error) {
      console.error('Thumbnail error:', error);
      return { success: false, error: 'Failed to create thumbnail' };
    }
  }
}

export default ImageService;
