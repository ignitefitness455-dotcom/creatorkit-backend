import Stripe from 'stripe';
import { env } from '../config/env';
import { prisma } from '../config/database';
import type { UserPlan } from '../types';

// Initialize Stripe only if configured
const stripe = env.STRIPE_SECRET_KEY
  ? new Stripe(env.STRIPE_SECRET_KEY, { apiVersion: '2024-06-20' as Stripe.LatestApiVersion })
  : null;

export class PaymentService {
  /**
   * Check if Stripe is configured
   */
  static isConfigured(): boolean {
    return !!stripe;
  }
  
  /**
   * Create a checkout session for subscription
   */
  static async createCheckoutSession(
    userId: string,
    plan: UserPlan,
    successUrl: string,
    cancelUrl: string
  ): Promise<{
    success: boolean;
    sessionId?: string;
    url?: string;
    error?: string;
  }> {
    try {
      if (!stripe) {
        return { success: false, error: 'Stripe not configured' };
      }
      
      const user = await prisma.user.findUnique({ where: { id: userId } });
      if (!user) {
        return { success: false, error: 'User not found' };
      }
      
      const priceId = plan === 'PRO' 
        ? env.STRIPE_PRICE_PRO 
        : env.STRIPE_PRICE_BUSINESS;
        
      if (!priceId) {
        return { success: false, error: 'Price ID not configured for this plan' };
      }
      
      const session = await stripe.checkout.sessions.create({
        customer_email: user.email,
        line_items: [
          {
            price: priceId,
            quantity: 1,
          },
        ],
        mode: 'subscription',
        success_url: successUrl,
        cancel_url: cancelUrl,
        metadata: {
          userId,
          plan,
        },
      });
      
      // Create pending payment record
      await prisma.payment.create({
        data: {
          userId,
          amount: plan === 'PRO' ? 999 : 2999, // $9.99 or $29.99 in cents
          currency: 'usd',
          status: 'PENDING',
          plan,
        },
      });
      
      return {
        success: true,
        sessionId: session.id,
        url: session.url || undefined,
      };
    } catch (error: any) {
      console.error('Create checkout session error:', error);
      return { success: false, error: error.message };
    }
  }
  
  /**
   * Create a customer portal session
   */
  static async createPortalSession(
    customerId: string,
    returnUrl: string
  ): Promise<{
    success: boolean;
    url?: string;
    error?: string;
  }> {
    try {
      if (!stripe) {
        return { success: false, error: 'Stripe not configured' };
      }
      
      const session = await stripe.billingPortal.sessions.create({
        customer: customerId,
        return_url: returnUrl,
      });
      
      return {
        success: true,
        url: session.url,
      };
    } catch (error: any) {
      console.error('Create portal session error:', error);
      return { success: false, error: error.message };
    }
  }
  
  /**
   * Handle webhook events
   */
  static async handleWebhook(payload: string | Buffer, signature: string): Promise<{
    success: boolean;
    event?: Stripe.Event;
    error?: string;
  }> {
    try {
      if (!stripe || !env.STRIPE_WEBHOOK_SECRET) {
        return { success: false, error: 'Stripe webhook not configured' };
      }
      
      const event = stripe.webhooks.constructEvent(
        payload,
        signature,
        env.STRIPE_WEBHOOK_SECRET
      );
      
      // Handle the event
      switch (event.type) {
        case 'checkout.session.completed':
          await this.handleCheckoutCompleted(event.data.object as Stripe.Checkout.Session);
          break;
          
        case 'invoice.payment_succeeded':
          await this.handlePaymentSucceeded(event.data.object as Stripe.Invoice);
          break;
          
        case 'invoice.payment_failed':
          await this.handlePaymentFailed(event.data.object as Stripe.Invoice);
          break;
          
        case 'customer.subscription.deleted':
          await this.handleSubscriptionCanceled(event.data.object as Stripe.Subscription);
          break;
      }
      
      return { success: true, event };
    } catch (error: any) {
      console.error('Webhook error:', error);
      return { success: false, error: error.message };
    }
  }
  
  /**
   * Handle checkout session completed
   */
  private static async handleCheckoutCompleted(session: Stripe.Checkout.Session): Promise<void> {
    const userId = session.metadata?.userId;
    const plan = session.metadata?.plan as UserPlan;
    
    if (!userId || !plan) {
      console.error('Missing metadata in checkout session');
      return;
    }
    
    // Update user plan
    await prisma.user.update({
      where: { id: userId },
      data: {
        plan,
        credits: plan === 'PRO' ? 500 : 2000,
      },
    });
    
    // Update payment status
    await prisma.payment.updateMany({
      where: {
        userId,
        status: 'PENDING',
      },
      data: {
        status: 'COMPLETED',
      },
    });
    
    console.log(`User ${userId} upgraded to ${plan} plan`);
  }
  
  /**
   * Handle payment succeeded
   */
  private static async handlePaymentSucceeded(invoice: Stripe.Invoice): Promise<void> {
    console.log('Payment succeeded:', invoice.id);
  }
  
  /**
   * Handle payment failed
   */
  private static async handlePaymentFailed(invoice: Stripe.Invoice): Promise<void> {
    console.log('Payment failed:', invoice.id);
  }
  
  /**
   * Handle subscription canceled
   */
  private static async handleSubscriptionCanceled(subscription: Stripe.Subscription): Promise<void> {
    console.log('Subscription canceled:', subscription.id);
  }
  
  /**
   * Get subscription details
   */
  static async getSubscription(subscriptionId: string): Promise<{
    success: boolean;
    subscription?: Stripe.Subscription;
    error?: string;
  }> {
    try {
      if (!stripe) {
        return { success: false, error: 'Stripe not configured' };
      }
      
      const subscription = await stripe.subscriptions.retrieve(subscriptionId);
      return { success: true, subscription };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }
  
  /**
   * Cancel subscription
   */
  static async cancelSubscription(subscriptionId: string): Promise<{
    success: boolean;
    subscription?: Stripe.Subscription;
    error?: string;
  }> {
    try {
      if (!stripe) {
        return { success: false, error: 'Stripe not configured' };
      }
      
      const subscription = await stripe.subscriptions.cancel(subscriptionId);
      return { success: true, subscription };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }
  
  /**
   * Get or create customer
   */
  static async getOrCreateCustomer(email: string, name?: string): Promise<{
    success: boolean;
    customerId?: string;
    error?: string;
  }> {
    try {
      if (!stripe) {
        return { success: false, error: 'Stripe not configured' };
      }
      
      // Search for existing customer
      const customers = await stripe.customers.list({
        email,
        limit: 1,
      });
      
      if (customers.data.length > 0) {
        return { success: true, customerId: customers.data[0].id };
      }
      
      // Create new customer
      const customer = await stripe.customers.create({
        email,
        name,
      });
      
      return { success: true, customerId: customer.id };
    } catch (error: any) {
      return { success: false, error: error.message };
    }
  }
}

export default PaymentService;
