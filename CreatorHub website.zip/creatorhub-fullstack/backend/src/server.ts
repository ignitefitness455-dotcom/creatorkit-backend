import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import compression from 'compression';
import cookieParser from 'cookie-parser';
import path from 'path';
import { connectDatabase, prisma } from './config/database';
import { errorHandler, notFoundHandler } from './middleware/errorHandler';
import { apiRateLimiter } from './middleware/rateLimiter';
import { FileService } from './services/fileService';
import { PaymentService } from './services/paymentService';

// Import routes
import authRoutes from './routes/auth';
import toolsRoutes from './routes/tools';
import userRoutes from './routes/user';
import paymentsRoutes from './routes/payments';

const app = express();
const PORT = process.env.PORT || 5000;

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
  console.error('Uncaught Exception:', err);
  process.exit(1);
});

// Handle unhandled promise rejections
process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

// Middleware
app.use(helmet({
  crossOriginResourcePolicy: { policy: 'cross-origin' },
}));

app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:5173',
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
  exposedHeaders: ['Content-Range', 'X-Content-Range'],
}));

// Handle preflight requests
app.options('*', cors());

app.use(compression());

// Stripe webhook route needs raw body - MUST be before express.json()
app.use('/api/payments/webhook', express.raw({ type: 'application/json' }), async (req, res, next) => {
  try {
    const signature = req.headers['stripe-signature'] as string;
    
    if (!signature) {
      return res.status(400).json({ success: false, error: 'Stripe signature required' });
    }
    
    const result = await PaymentService.handleWebhook(req.body, signature);
    
    if (!result.success) {
      return res.status(400).json({ success: false, error: result.error || 'Webhook processing failed' });
    }
    
    res.json({ received: true });
  } catch (error: any) {
    console.error('Webhook error:', error);
    res.status(400).json({ success: false, error: error.message || 'Webhook error' });
  }
});

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));
app.use(cookieParser());
app.use(morgan('dev'));

// Rate limiting
app.use('/api/', apiRateLimiter);

// Static files
app.use('/uploads', express.static(FileService.getUploadDir()));
app.use('/outputs', express.static(FileService.getOutputDir()));

// Health check
app.get('/health', async (req, res) => {
  try {
    await prisma.$queryRaw`SELECT 1`;
    res.json({ 
      status: 'healthy', 
      database: 'connected',
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
      version: process.env.npm_package_version || '1.0.0',
    });
  } catch (error) {
    res.status(503).json({ 
      status: 'unhealthy', 
      database: 'disconnected',
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
    });
  }
});

// API info
app.get('/api', (req, res) => {
  res.json({
    name: 'CreatorHub API',
    version: '1.0.0',
    status: 'running',
    documentation: '/api/docs',
    endpoints: {
      auth: '/api/auth',
      tools: '/api/tools',
      user: '/api/user',
      payments: '/api/payments',
    },
  });
});

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/tools', toolsRoutes);
app.use('/api/user', userRoutes);
app.use('/api/payments', paymentsRoutes);

// Error handling
app.use(notFoundHandler);
app.use(errorHandler);

// Start server
async function startServer() {
  try {
    // Connect to database
    const dbConnected = await connectDatabase();
    
    if (!dbConnected) {
      console.error('Failed to connect to database. Server will start but may not function correctly.');
    }
    
    // Clean up old files periodically
    setInterval(() => {
      FileService.cleanupOldFiles(24);
    }, 60 * 60 * 1000); // Every hour
    
    const server = app.listen(PORT, () => {
      console.log(`
╔═══════════════════════════════════════════════════════════╗
║                                                           ║
║   🚀 CreatorHub API Server                                ║
║                                                           ║
║   Port: ${PORT.toString().padEnd(50)}║
║   URL: http://localhost:${PORT}${' '.repeat(27)}║
║   Environment: ${(process.env.NODE_ENV || 'development').padEnd(43)}║
║   Database: ${(dbConnected ? 'Connected' : 'Disconnected').padEnd(46)}║
║                                                           ║
╚═══════════════════════════════════════════════════════════╝
      `);
    });

    // Graceful shutdown
    const gracefulShutdown = async (signal: string) => {
      console.log(`\n${signal} received. Starting graceful shutdown...`);
      
      server.close(async () => {
        console.log('HTTP server closed');
        
        try {
          await prisma.$disconnect();
          console.log('Database disconnected');
          process.exit(0);
        } catch (err) {
          console.error('Error during shutdown:', err);
          process.exit(1);
        }
      });

      // Force shutdown after 10 seconds
      setTimeout(() => {
        console.error('Forced shutdown after timeout');
        process.exit(1);
      }, 10000);
    };

    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));

  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();

export default app;
