import { Request } from 'express';

// User Types
export interface AuthenticatedRequest extends Request {
  user?: {
    id: string;
    email: string;
    name: string;
    plan: string;
    credits: number;
  };
}

export interface TokenPayload {
  userId: string;
  email: string;
  type: 'access' | 'refresh';
}

export interface JwtPayload {
  userId: string;
  email: string;
  plan: string;
}

// User Plan Type
export type UserPlan = 'FREE' | 'PRO' | 'BUSINESS';

// File Types
export interface FileUpload {
  fieldname: string;
  originalname: string;
  encoding: string;
  mimetype: string;
  destination: string;
  filename: string;
  path: string;
  size: number;
}

export interface FileUploadResult {
  id: string;
  url: string;
  name: string;
  originalName: string;
  mimeType: string;
  size: number;
}

// Process Result Type
export interface ProcessResult {
  success: boolean;
  fileUrl?: string;
  fileName?: string;
  mimeType?: string;
  size?: number;
  error?: string;
}

// Tool Type
export interface Tool {
  id: string;
  name: string;
  description: string;
  category: string;
  icon: string;
  color: string;
  isPremium: boolean;
  plan: UserPlan;
  maxFileSize?: number;
  allowedTypes?: string[];
  rating: number;
  usageCount: number;
  creditCost: number;
}

// Tool Types
export interface ToolOptions {
  [key: string]: any;
}

export interface PdfMergeOptions extends ToolOptions {
  files: string[];
  pageOrder?: 'natural' | 'reverse' | 'alternate';
}

export interface PdfSplitOptions extends ToolOptions {
  file: string;
  pages?: number[] | string;
  mode: 'extract' | 'split';
  range?: string;
  every?: number;
}

export interface PdfCompressOptions extends ToolOptions {
  file: string;
  quality: 'low' | 'medium' | 'high';
}

export interface ImageResizeOptions extends ToolOptions {
  file: string;
  width?: number;
  height?: number;
  maintainAspectRatio?: boolean;
}

export interface ImageCompressOptions extends ToolOptions {
  file: string;
  quality: number;
  format?: 'jpeg' | 'png' | 'webp';
}

export interface ImageCropOptions extends ToolOptions {
  file: string;
  left: number;
  top: number;
  width: number;
  height: number;
}

export interface WatermarkOptions extends ToolOptions {
  file: string;
  text?: string;
  imageUrl?: string;
  position: 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right' | 'center';
  opacity: number;
  size: number;
}

export interface QrCodeOptions extends ToolOptions {
  text: string;
  size?: number;
  color?: string;
  bgColor?: string;
  errorCorrectionLevel?: 'L' | 'M' | 'Q' | 'H';
  foregroundColor?: string;
  backgroundColor?: string;
}

export interface QRWifiOptions extends ToolOptions {
  ssid: string;
  password: string;
  encryption?: 'WPA' | 'WEP' | 'nopass';
  hidden?: boolean;
}

export interface AITextOptions extends ToolOptions {
  prompt: string;
  maxTokens?: number;
  temperature?: number;
  model?: string;
}

export interface AIImageOptions extends ToolOptions {
  prompt: string;
  size?: '256x256' | '512x512' | '1024x1024' | '1792x1024' | '1024x1792';
  quality?: 'standard' | 'hd';
  style?: 'vivid' | 'natural';
}

export interface AICodeOptions extends ToolOptions {
  description: string;
  language: string;
}

export interface PasswordGeneratorOptions extends ToolOptions {
  length?: number;
  includeUppercase?: boolean;
  includeNumbers?: boolean;
  includeSymbols?: boolean;
}

export interface EMICalculatorOptions extends ToolOptions {
  principal: number;
  rate: number;
  tenure: number;
}

export interface UnitConverterOptions extends ToolOptions {
  value: number;
  from: string;
  to: string;
  category: string;
}

// Payment Types
export interface PaymentSession {
  id: string;
  url: string;
}

export interface SubscriptionData {
  id: string;
  status: string;
  plan: string;
  currentPeriodEnd: Date;
  cancelAtPeriodEnd: boolean;
}

// API Response Types
export interface ApiResponse<T = any> {
  success: boolean;
  data?: T;
  message?: string;
  error?: string;
  details?: any;
}

export interface PaginatedResponse<T = any> extends ApiResponse<T> {
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

// Dashboard Types
export interface DashboardStats {
  totalFiles: number;
  totalPayments: number;
  filesByStatus: Record<string, number>;
}

export interface UserActivity {
  date: string;
  filesProcessed: number;
  creditsUsed: number;
}

// Cache Types
export interface CacheEntry<T> {
  data: T;
  expiresAt: number;
}

// Rate Limit Types
export interface RateLimitInfo {
  limit: number;
  remaining: number;
  reset: number;
}
