import multer from 'multer';
import path from 'path';
import { generateId, getMimeType } from '../utils/helpers';

const UPLOAD_DIR = process.env.UPLOAD_DIR 
  ? path.resolve(process.env.UPLOAD_DIR) 
  : path.join(process.cwd(), 'uploads');

// Configure storage
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, UPLOAD_DIR);
  },
  filename: (req, file, cb) => {
    const id = generateId();
    const ext = path.extname(file.originalname);
    cb(null, `${id}${ext}`);
  },
});

// File filter
const fileFilter = (allowedTypes: string[]) => {
  return (req: Express.Request, file: Express.Multer.File, cb: multer.FileFilterCallback) => {
    if (allowedTypes.length === 0 || allowedTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error(`Invalid file type. Allowed types: ${allowedTypes.join(', ')}`));
    }
  };
};

// Create multer instances for different file types
export const uploadPdf = multer({
  storage,
  fileFilter: fileFilter(['application/pdf']),
  limits: {
    fileSize: 100 * 1024 * 1024, // 100MB
    files: 10,
  },
});

export const uploadImage = multer({
  storage,
  fileFilter: fileFilter([
    'image/jpeg',
    'image/png',
    'image/gif',
    'image/webp',
    'image/svg+xml',
  ]),
  limits: {
    fileSize: 20 * 1024 * 1024, // 20MB
    files: 10,
  },
});

export const uploadDocument = multer({
  storage,
  fileFilter: fileFilter([
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/vnd.ms-powerpoint',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'text/plain',
    'text/csv',
  ]),
  limits: {
    fileSize: 50 * 1024 * 1024, // 50MB
    files: 5,
  },
});

export const uploadAny = multer({
  storage,
  limits: {
    fileSize: 100 * 1024 * 1024, // 100MB
    files: 10,
  },
});

// Memory storage for processing
const memoryStorage = multer.memoryStorage();

export const uploadPdfMemory = multer({
  storage: memoryStorage,
  fileFilter: fileFilter(['application/pdf']),
  limits: {
    fileSize: 100 * 1024 * 1024, // 100MB
    files: 10,
  },
});

export const uploadImageMemory = multer({
  storage: memoryStorage,
  fileFilter: fileFilter([
    'image/jpeg',
    'image/png',
    'image/gif',
    'image/webp',
  ]),
  limits: {
    fileSize: 20 * 1024 * 1024, // 20MB
    files: 10,
  },
});

export default {
  uploadPdf,
  uploadImage,
  uploadDocument,
  uploadAny,
  uploadPdfMemory,
  uploadImageMemory,
};
