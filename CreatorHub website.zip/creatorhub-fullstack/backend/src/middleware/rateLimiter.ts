import rateLimit from 'express-rate-limit';

// Create rate limiter with Redis store if available
export function createRateLimiter(
  windowMs: number = 15 * 60 * 1000, // 15 minutes
  max: number = 100, // limit each IP to 100 requests per windowMs
  message: string = 'Too many requests, please try again later'
) {
  return rateLimit({
    windowMs,
    max,
    message: {
      success: false,
      error: message,
      code: 'TOO_MANY_REQUESTS',
    },
    standardHeaders: true,
    legacyHeaders: false,
    keyGenerator: (req) => {
      return req.ip || req.headers['x-forwarded-for']?.toString() || 'unknown';
    },
    skip: (req) => {
      // Skip rate limiting for health checks
      return req.path === '/health';
    },
  });
}

// Specific rate limiters
export const authRateLimiter = createRateLimiter(
  15 * 60 * 1000, // 15 minutes
  5, // 5 attempts
  'Too many authentication attempts, please try again later'
);

export const apiRateLimiter = createRateLimiter(
  15 * 60 * 1000, // 15 minutes
  100, // 100 requests
  'API rate limit exceeded, please try again later'
);

export const uploadRateLimiter = createRateLimiter(
  60 * 60 * 1000, // 1 hour
  50, // 50 uploads
  'Upload rate limit exceeded, please try again later'
);

export const toolRateLimiter = createRateLimiter(
  60 * 60 * 1000, // 1 hour
  30, // 30 tool uses
  'Tool usage limit exceeded, please try again later'
);

// Custom rate limiter based on user plan
export function createPlanBasedRateLimiter() {
  return async (req: any, res: any, next: any) => {
    const user = req.user;
    
    if (!user) {
      // Anonymous users - strict limit
      const limiter = createRateLimiter(60 * 60 * 1000, 10);
      return limiter(req, res, next);
    }
    
    // Plan-based limits
    let maxRequests = 10;
    switch (user.plan) {
      case 'FREE':
        maxRequests = 50;
        break;
      case 'PRO':
        maxRequests = 200;
        break;
      case 'BUSINESS':
        maxRequests = 500;
        break;
    }
    
    const limiter = createRateLimiter(60 * 60 * 1000, maxRequests);
    return limiter(req, res, next);
  };
}

export default {
  createRateLimiter,
  authRateLimiter,
  apiRateLimiter,
  uploadRateLimiter,
  toolRateLimiter,
  createPlanBasedRateLimiter,
};
