import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('Starting database seed...');

  // Create admin user
  const adminPassword = await bcrypt.hash('admin123', 10);
  const admin = await prisma.user.upsert({
    where: { email: 'admin@creatorhub.com' },
    update: {},
    create: {
      email: 'admin@creatorhub.com',
      name: 'Admin User',
      password: adminPassword,
      plan: 'BUSINESS',
      credits: 10000,
    },
  });
  console.log('Created admin user:', admin.email);

  // Create demo user
  const demoPassword = await bcrypt.hash('demo123', 10);
  const demo = await prisma.user.upsert({
    where: { email: 'demo@creatorhub.com' },
    update: {},
    create: {
      email: 'demo@creatorhub.com',
      name: 'Demo User',
      password: demoPassword,
      plan: 'PRO',
      credits: 500,
    },
  });
  console.log('Created demo user:', demo.email);

  // Create free user
  const freePassword = await bcrypt.hash('free123', 10);
  const free = await prisma.user.upsert({
    where: { email: 'free@creatorhub.com' },
    update: {},
    create: {
      email: 'free@creatorhub.com',
      name: 'Free User',
      password: freePassword,
      plan: 'FREE',
      credits: 50,
    },
  });
  console.log('Created free user:', free.email);

  console.log('Database seed completed successfully!');
}

main()
  .catch((e) => {
    console.error('Error seeding database:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
