# CreatorHub Backend Deployment Guide

This guide will walk you through deploying the CreatorHub backend to various platforms.

## Table of Contents

1. [Railway Deployment (Recommended)](#railway-deployment)
2. [Render Deployment](#render-deployment)
3. [Heroku Deployment](#heroku-deployment)
4. [Manual VPS Deployment](#manual-vps-deployment)
5. [Docker Deployment](#docker-deployment)
6. [Troubleshooting](#troubleshooting)

---

## Railway Deployment (Recommended)

Railway is the easiest way to deploy this backend with automatic scaling and managed PostgreSQL.

### Step 1: Prepare Your Repository

1. Make sure all your code is committed:
```bash
git add .
git commit -m "Ready for Railway deployment"
git push origin main
```

2. Ensure your repository includes:
   - `railway.toml` - Railway configuration
   - `nixpacks.toml` - Build configuration
   - `Procfile` - Process configuration
   - `package.json` - Dependencies
   - `prisma/schema.prisma` - Database schema
   - `prisma/migrations/` - Database migrations

### Step 2: Create Railway Account

1. Go to [railway.app](https://railway.app)
2. Sign up with GitHub
3. Click "New Project"

### Step 3: Add PostgreSQL Database

1. In your Railway project, click "New"
2. Select "Database" → "Add PostgreSQL"
3. Wait for the database to provision
4. Click on the PostgreSQL service
5. Go to "Variables" tab
6. Copy the `DATABASE_URL` value

### Step 4: Deploy Your Code

1. Click "New" → "GitHub Repo"
2. Select your `creatorhub-backend` repository
3. Railway will automatically detect the configuration

### Step 5: Configure Environment Variables

1. Click on your backend service
2. Go to "Variables" tab
3. Add the following variables:

**Required:**
```
DATABASE_URL=<paste from PostgreSQL service>
JWT_SECRET=<generate a strong random string (64+ characters)>
JWT_REFRESH_SECRET=<generate another strong random string>
NODE_ENV=production
```

**Generate JWT secrets:**
```bash
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
```

**Optional (for full functionality):**
```
FRONTEND_URL=https://your-frontend-url.com

# Stripe (for payments)
STRIPE_SECRET_KEY=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...
STRIPE_PRICE_PRO=price_...
STRIPE_PRICE_BUSINESS=price_...

# OpenAI (for AI features)
OPENAI_API_KEY=sk-...

# AWS S3 (for file storage)
AWS_ACCESS_KEY_ID=...
AWS_SECRET_ACCESS_KEY=...
AWS_REGION=us-east-1
AWS_S3_BUCKET=...

# Redis (for caching)
REDIS_URL=redis://...

# Email
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=...
SMTP_PASS=...

# SSLCommerz (Bangladesh payments)
SSLCOMMERZ_STORE_ID=...
SSLCOMMERZ_STORE_PASSWD=...
SSLCOMMERZ_IS_SANDBOX=true
```

### Step 6: Deploy

1. Railway will automatically deploy when you add variables
2. Monitor the deployment logs
3. Once deployed, your API will be available at the provided URL

### Step 7: Run Database Migrations

1. Go to your backend service in Railway
2. Click on "Shell" tab
3. Run:
```bash
npx prisma migrate deploy
```

Or use Railway CLI:
```bash
railway login
railway link
railway run npx prisma migrate deploy
```

### Step 8: Verify Deployment

1. Visit `https://your-app-url.up.railway.app/health`
2. You should see:
```json
{
  "status": "healthy",
  "database": "connected",
  "timestamp": "2024-01-31T12:00:00.000Z",
  "uptime": 123.456,
  "version": "1.0.0"
}
```

---

## Render Deployment

### Step 1: Create Render Account

1. Go to [render.com](https://render.com)
2. Sign up with GitHub

### Step 2: Create PostgreSQL Database

1. Click "New" → "PostgreSQL"
2. Name it `creatorhub-db`
3. Wait for it to be created
4. Copy the "Internal Database URL"

### Step 3: Create Web Service

1. Click "New" → "Web Service"
2. Connect your GitHub repository
3. Configure:
   - **Name**: `creatorhub-backend`
   - **Environment**: `Node`
   - **Build Command**: `npm install && npx prisma generate && npm run build`
   - **Start Command**: `npm start`

### Step 4: Add Environment Variables

Add the same variables as Railway (see above), using the PostgreSQL URL from step 2.

### Step 5: Deploy

Click "Create Web Service" and wait for deployment.

---

## Heroku Deployment

### Step 1: Install Heroku CLI

```bash
npm install -g heroku
```

### Step 2: Login and Create App

```bash
heroku login
heroku create creatorhub-backend
```

### Step 3: Add PostgreSQL

```bash
heroku addons:create heroku-postgresql:mini
```

### Step 4: Set Environment Variables

```bash
heroku config:set NODE_ENV=production
heroku config:set JWT_SECRET=$(node -e "console.log(require('crypto').randomBytes(64).toString('hex'))")
heroku config:set JWT_REFRESH_SECRET=$(node -e "console.log(require('crypto').randomBytes(64).toString('hex'))")
```

### Step 5: Deploy

```bash
git push heroku main
```

### Step 6: Run Migrations

```bash
heroku run npx prisma migrate deploy
```

---

## Manual VPS Deployment

### Prerequisites

- Ubuntu 20.04+ server
- Node.js 18+ installed
- PostgreSQL installed
- Nginx (optional, for reverse proxy)
- PM2 (for process management)

### Step 1: Install Dependencies

```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# Install PM2
sudo npm install -g pm2

# Install PostgreSQL
sudo apt install postgresql postgresql-contrib -y
```

### Step 2: Set Up PostgreSQL

```bash
sudo -u postgres psql -c "CREATE DATABASE creatorhub;"
sudo -u postgres psql -c "CREATE USER creatorhub WITH PASSWORD 'your_password';"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE creatorhub TO creatorhub;"
```

### Step 3: Clone and Setup

```bash
cd /var/www
git clone <your-repo-url>
cd creatorhub-backend
npm install
npm run build
```

### Step 4: Environment Variables

```bash
cp .env.example .env
nano .env
# Edit with your configuration
```

### Step 5: Database Migrations

```bash
npx prisma migrate deploy
```

### Step 6: Start with PM2

```bash
pm2 start dist/server.js --name "creatorhub-backend"
pm2 save
pm2 startup
```

### Step 7: Nginx Configuration (Optional)

```bash
sudo nano /etc/nginx/sites-available/creatorhub
```

Add:
```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Enable:
```bash
sudo ln -s /etc/nginx/sites-available/creatorhub /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl restart nginx
```

---

## Docker Deployment

### Using Docker Compose

Create `docker-compose.yml`:

```yaml
version: '3.8'

services:
  app:
    build: .
    ports:
      - "5000:5000"
    environment:
      - DATABASE_URL=postgresql://postgres:postgres@db:5432/creatorhub?schema=public
      - JWT_SECRET=your-secret
      - JWT_REFRESH_SECRET=your-refresh-secret
      - NODE_ENV=production
    depends_on:
      - db
    volumes:
      - uploads:/app/uploads
      - outputs:/app/outputs

  db:
    image: postgres:15-alpine
    environment:
      - POSTGRES_USER=postgres
      - POSTGRES_PASSWORD=postgres
      - POSTGRES_DB=creatorhub
    volumes:
      - postgres_data:/var/lib/postgresql/data

volumes:
  postgres_data:
  uploads:
  outputs:
```

Create `Dockerfile`:

```dockerfile
FROM node:20-alpine

WORKDIR /app

# Install dependencies for native modules
RUN apk add --no-cache python3 make g++

# Copy package files
COPY package*.json ./
COPY prisma ./prisma/

# Install dependencies
RUN npm ci

# Copy source code
COPY . .

# Generate Prisma client
RUN npx prisma generate

# Build TypeScript
RUN npm run build

# Create directories
RUN mkdir -p uploads outputs

# Expose port
EXPOSE 5000

# Start command
CMD ["npm", "start"]
```

Run:
```bash
docker-compose up -d
```

---

## Troubleshooting

### Build Failures

**Error: `Cannot find module '@prisma/client'`**
- Solution: Run `npx prisma generate` before building

**Error: `TypeScript compilation failed`**
- Solution: Check `tsconfig.json` settings
- Run `npx tsc --noEmit` to check for errors

### Database Issues

**Error: `Database connection failed`**
- Verify `DATABASE_URL` is correct
- Check if PostgreSQL is running
- Ensure database exists

**Error: `Migration failed`**
- Run `npx prisma migrate reset` (WARNING: This deletes data)
- Or run `npx prisma migrate deploy` to apply pending migrations

### Runtime Issues

**Error: `PORT already in use`**
- Change the PORT environment variable
- Or kill the process using the port: `kill $(lsof -t -i:5000)`

**Error: `JWT verification failed`**
- Ensure `JWT_SECRET` is set and consistent
- Generate new secrets if needed

### Railway-Specific Issues

**Build succeeds but health check fails**
- Check that `/health` endpoint returns 200
- Verify `DATABASE_URL` is correctly set
- Check logs for startup errors

**Database connection timeout**
- Railway PostgreSQL may take time to start
- Increase health check timeout in `railway.toml`

### Getting Help

1. Check the logs: `railway logs` or platform-specific logging
2. Enable debug mode: Set `DEBUG=*` environment variable
3. Check health endpoint: `/health`
4. Review error messages carefully

---

## Post-Deployment Checklist

- [ ] Health check endpoint returns 200
- [ ] Database migrations applied successfully
- [ ] Environment variables configured correctly
- [ ] JWT secrets are strong and unique
- [ ] Frontend URL configured in CORS
- [ ] File upload directories are writable
- [ ] SSL/HTTPS enabled (for production)
- [ ] Monitoring/logging set up
- [ ] Backup strategy in place

---

## Next Steps

1. Set up monitoring (e.g., Sentry, LogRocket)
2. Configure CDN for static files (e.g., Cloudflare)
3. Set up automated backups
4. Configure CI/CD pipeline
5. Add load balancing for scaling
