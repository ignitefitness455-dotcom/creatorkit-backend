// User Types
export interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
  image?: string;
  plan: 'FREE' | 'PRO' | 'BUSINESS' | 'free' | 'pro' | 'enterprise';
  credits: number;
  createdAt: string;
  updatedAt: string;
}

// Tool Types
export type ToolCategory = 'pdf' | 'image' | 'ai' | 'utility' | 'social' | 'business';

export interface Tool {
  id: string;
  name: string;
  description: string;
  category: ToolCategory | string;
  icon: string;
  color?: string;
  creditCost: number;
  maxFiles?: number;
  maxFileSize?: number;
  allowedTypes?: string[];
  features?: string[];
  isPopular?: boolean;
  isNew?: boolean;
  isPremium?: boolean;
  plan?: 'FREE' | 'PRO' | 'BUSINESS';
  rating?: number;
  usageCount?: number;
}

// File Types
export interface ProcessedFile {
  id: string;
  originalName: string;
  fileName: string;
  fileUrl: string;
  fileSize: number;
  mimeType: string;
  toolId: string;
  status: 'processing' | 'completed' | 'failed';
  createdAt: string;
  expiresAt: string;
}

// Payment Types
export type PlanType = 'FREE' | 'PRO' | 'BUSINESS' | 'free' | 'pro' | 'enterprise';

export interface Plan {
  id: PlanType;
  name: string;
  description: string;
  price: number;
  priceId?: string;
  features: string[];
  creditsPerMonth: number;
  maxFileSize: number;
  isPopular?: boolean;
}

export interface Payment {
  id: string;
  amount: number;
  currency: string;
  status: 'pending' | 'completed' | 'failed';
  plan: PlanType;
  createdAt: string;
}

// API Response Types
export interface ApiResponse<T> {
  success: boolean;
  data: T;
  message?: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  pagination: {
    page: number;
    limit: number;
    total: number;
    totalPages: number;
  };
}

// Dashboard Types
export interface DashboardStats {
  totalFiles: number;
  creditsUsed: number;
  creditsRemaining: number;
  plan: PlanType;
}

export interface UserActivity {
  date: string;
  filesProcessed: number;
  creditsUsed: number;
}

// Tool Processing Types
export interface ToolResult {
  success: boolean;
  downloadUrl?: string;
  previewUrl?: string;
  aiResponse?: string;
  fileName?: string;
  fileSize?: number;
  message?: string;
}

// Auth Types
export interface LoginCredentials {
  email: string;
  password: string;
}

export interface RegisterCredentials {
  name: string;
  email: string;
  password: string;
}

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
}

// Filter Types
export interface ToolFilters {
  category?: ToolCategory;
  search?: string;
  sortBy?: 'name' | 'popular' | 'newest';
}
