import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Check, X, Sparkles, Zap, Crown, ArrowRight, Loader2,
  FileText, Image, Shield, Clock, Globe, CreditCard
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { useAuthStore } from '@/store/authStore';
import { toast } from 'sonner';

const plans = [
  {
    id: 'free',
    name: 'Free',
    description: 'Perfect for getting started',
    monthlyPrice: 0,
    yearlyPrice: 0,
    icon: Zap,
    color: 'from-gray-500 to-gray-600',
    features: [
      { text: '50 credits per month', included: true },
      { text: 'Access to all basic tools', included: true },
      { text: '10 MB max file size', included: true },
      { text: '5 files per batch', included: true },
      { text: 'Standard processing speed', included: true },
      { text: 'AI tools', included: false },
      { text: 'Priority support', included: false },
      { text: 'API access', included: false },
    ],
    cta: 'Get Started Free',
    popular: false,
  },
  {
    id: 'pro',
    name: 'Pro',
    description: 'Best for professionals',
    monthlyPrice: 9.99,
    yearlyPrice: 99.99,
    icon: Sparkles,
    color: 'from-blue-500 to-purple-600',
    features: [
      { text: '500 credits per month', included: true },
      { text: 'Access to all tools', included: true },
      { text: '50 MB max file size', included: true },
      { text: '20 files per batch', included: true },
      { text: 'Fast processing speed', included: true },
      { text: 'AI tools included', included: true },
      { text: 'Priority support', included: true },
      { text: 'API access', included: false },
    ],
    cta: 'Start Pro Trial',
    popular: true,
  },
  {
    id: 'enterprise',
    name: 'Enterprise',
    description: 'For teams and businesses',
    monthlyPrice: 29.99,
    yearlyPrice: 299.99,
    icon: Crown,
    color: 'from-amber-500 to-orange-600',
    features: [
      { text: 'Unlimited credits', included: true },
      { text: 'Access to all tools', included: true },
      { text: '100 MB max file size', included: true },
      { text: 'Unlimited files per batch', included: true },
      { text: 'Fastest processing speed', included: true },
      { text: 'AI tools included', included: true },
      { text: '24/7 Priority support', included: true },
      { text: 'Full API access', included: true },
    ],
    cta: 'Contact Sales',
    popular: false,
  },
];

const faqs = [
  {
    question: 'What are credits?',
    answer: 'Credits are our virtual currency used to process files. Each tool operation costs a certain number of credits based on complexity.',
  },
  {
    question: 'Can I upgrade or downgrade anytime?',
    answer: 'Yes! You can upgrade or downgrade your plan at any time. Changes take effect immediately, and we\'ll prorate any differences.',
  },
  {
    question: 'What happens if I run out of credits?',
    answer: 'You can purchase additional credit packs or upgrade to a higher plan. Free users can also wait for their monthly credit refresh.',
  },
  {
    question: 'Is there a free trial?',
    answer: 'Yes! All paid plans come with a 14-day free trial. No credit card required to start.',
  },
  {
    question: 'How secure is my data?',
    answer: 'All files are encrypted in transit and at rest. We automatically delete processed files after 24 hours. We never share your data with third parties.',
  },
];

export default function PricingPage() {
  const navigate = useNavigate();
  const { isAuthenticated, user } = useAuthStore();
  const [isYearly, setIsYearly] = useState(false);
  const [isLoading, setIsLoading] = useState<string | null>(null);

  const handleSelectPlan = async (planId: string) => {
    if (!isAuthenticated) {
      navigate('/register', { state: { from: '/pricing', plan: planId } });
      return;
    }

    if (planId === 'free') {
      toast.info('You are already on the Free plan!');
      return;
    }

    setIsLoading(planId);

    // Simulate checkout process
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    toast.success('Redirecting to checkout...');
    setIsLoading(null);
    
    // In production, redirect to Stripe checkout
    // window.location.href = checkoutUrl;
  };

  const getCurrentPlan = () => {
    return user?.plan || 'free';
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center space-x-2">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                CreatorHub
              </span>
            </Link>
            <div className="flex items-center space-x-4">
              {isAuthenticated ? (
                <Button variant="outline" onClick={() => navigate('/dashboard')}>
                  Dashboard
                </Button>
              ) : (
                <>
                  <Button variant="ghost" onClick={() => navigate('/login')}>
                    Sign In
                  </Button>
                  <Button onClick={() => navigate('/register')}>
                    Get Started
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Hero */}
        <div className="text-center mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 dark:text-white mb-4">
              Simple, Transparent Pricing
            </h1>
            <p className="text-lg text-gray-600 dark:text-gray-400 max-w-2xl mx-auto mb-8">
              Choose the plan that fits your needs. All plans include a 14-day free trial.
            </p>

            {/* Billing Toggle */}
            <div className="flex items-center justify-center space-x-4">
              <span className={`text-sm ${!isYearly ? 'text-gray-900 dark:text-white font-medium' : 'text-gray-500'}`}>
                Monthly
              </span>
              <Switch
                checked={isYearly}
                onCheckedChange={setIsYearly}
              />
              <span className={`text-sm ${isYearly ? 'text-gray-900 dark:text-white font-medium' : 'text-gray-500'}`}>
                Yearly
              </span>
              <Badge variant="secondary" className="ml-2 bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300">
                Save 20%
              </Badge>
            </div>
          </motion.div>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-20">
          {plans.map((plan, index) => {
            const Icon = plan.icon;
            const isCurrentPlan = getCurrentPlan() === plan.id;
            const price = isYearly ? plan.yearlyPrice : plan.monthlyPrice;

            return (
              <motion.div
                key={plan.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className={`h-full relative ${plan.popular ? 'border-blue-500 ring-2 ring-blue-500/20' : ''}`}>
                  {plan.popular && (
                    <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                      <Badge className="bg-blue-600 text-white">Most Popular</Badge>
                    </div>
                  )}

                  <CardHeader className="pb-8">
                    <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${plan.color} flex items-center justify-center mb-4`}>
                      <Icon className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="text-2xl font-bold text-gray-900 dark:text-white">{plan.name}</h3>
                    <p className="text-gray-500 dark:text-gray-400">{plan.description}</p>
                  </CardHeader>

                  <CardContent>
                    <div className="mb-6">
                      <div className="flex items-baseline">
                        <span className="text-4xl font-bold text-gray-900 dark:text-white">
                          ${price}
                        </span>
                        <span className="text-gray-500 ml-2">
                          /{isYearly ? 'year' : 'month'}
                        </span>
                      </div>
                      {isYearly && price > 0 && (
                        <p className="text-sm text-green-600 mt-1">
                          Save ${(plan.monthlyPrice * 12 - plan.yearlyPrice).toFixed(2)} per year
                        </p>
                      )}
                    </div>

                    <ul className="space-y-3 mb-8">
                      {plan.features.map((feature, i) => (
                        <li key={i} className="flex items-center space-x-3">
                          {feature.included ? (
                            <Check className="w-5 h-5 text-green-500 flex-shrink-0" />
                          ) : (
                            <X className="w-5 h-5 text-gray-300 flex-shrink-0" />
                          )}
                          <span className={feature.included ? 'text-gray-600 dark:text-gray-400' : 'text-gray-400'}>
                            {feature.text}
                          </span>
                        </li>
                      ))}
                    </ul>

                    <Button
                      onClick={() => handleSelectPlan(plan.id)}
                      disabled={isLoading === plan.id || isCurrentPlan}
                      className={`w-full ${
                        plan.popular
                          ? 'bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700'
                          : ''
                      }`}
                      variant={plan.popular ? 'default' : 'outline'}
                    >
                      {isLoading === plan.id ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Processing...
                        </>
                      ) : isCurrentPlan ? (
                        'Current Plan'
                      ) : (
                        <>
                          {plan.cta}
                          <ArrowRight className="w-4 h-4 ml-2" />
                        </>
                      )}
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* Features Comparison */}
        <div className="mb-20">
          <h2 className="text-3xl font-bold text-center text-gray-900 dark:text-white mb-12">
            Compare All Features
          </h2>

          <Card>
            <CardContent className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-gray-200 dark:border-gray-700">
                      <th className="text-left py-4 px-6 font-semibold text-gray-900 dark:text-white">Feature</th>
                      <th className="text-center py-4 px-6 font-semibold text-gray-900 dark:text-white">Free</th>
                      <th className="text-center py-4 px-6 font-semibold text-blue-600">Pro</th>
                      <th className="text-center py-4 px-6 font-semibold text-gray-900 dark:text-white">Enterprise</th>
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      { feature: 'Monthly Credits', free: '50', pro: '500', enterprise: 'Unlimited' },
                      { feature: 'Max File Size', free: '10 MB', pro: '50 MB', enterprise: '100 MB' },
                      { feature: 'Files per Batch', free: '5', pro: '20', enterprise: 'Unlimited' },
                      { feature: 'PDF Tools', free: true, pro: true, enterprise: true },
                      { feature: 'Image Tools', free: true, pro: true, enterprise: true },
                      { feature: 'AI Tools', free: false, pro: true, enterprise: true },
                      { feature: 'Utility Tools', free: true, pro: true, enterprise: true },
                      { feature: 'Processing Speed', free: 'Standard', pro: 'Fast', enterprise: 'Fastest' },
                      { feature: 'Priority Support', free: false, pro: true, enterprise: true },
                      { feature: 'API Access', free: false, pro: false, enterprise: true },
                      { feature: 'Custom Integrations', free: false, pro: false, enterprise: true },
                      { feature: 'Dedicated Account Manager', free: false, pro: false, enterprise: true },
                    ].map((row, index) => (
                      <tr key={index} className="border-b border-gray-100 dark:border-gray-800">
                        <td className="py-4 px-6 text-gray-600 dark:text-gray-400">{row.feature}</td>
                        <td className="py-4 px-6 text-center">
                          {typeof row.free === 'boolean' ? (
                            row.free ? <Check className="w-5 h-5 text-green-500 mx-auto" /> : <X className="w-5 h-5 text-gray-300 mx-auto" />
                          ) : (
                            <span className="text-gray-600 dark:text-gray-400">{row.free}</span>
                          )}
                        </td>
                        <td className="py-4 px-6 text-center bg-blue-50/50 dark:bg-blue-900/10">
                          {typeof row.pro === 'boolean' ? (
                            row.pro ? <Check className="w-5 h-5 text-green-500 mx-auto" /> : <X className="w-5 h-5 text-gray-300 mx-auto" />
                          ) : (
                            <span className="text-blue-600 font-medium">{row.pro}</span>
                          )}
                        </td>
                        <td className="py-4 px-6 text-center">
                          {typeof row.enterprise === 'boolean' ? (
                            row.enterprise ? <Check className="w-5 h-5 text-green-500 mx-auto" /> : <X className="w-5 h-5 text-gray-300 mx-auto" />
                          ) : (
                            <span className="text-gray-600 dark:text-gray-400">{row.enterprise}</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* FAQ */}
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl font-bold text-center text-gray-900 dark:text-white mb-12">
            Frequently Asked Questions
          </h2>

          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card>
                  <CardContent className="p-6">
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                      {faq.question}
                    </h3>
                    <p className="text-gray-600 dark:text-gray-400">
                      {faq.answer}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div className="text-center mt-16">
          <p className="text-gray-600 dark:text-gray-400 mb-4">
            Still have questions?
          </p>
          <Button variant="outline" onClick={() => toast.info('Contact form coming soon!')}>
            Contact Support
          </Button>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-300 py-12 mt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="flex items-center space-x-2 mb-4 md:mb-0">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <span className="text-lg font-bold text-white">CreatorHub</span>
            </div>
            <p className="text-gray-500 text-sm">
              © 2024 CreatorHub. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
