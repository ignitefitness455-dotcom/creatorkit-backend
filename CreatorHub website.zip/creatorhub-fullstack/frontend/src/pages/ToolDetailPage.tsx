import { useEffect, useState, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ArrowLeft, Upload, FileText, Image, File, Download, 
  CheckCircle, AlertCircle, Loader2, X, Settings, Zap,
  CreditCard, Clock, Shield, Sparkles, ChevronRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { useAuthStore } from '@/store/authStore';
import { useToolProcessor } from '@/hooks/useToolProcessor';
import { toolsApi } from '@/lib/api';
import { cn } from '@/lib/utils';
import type { Tool } from '@/types';

// Tool-specific option interfaces
interface PDFMergeOptions {
  pageOrder?: 'natural' | 'reverse' | 'alternate';
}

interface PDFSplitOptions {
  splitMethod: 'range' | 'every' | 'extract';
  range?: string;
  every?: number;
  pages?: string;
}

interface ImageResizeOptions {
  width: number;
  height: number;
  maintainAspectRatio: boolean;
}

interface ImageCompressOptions {
  quality: number;
  format: 'jpeg' | 'png' | 'webp';
}

interface QRCodeOptions {
  size: number;
  errorCorrectionLevel: 'L' | 'M' | 'Q' | 'H';
  foregroundColor: string;
  backgroundColor: string;
}

interface AIOptions {
  model: string;
  temperature: number;
  maxTokens: number;
}

export default function ToolDetailPage() {
  const { toolId } = useParams<{ toolId: string }>();
  const navigate = useNavigate();
  const { isAuthenticated, user } = useAuthStore();
  const { processTool, isProcessing, progress, error: processError, result, reset } = useToolProcessor();

  const [tool, setTool] = useState<Tool | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [files, setFiles] = useState<File[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [showOptions, setShowOptions] = useState(false);
  const [showUpgradeDialog, setShowUpgradeDialog] = useState(false);
  const [activeTab, setActiveTab] = useState<'upload' | 'options' | 'result'>('upload');

  // Tool-specific options
  const [pdfMergeOptions, setPdfMergeOptions] = useState<PDFMergeOptions>({ pageOrder: 'natural' });
  const [pdfSplitOptions, setPdfSplitOptions] = useState<PDFSplitOptions>({ splitMethod: 'range', range: '1-5' });
  const [imageResizeOptions, setImageResizeOptions] = useState<ImageResizeOptions>({ 
    width: 800, height: 600, maintainAspectRatio: true 
  });
  const [imageCompressOptions, setImageCompressOptions] = useState<ImageCompressOptions>({ 
    quality: 80, format: 'jpeg' 
  });
  const [qrCodeOptions, setQrCodeOptions] = useState<QRCodeOptions>({
    size: 300,
    errorCorrectionLevel: 'M',
    foregroundColor: '#000000',
    backgroundColor: '#FFFFFF'
  });
  const [aiOptions, setAiOptions] = useState<AIOptions>({
    model: 'gpt-3.5-turbo',
    temperature: 0.7,
    maxTokens: 1000
  });
  const [aiPrompt, setAiPrompt] = useState('');

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/login', { state: { from: `/tools/${toolId}` } });
      return;
    }

    const fetchTool = async () => {
      try {
        setLoading(true);
        const response = await toolsApi.getById(toolId!);
        setTool(response.data.tool);
      } catch (err: any) {
        setError(err.response?.data?.message || 'Failed to load tool');
      } finally {
        setLoading(false);
      }
    };

    fetchTool();
  }, [toolId, isAuthenticated, navigate]);

  // Handle file drop
  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    
    const droppedFiles = Array.from(e.dataTransfer.files);
    handleFiles(droppedFiles);
  }, [tool]);

  const handleFileInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(e.target.files || []);
    handleFiles(selectedFiles);
  }, [tool]);

  const handleFiles = (newFiles: File[]) => {
    if (!tool) return;

    // Validate file types
    const validFiles = newFiles.filter(file => {
      if (tool.category === 'pdf') return file.type === 'application/pdf';
      if (tool.category === 'image') return file.type.startsWith('image/');
      return true;
    });

    // Check file count limits
    const maxFiles = tool.maxFiles || 1;
    if (files.length + validFiles.length > maxFiles) {
      setError(`Maximum ${maxFiles} file(s) allowed`);
      return;
    }

    setFiles(prev => [...prev, ...validFiles]);
    setError(null);
  };

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const getToolOptions = () => {
    switch (tool?.id) {
      case 'pdf-merge':
        return pdfMergeOptions;
      case 'pdf-split':
        return pdfSplitOptions;
      case 'image-resize':
        return imageResizeOptions;
      case 'image-compress':
      case 'image-convert':
        return imageCompressOptions;
      case 'qr-generator':
        return qrCodeOptions;
      case 'ai-text':
      case 'ai-image':
      case 'ai-code':
        return { ...aiOptions, prompt: aiPrompt };
      default:
        return {};
    }
  };

  const handleProcess = async () => {
    if (!tool) return;

    // Check credits
    const userCredits = user?.credits || 0;
    if (userCredits < tool.creditCost) {
      setShowUpgradeDialog(true);
      return;
    }

    const options = getToolOptions();
    await processTool(tool.id, files, options);
    setActiveTab('result');
  };

  const handleDownload = () => {
    if (result?.downloadUrl) {
      window.open(result.downloadUrl, '_blank');
    }
  };

  const getFileIcon = (file: File) => {
    if (file.type.startsWith('image/')) return <Image className="w-5 h-5" />;
    if (file.type === 'application/pdf') return <FileText className="w-5 h-5" />;
    return <File className="w-5 h-5" />;
  };

  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin mx-auto text-blue-600 mb-4" />
          <p className="text-gray-600 dark:text-gray-400">Loading tool...</p>
        </div>
      </div>
    );
  }

  if (error || !tool) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <AlertCircle className="w-12 h-12 mx-auto text-red-500 mb-4" />
          <p className="text-gray-600 dark:text-gray-400 mb-4">{error || 'Tool not found'}</p>
          <Button onClick={() => navigate('/tools')}>
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Tools
          </Button>
        </div>
      </div>
    );
  }

  const renderOptionsPanel = () => {
    switch (tool.id) {
      case 'pdf-merge':
        return (
          <div className="space-y-4">
            <div>
              <Label>Page Order</Label>
              <Select 
                value={pdfMergeOptions.pageOrder} 
                onValueChange={(v) => setPdfMergeOptions({ pageOrder: v as any })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="natural">Natural Order</SelectItem>
                  <SelectItem value="reverse">Reverse Order</SelectItem>
                  <SelectItem value="alternate">Alternate Pages</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        );

      case 'pdf-split':
        return (
          <div className="space-y-4">
            <div>
              <Label>Split Method</Label>
              <Select 
                value={pdfSplitOptions.splitMethod} 
                onValueChange={(v) => setPdfSplitOptions({ ...pdfSplitOptions, splitMethod: v as any })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="range">By Page Range</SelectItem>
                  <SelectItem value="every">Every N Pages</SelectItem>
                  <SelectItem value="extract">Extract Specific Pages</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {pdfSplitOptions.splitMethod === 'range' && (
              <div>
                <Label>Page Range (e.g., 1-5, 8-10)</Label>
                <Input 
                  value={pdfSplitOptions.range} 
                  onChange={(e) => setPdfSplitOptions({ ...pdfSplitOptions, range: e.target.value })}
                  placeholder="1-5"
                />
              </div>
            )}
            {pdfSplitOptions.splitMethod === 'every' && (
              <div>
                <Label>Split Every N Pages</Label>
                <Input 
                  type="number"
                  value={pdfSplitOptions.every || 1} 
                  onChange={(e) => setPdfSplitOptions({ ...pdfSplitOptions, every: parseInt(e.target.value) })}
                  min={1}
                />
              </div>
            )}
            {pdfSplitOptions.splitMethod === 'extract' && (
              <div>
                <Label>Pages to Extract (e.g., 1,3,5-7)</Label>
                <Input 
                  value={pdfSplitOptions.pages} 
                  onChange={(e) => setPdfSplitOptions({ ...pdfSplitOptions, pages: e.target.value })}
                  placeholder="1,3,5-7"
                />
              </div>
            )}
          </div>
        );

      case 'image-resize':
        return (
          <div className="space-y-4">
            <div>
              <Label>Width (px)</Label>
              <Input 
                type="number"
                value={imageResizeOptions.width} 
                onChange={(e) => setImageResizeOptions({ ...imageResizeOptions, width: parseInt(e.target.value) })}
              />
            </div>
            <div>
              <Label>Height (px)</Label>
              <Input 
                type="number"
                value={imageResizeOptions.height} 
                onChange={(e) => setImageResizeOptions({ ...imageResizeOptions, height: parseInt(e.target.value) })}
              />
            </div>
            <div className="flex items-center space-x-2">
              <Switch 
                checked={imageResizeOptions.maintainAspectRatio}
                onCheckedChange={(v) => setImageResizeOptions({ ...imageResizeOptions, maintainAspectRatio: v })}
              />
              <Label>Maintain Aspect Ratio</Label>
            </div>
          </div>
        );

      case 'image-compress':
      case 'image-convert':
        return (
          <div className="space-y-4">
            <div>
              <Label>Quality: {imageCompressOptions.quality}%</Label>
              <Slider 
                value={[imageCompressOptions.quality]} 
                onValueChange={([v]) => setImageCompressOptions({ ...imageCompressOptions, quality: v })}
                min={1}
                max={100}
              />
            </div>
            <div>
              <Label>Output Format</Label>
              <Select 
                value={imageCompressOptions.format} 
                onValueChange={(v) => setImageCompressOptions({ ...imageCompressOptions, format: v as any })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="jpeg">JPEG</SelectItem>
                  <SelectItem value="png">PNG</SelectItem>
                  <SelectItem value="webp">WebP</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        );

      case 'qr-generator':
        return (
          <div className="space-y-4">
            <div>
              <Label>Size: {qrCodeOptions.size}px</Label>
              <Slider 
                value={[qrCodeOptions.size]} 
                onValueChange={([v]) => setQrCodeOptions({ ...qrCodeOptions, size: v })}
                min={100}
                max={1000}
                step={50}
              />
            </div>
            <div>
              <Label>Error Correction</Label>
              <Select 
                value={qrCodeOptions.errorCorrectionLevel} 
                onValueChange={(v) => setQrCodeOptions({ ...qrCodeOptions, errorCorrectionLevel: v as any })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="L">Low (7%)</SelectItem>
                  <SelectItem value="M">Medium (15%)</SelectItem>
                  <SelectItem value="Q">Quartile (25%)</SelectItem>
                  <SelectItem value="H">High (30%)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Foreground Color</Label>
                <Input 
                  type="color"
                  value={qrCodeOptions.foregroundColor} 
                  onChange={(e) => setQrCodeOptions({ ...qrCodeOptions, foregroundColor: e.target.value })}
                />
              </div>
              <div>
                <Label>Background Color</Label>
                <Input 
                  type="color"
                  value={qrCodeOptions.backgroundColor} 
                  onChange={(e) => setQrCodeOptions({ ...qrCodeOptions, backgroundColor: e.target.value })}
                />
              </div>
            </div>
          </div>
        );

      case 'ai-text':
      case 'ai-code':
        return (
          <div className="space-y-4">
            <div>
              <Label>Prompt</Label>
              <textarea
                value={aiPrompt}
                onChange={(e) => setAiPrompt(e.target.value)}
                placeholder="Enter your prompt here..."
                className="w-full min-h-[120px] p-3 rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800"
              />
            </div>
            <div>
              <Label>Model</Label>
              <Select 
                value={aiOptions.model} 
                onValueChange={(v) => setAiOptions({ ...aiOptions, model: v })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="gpt-3.5-turbo">GPT-3.5 Turbo</SelectItem>
                  <SelectItem value="gpt-4">GPT-4</SelectItem>
                  <SelectItem value="gpt-4-turbo">GPT-4 Turbo</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Temperature: {aiOptions.temperature}</Label>
              <Slider 
                value={[aiOptions.temperature * 100]} 
                onValueChange={([v]) => setAiOptions({ ...aiOptions, temperature: v / 100 })}
                min={0}
                max={100}
              />
            </div>
            <div>
              <Label>Max Tokens: {aiOptions.maxTokens}</Label>
              <Slider 
                value={[aiOptions.maxTokens]} 
                onValueChange={([v]) => setAiOptions({ ...aiOptions, maxTokens: v })}
                min={100}
                max={4000}
                step={100}
              />
            </div>
          </div>
        );

      case 'ai-image':
        return (
          <div className="space-y-4">
            <div>
              <Label>Image Description</Label>
              <textarea
                value={aiPrompt}
                onChange={(e) => setAiPrompt(e.target.value)}
                placeholder="Describe the image you want to generate..."
                className="w-full min-h-[120px] p-3 rounded-md border border-gray-300 dark:border-gray-600 bg-white dark:bg-gray-800"
              />
            </div>
          </div>
        );

      default:
        return (
          <div className="text-center py-8 text-gray-500">
            <Settings className="w-12 h-12 mx-auto mb-4 opacity-50" />
            <p>No additional options for this tool</p>
          </div>
        );
    }
  };

  const needsFiles = !['ai-text', 'ai-image', 'ai-code', 'qr-generator'].includes(tool.id);
  const needsOptions = ['pdf-merge', 'pdf-split', 'image-resize', 'image-compress', 'image-convert', 'qr-generator', 'ai-text', 'ai-image', 'ai-code'].includes(tool.id);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="icon" onClick={() => navigate('/tools')}>
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white">
                  {tool.category === 'pdf' && <FileText className="w-5 h-5" />}
                  {tool.category === 'image' && <Image className="w-5 h-5" />}
                  {tool.category === 'ai' && <Sparkles className="w-5 h-5" />}
                  {tool.category === 'utility' && <Zap className="w-5 h-5" />}
                </div>
                <div>
                  <h1 className="text-xl font-bold text-gray-900 dark:text-white">{tool.name}</h1>
                  <p className="text-sm text-gray-500 dark:text-gray-400">{tool.category}</p>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Badge variant="secondary" className="flex items-center space-x-1">
                <CreditCard className="w-3 h-3" />
                <span>{tool.creditCost} credits</span>
              </Badge>
              <div className="text-sm text-gray-600 dark:text-gray-400">
                Your credits: <span className="font-semibold text-blue-600">{user?.credits || 0}</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Processing Area */}
          <div className="lg:col-span-2 space-y-6">
            {/* Tabs */}
            <div className="flex space-x-1 bg-gray-100 dark:bg-gray-800 p-1 rounded-lg">
              {needsFiles && (
                <button
                  onClick={() => setActiveTab('upload')}
                  className={cn(
                    "flex-1 py-2 px-4 rounded-md text-sm font-medium transition-all",
                    activeTab === 'upload' 
                      ? "bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm" 
                      : "text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white"
                  )}
                >
                  <Upload className="w-4 h-4 inline mr-2" />
                  Upload Files
                </button>
              )}
              {needsOptions && (
                <button
                  onClick={() => setActiveTab('options')}
                  className={cn(
                    "flex-1 py-2 px-4 rounded-md text-sm font-medium transition-all",
                    activeTab === 'options' 
                      ? "bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm" 
                      : "text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white"
                  )}
                >
                  <Settings className="w-4 h-4 inline mr-2" />
                  Options
                </button>
              )}
              <button
                onClick={() => setActiveTab('result')}
                className={cn(
                  "flex-1 py-2 px-4 rounded-md text-sm font-medium transition-all",
                  activeTab === 'result' 
                    ? "bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm" 
                    : "text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white"
                )}
              >
                <CheckCircle className="w-4 h-4 inline mr-2" />
                Result
              </button>
            </div>

            {/* Tab Content */}
            <AnimatePresence mode="wait">
              {activeTab === 'upload' && needsFiles && (
                <motion.div
                  key="upload"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                >
                  <Card>
                    <CardContent className="p-8">
                      {/* Drop Zone */}
                      <div
                        onDragOver={handleDragOver}
                        onDragLeave={handleDragLeave}
                        onDrop={handleDrop}
                        className={cn(
                          "border-2 border-dashed rounded-xl p-12 text-center transition-all cursor-pointer",
                          isDragging 
                            ? "border-blue-500 bg-blue-50 dark:bg-blue-900/20" 
                            : "border-gray-300 dark:border-gray-600 hover:border-gray-400 dark:hover:border-gray-500"
                        )}
                      >
                        <input
                          type="file"
                          multiple={tool.maxFiles && tool.maxFiles > 1}
                          accept={tool.category === 'pdf' ? '.pdf' : tool.category === 'image' ? 'image/*' : '*/*'}
                          onChange={handleFileInput}
                          className="hidden"
                          id="file-input"
                        />
                        <label htmlFor="file-input" className="cursor-pointer">
                          <Upload className={cn(
                            "w-16 h-16 mx-auto mb-4 transition-colors",
                            isDragging ? "text-blue-500" : "text-gray-400"
                          )} />
                          <p className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                            {isDragging ? 'Drop files here' : 'Drag & drop files here'}
                          </p>
                          <p className="text-sm text-gray-500 dark:text-gray-400 mb-4">
                            or click to browse
                          </p>
                          <p className="text-xs text-gray-400 dark:text-gray-500">
                            {tool.category === 'pdf' && 'Supports: PDF files'}
                            {tool.category === 'image' && 'Supports: JPG, PNG, WebP, GIF'}
                            {tool.category === 'utility' && 'Supports: Various file types'}
                          </p>
                        </label>
                      </div>

                      {/* File List */}
                      {files.length > 0 && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: 'auto' }}
                          className="mt-6 space-y-2"
                        >
                          <h4 className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-3">
                            Selected Files ({files.length})
                          </h4>
                          {files.map((file, index) => (
                            <motion.div
                              key={index}
                              initial={{ opacity: 0, x: -20 }}
                              animate={{ opacity: 1, x: 0 }}
                              exit={{ opacity: 0, x: 20 }}
                              className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-800 rounded-lg"
                            >
                              <div className="flex items-center space-x-3">
                                <div className="w-10 h-10 rounded-lg bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-blue-600">
                                  {getFileIcon(file)}
                                </div>
                                <div>
                                  <p className="text-sm font-medium text-gray-900 dark:text-white truncate max-w-[200px] sm:max-w-[300px]">
                                    {file.name}
                                  </p>
                                  <p className="text-xs text-gray-500">{formatFileSize(file.size)}</p>
                                </div>
                              </div>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => removeFile(index)}
                                className="text-gray-400 hover:text-red-500"
                              >
                                <X className="w-4 h-4" />
                              </Button>
                            </motion.div>
                          ))}
                        </motion.div>
                      )}

                      {/* Error */}
                      {error && (
                        <Alert variant="destructive" className="mt-4">
                          <AlertCircle className="w-4 h-4" />
                          <AlertDescription>{error}</AlertDescription>
                        </Alert>
                      )}
                    </CardContent>
                  </Card>
                </motion.div>
              )}

              {activeTab === 'options' && needsOptions && (
                <motion.div
                  key="options"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                >
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Settings className="w-5 h-5" />
                        <span>Tool Options</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      {renderOptionsPanel()}
                    </CardContent>
                  </Card>
                </motion.div>
              )}

              {activeTab === 'result' && (
                <motion.div
                  key="result"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                >
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <CheckCircle className="w-5 h-5" />
                        <span>Processing Result</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      {isProcessing ? (
                        <div className="text-center py-12">
                          <Loader2 className="w-16 h-16 animate-spin mx-auto text-blue-600 mb-4" />
                          <p className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                            Processing your files...
                          </p>
                          <p className="text-sm text-gray-500 dark:text-gray-400 mb-6">
                            This may take a few moments
                          </p>
                          <div className="max-w-md mx-auto">
                            <Progress value={progress} className="h-2" />
                            <p className="text-sm text-gray-500 mt-2">{progress}%</p>
                          </div>
                        </div>
                      ) : result ? (
                        <div className="text-center py-8">
                          <div className="w-20 h-20 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center mx-auto mb-6">
                            <CheckCircle className="w-10 h-10 text-green-600" />
                          </div>
                          <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                            Processing Complete!
                          </h3>
                          <p className="text-gray-600 dark:text-gray-400 mb-6">
                            Your files have been processed successfully
                          </p>
                          
                          {result.previewUrl && (
                            <div className="mb-6">
                              <img 
                                src={result.previewUrl} 
                                alt="Preview" 
                                className="max-w-full max-h-64 mx-auto rounded-lg shadow-lg"
                              />
                            </div>
                          )}

                          {result.aiResponse && (
                            <div className="mb-6 text-left">
                              <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
                                <pre className="whitespace-pre-wrap text-sm text-gray-700 dark:text-gray-300">
                                  {result.aiResponse}
                                </pre>
                              </div>
                            </div>
                          )}
                          
                          <div className="flex flex-col sm:flex-row gap-4 justify-center">
                            {result.downloadUrl && (
                              <Button onClick={handleDownload} size="lg" className="w-full sm:w-auto">
                                <Download className="w-5 h-5 mr-2" />
                                Download Result
                              </Button>
                            )}
                            <Button 
                              variant="outline" 
                              onClick={() => {
                                reset();
                                setFiles([]);
                                setActiveTab('upload');
                              }}
                              size="lg"
                              className="w-full sm:w-auto"
                            >
                              Process More Files
                            </Button>
                          </div>
                        </div>
                      ) : (
                        <div className="text-center py-12">
                          <div className="w-20 h-20 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center mx-auto mb-6">
                            <Clock className="w-10 h-10 text-gray-400" />
                          </div>
                          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                            No Results Yet
                          </h3>
                          <p className="text-gray-500 dark:text-gray-400 mb-6">
                            Upload files and click Process to see results here
                          </p>
                          <Button onClick={() => setActiveTab('upload')}>
                            Go to Upload
                          </Button>
                        </div>
                      )}

                      {processError && (
                        <Alert variant="destructive" className="mt-4">
                          <AlertCircle className="w-4 h-4" />
                          <AlertDescription>{processError}</AlertDescription>
                        </Alert>
                      )}
                    </CardContent>
                  </Card>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Process Button */}
            {!isProcessing && !result && activeTab !== 'result' && (
              <div className="flex justify-center">
                <Button
                  onClick={handleProcess}
                  disabled={needsFiles && files.length === 0}
                  size="lg"
                  className="w-full sm:w-auto min-w-[200px]"
                >
                  <Zap className="w-5 h-5 mr-2" />
                  Process {needsFiles && files.length > 0 && `(${files.length} file${files.length > 1 ? 's' : ''})`}
                </Button>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Tool Info */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">About This Tool</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {tool.description}
                </p>
                <Separator />
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500 dark:text-gray-400">Category</span>
                    <Badge variant="secondary">{tool.category}</Badge>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500 dark:text-gray-400">Credit Cost</span>
                    <span className="font-medium">{tool.creditCost} credits</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500 dark:text-gray-400">Max Files</span>
                    <span className="font-medium">{tool.maxFiles || 1}</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-500 dark:text-gray-400">Max File Size</span>
                    <span className="font-medium">{tool.maxFileSize || 50} MB</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Features */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Features</CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {tool.features?.map((feature, index) => (
                    <li key={index} className="flex items-start space-x-2 text-sm">
                      <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-600 dark:text-gray-400">{feature}</span>
                    </li>
                  )) || (
                    <>
                      <li className="flex items-start space-x-2 text-sm">
                        <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                        <span className="text-gray-600 dark:text-gray-400">Fast processing</span>
                      </li>
                      <li className="flex items-start space-x-2 text-sm">
                        <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                        <span className="text-gray-600 dark:text-gray-400">Secure file handling</span>
                      </li>
                      <li className="flex items-start space-x-2 text-sm">
                        <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                        <span className="text-gray-600 dark:text-gray-400">High quality output</span>
                      </li>
                    </>
                  )}
                </ul>
              </CardContent>
            </Card>

            {/* Security */}
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                    <Shield className="w-5 h-5 text-green-600" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-900 dark:text-white">Secure Processing</p>
                    <p className="text-xs text-gray-500">Files are encrypted and auto-deleted after 24 hours</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Need More Credits */}
            {(user?.credits || 0) < tool.creditCost && (
              <Card className="border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-900/20">
                <CardContent className="p-4">
                  <div className="flex items-start space-x-3">
                    <AlertCircle className="w-5 h-5 text-amber-600 mt-0.5" />
                    <div>
                      <p className="text-sm font-medium text-amber-800 dark:text-amber-200">
                        Low Credits
                      </p>
                      <p className="text-xs text-amber-700 dark:text-amber-300 mt-1">
                        You need {tool.creditCost} credits but only have {user?.credits || 0}
                      </p>
                      <Button 
                        variant="link" 
                        className="p-0 h-auto text-xs text-amber-600"
                        onClick={() => navigate('/pricing')}
                      >
                        Upgrade now <ChevronRight className="w-3 h-3 ml-1" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>

      {/* Upgrade Dialog */}
      <Dialog open={showUpgradeDialog} onOpenChange={setShowUpgradeDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Insufficient Credits</DialogTitle>
            <DialogDescription>
              You need {tool.creditCost} credits to use this tool, but you only have {user?.credits || 0}.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <div>
                <p className="font-medium">Current Balance</p>
                <p className="text-sm text-gray-500">{user?.credits || 0} credits</p>
              </div>
              <div className="text-right">
                <p className="font-medium">Required</p>
                <p className="text-sm text-gray-500">{tool.creditCost} credits</p>
              </div>
            </div>
          </div>
          <div className="flex space-x-3">
            <Button variant="outline" onClick={() => setShowUpgradeDialog(false)} className="flex-1">
              Cancel
            </Button>
            <Button onClick={() => navigate('/pricing')} className="flex-1">
              <CreditCard className="w-4 h-4 mr-2" />
              Upgrade Plan
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
