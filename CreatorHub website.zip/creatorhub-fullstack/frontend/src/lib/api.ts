import axios, { AxiosError, AxiosInstance, AxiosRequestConfig } from 'axios';

const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

// Create axios instance
const api: AxiosInstance = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 60000, // 60 seconds for file uploads
});

// Request interceptor - add auth token
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('accessToken');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor - handle errors
api.interceptors.response.use(
  (response) => response,
  async (error: AxiosError) => {
    const originalRequest = error.config as AxiosRequestConfig & { _retry?: boolean };
    
    // Handle token expiration
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
      
      try {
        const refreshToken = localStorage.getItem('refreshToken');
        if (refreshToken) {
          const response = await axios.post(`${API_URL}/auth/refresh`, {
            refreshToken,
          });
          
          const { accessToken } = response.data;
          localStorage.setItem('accessToken', accessToken);
          
          // Retry original request
          if (originalRequest.headers) {
            originalRequest.headers.Authorization = `Bearer ${accessToken}`;
          }
          return api(originalRequest);
        }
      } catch (refreshError) {
        // Refresh failed, logout user
        localStorage.removeItem('accessToken');
        localStorage.removeItem('refreshToken');
        window.location.href = '/login';
      }
    }
    
    return Promise.reject(error);
  }
);

// Auth API
export const authApi = {
  register: (data: { email: string; password: string; name?: string }) =>
    api.post('/auth/register', data),
  
  login: (data: { email: string; password: string }) =>
    api.post('/auth/login', data),
  
  logout: () => api.post('/auth/logout'),
  
  refresh: (refreshToken: string) =>
    api.post('/auth/refresh', { refreshToken }),
  
  me: () => api.get('/auth/me'),
  
  updateProfile: (data: { name?: string; image?: string }) =>
    api.patch('/auth/profile', data),
  
  changePassword: (data: { currentPassword: string; newPassword: string }) =>
    api.post('/auth/change-password', data),
};

// Tools API
export const toolsApi = {
  getAll: (params?: { category?: string; search?: string }) =>
    api.get('/tools', { params }),
  
  getById: (id: string) => api.get(`/tools/${id}`),
  
  getCategories: () => api.get('/tools/categories'),
  
  // PDF Tools
  pdfMerge: (files: File[]) => {
    const formData = new FormData();
    files.forEach(file => formData.append('files', file));
    return api.post('/tools/pdf-merge', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },
  
  pdfSplit: (file: File, options: { pages?: number[]; mode: 'extract' | 'split' }) => {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('mode', options.mode);
    if (options.pages) {
      formData.append('pages', JSON.stringify(options.pages));
    }
    return api.post('/tools/pdf-split', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },
  
  pdfCompress: (file: File, quality: 'low' | 'medium' | 'high') => {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('quality', quality);
    return api.post('/tools/pdf-compress', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },
  
  pdfRotate: (file: File, angle: 90 | 180 | 270, pages?: number[]) => {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('angle', angle.toString());
    if (pages) {
      formData.append('pages', JSON.stringify(pages));
    }
    return api.post('/tools/pdf-rotate', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },
  
  // Image Tools
  imageCompress: (file: File, quality: number, format?: string) => {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('quality', quality.toString());
    if (format) formData.append('format', format);
    return api.post('/tools/image-compress', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },
  
  imageConvert: (file: File, format: 'jpeg' | 'png' | 'webp' | 'gif' | 'avif') => {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('format', format);
    return api.post('/tools/image-convert', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },
  
  imageResize: (file: File, options: { width?: number; height?: number; maintainAspectRatio: boolean }) => {
    const formData = new FormData();
    formData.append('file', file);
    if (options.width) formData.append('width', options.width.toString());
    if (options.height) formData.append('height', options.height.toString());
    formData.append('maintainAspectRatio', options.maintainAspectRatio.toString());
    return api.post('/tools/image-resize', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },
  
  imageCrop: (file: File, crop: { left: number; top: number; width: number; height: number }) => {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('left', crop.left.toString());
    formData.append('top', crop.top.toString());
    formData.append('width', crop.width.toString());
    formData.append('height', crop.height.toString());
    return api.post('/tools/image-crop', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },
  
  imageWatermark: (file: File, options: { text: string; position: string; opacity: number; size: number }) => {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('text', options.text);
    formData.append('position', options.position);
    formData.append('opacity', options.opacity.toString());
    formData.append('size', options.size.toString());
    return api.post('/tools/image-watermark', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
  },
  
  // QR Code
  qrGenerate: (text: string, options?: { size?: number; color?: string; bgColor?: string }) =>
    api.post('/tools/qr-generator', { text, ...options }),
  
  qrWifi: (data: { ssid: string; password: string; encryption?: string; hidden?: boolean }) =>
    api.post('/tools/qr-wifi', data),
  
  // AI Tools
  aiText: (prompt: string, options?: { maxTokens?: number; temperature?: number }) =>
    api.post('/tools/ai-text', { prompt, ...options }),
  
  aiImage: (prompt: string, options?: { size?: string; quality?: string; style?: string }) =>
    api.post('/tools/ai-image', { prompt, ...options }),
  
  aiCode: (description: string, language: string) =>
    api.post('/tools/ai-code', { description, language }),
  
  aiCaption: (topic: string, platform: string, tone?: string) =>
    api.post('/tools/caption-writer', { topic, platform, tone }),
  
  aiHashtags: (topic: string, count?: number) =>
    api.post('/tools/hashtag-generator', { topic, count }),
  
  aiBio: (data: { name: string; profession: string; interests?: string[]; platform: string }) =>
    api.post('/tools/bio-generator', data),
  
  aiTranslate: (text: string, targetLanguage: string, sourceLanguage?: string) =>
    api.post('/tools/ai-translate', { text, targetLanguage, sourceLanguage }),
  
  aiSummarize: (text: string, maxLength?: number) =>
    api.post('/tools/ai-summarize', { text, maxLength }),
  
  // Business Tools
  passwordGenerator: (options: { length?: number; includeUppercase?: boolean; includeNumbers?: boolean; includeSymbols?: boolean }) =>
    api.post('/tools/password-generator', options),
  
  emiCalculator: (data: { principal: number; rate: number; tenure: number }) =>
    api.post('/tools/emi-calculator', data),
  
  unitConverter: (data: { value: number; from: string; to: string; category: string }) =>
    api.post('/tools/unit-converter', data),
};

// User API
export const userApi = {
  getDashboard: () => api.get('/user/dashboard'),
  
  getFiles: (params?: { page?: number; limit?: number; status?: string }) =>
    api.get('/user/files', { params }),
  
  getPayments: (params?: { page?: number; limit?: number }) =>
    api.get('/user/payments', { params }),
  
  getStats: () => api.get('/user/stats'),
  
  updateProfile: (data: { name?: string; image?: string }) =>
    api.patch('/user/profile', data),
  
  deleteFile: (id: string) => api.delete(`/user/files/${id}`),
  
  getActivity: () => api.get('/user/activity'),
};

// Payments API
export const paymentsApi = {
  getConfig: () => api.get('/payments/config'),
  
  createCheckout: (data: { plan: 'PRO' | 'BUSINESS'; successUrl: string; cancelUrl: string }) =>
    api.post('/payments/checkout', data),
  
  createPortal: (returnUrl: string) =>
    api.post('/payments/portal', { returnUrl }),
  
  getSubscription: (id: string) => api.get(`/payments/subscription/${id}`),
  
  cancelSubscription: (id: string) => api.post(`/payments/subscription/${id}/cancel`),
};

// Health check
export const healthCheck = () => api.get('/health');

export default api;
