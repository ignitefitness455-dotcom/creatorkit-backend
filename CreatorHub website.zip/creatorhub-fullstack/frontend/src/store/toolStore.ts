import { create } from 'zustand';
import type { ToolCategory, FileItem, ToolState } from '@/types';

interface ToolStore extends ToolState {
  setSelectedCategory: (category: ToolCategory) => void;
  setSearchQuery: (query: string) => void;
  setSelectedTool: (toolId: string | null) => void;
  openToolModal: (toolId: string) => void;
  closeToolModal: () => void;
  addFile: (file: FileItem) => void;
  removeFile: (fileId: string) => void;
  updateFile: (fileId: string, updates: Partial<FileItem>) => void;
  clearFiles: () => void;
  setProcessingStatus: (status: ToolState['processingStatus']) => void;
  setProcessingProgress: (progress: number) => void;
  resetProcessing: () => void;
}

export const useToolStore = create<ToolStore>((set) => ({
  selectedCategory: 'all',
  searchQuery: '',
  selectedTool: null,
  isToolModalOpen: false,
  uploadedFiles: [],
  processingStatus: 'idle',
  processingProgress: 0,

  setSelectedCategory: (category) => set({ selectedCategory: category }),
  setSearchQuery: (query) => set({ searchQuery: query }),
  setSelectedTool: (toolId) => set({ selectedTool: toolId }),

  openToolModal: (toolId) =>
    set({
      selectedTool: toolId,
      isToolModalOpen: true,
    }),

  closeToolModal: () =>
    set({
      selectedTool: null,
      isToolModalOpen: false,
      uploadedFiles: [],
      processingStatus: 'idle',
      processingProgress: 0,
    }),

  addFile: (file) =>
    set((state) => ({
      uploadedFiles: [...state.uploadedFiles, file],
    })),

  removeFile: (fileId) =>
    set((state) => ({
      uploadedFiles: state.uploadedFiles.filter((f) => f.id !== fileId),
    })),

  updateFile: (fileId, updates) =>
    set((state) => ({
      uploadedFiles: state.uploadedFiles.map((f) =>
        f.id === fileId ? { ...f, ...updates } : f
      ),
    })),

  clearFiles: () => set({ uploadedFiles: [] }),

  setProcessingStatus: (status) => set({ processingStatus: status }),
  setProcessingProgress: (progress) => set({ processingProgress: progress }),

  resetProcessing: () =>
    set({
      processingStatus: 'idle',
      processingProgress: 0,
    }),
}));
