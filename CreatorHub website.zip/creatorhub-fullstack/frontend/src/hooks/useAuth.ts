import { useEffect } from 'react';
import { useAuthStore } from '@/store/authStore';

export function useAuth() {
  const {
    user,
    isAuthenticated,
    isLoading,
    login,
    register,
    logout,
    fetchUser,
    updateProfile,
    changePassword,
  } = useAuthStore();

  // Fetch user on mount
  useEffect(() => {
    if (!isAuthenticated && !isLoading) {
      fetchUser();
    }
  }, []);

  return {
    user,
    isAuthenticated,
    isLoading,
    login,
    register,
    logout,
    fetchUser,
    updateProfile,
    changePassword,
    isFree: user?.plan === 'free',
    isPro: user?.plan === 'pro',
    isBusiness: user?.plan === 'business',
    credits: user?.credits || 0,
  };
}

export default useAuth;
