import { useState, useCallback } from 'react';
import { toolsApi } from '@/lib/api';
import type { Tool } from '@/types';

interface UseToolsReturn {
  tools: Tool[];
  categories: { id: string; name: string; icon: string }[];
  isLoading: boolean;
  error: string | null;
  fetchTools: (params?: { category?: string; search?: string }) => Promise<void>;
  fetchCategories: () => Promise<void>;
  getToolById: (id: string) => Tool | undefined;
}

export function useTools(): UseToolsReturn {
  const [tools, setTools] = useState<Tool[]>([]);
  const [categories, setCategories] = useState<{ id: string; name: string; icon: string }[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchTools = useCallback(async (params?: { category?: string; search?: string }) => {
    try {
      setIsLoading(true);
      setError(null);
      const response = await toolsApi.getAll(params);
      setTools(response.data.tools);
    } catch (err: any) {
      setError(err.response?.data?.error || 'Failed to fetch tools');
    } finally {
      setIsLoading(false);
    }
  }, []);

  const fetchCategories = useCallback(async () => {
    try {
      const response = await toolsApi.getCategories();
      setCategories(response.data.categories);
    } catch (err: any) {
      console.error('Failed to fetch categories:', err);
    }
  }, []);

  const getToolById = useCallback((id: string) => {
    return tools.find(tool => tool.id === id);
  }, [tools]);

  return {
    tools,
    categories,
    isLoading,
    error,
    fetchTools,
    fetchCategories,
    getToolById,
  };
}

export default useTools;
