import { useState, useCallback } from 'react';
import { toolsApi } from '@/lib/api';

interface ProcessingState {
  isProcessing: boolean;
  progress: number;
  result: any;
  error: string | null;
}

interface UseToolProcessorReturn extends ProcessingState {
  processPdfMerge: (files: File[]) => Promise<void>;
  processPdfSplit: (file: File, options: { pages?: number[]; mode: 'extract' | 'split' }) => Promise<void>;
  processPdfCompress: (file: File, quality: 'low' | 'medium' | 'high') => Promise<void>;
  processPdfRotate: (file: File, angle: 90 | 180 | 270, pages?: number[]) => Promise<void>;
  processImageCompress: (file: File, quality: number, format?: string) => Promise<void>;
  processImageConvert: (file: File, format: 'jpeg' | 'png' | 'webp' | 'gif' | 'avif') => Promise<void>;
  processImageResize: (file: File, options: { width?: number; height?: number; maintainAspectRatio: boolean }) => Promise<void>;
  processImageCrop: (file: File, crop: { left: number; top: number; width: number; height: number }) => Promise<void>;
  processImageWatermark: (file: File, options: { text: string; position: string; opacity: number; size: number }) => Promise<void>;
  processQrGenerate: (text: string, options?: { size?: number; color?: string; bgColor?: string }) => Promise<void>;
  processAiText: (prompt: string, options?: { maxTokens?: number; temperature?: number }) => Promise<void>;
  processAiImage: (prompt: string, options?: { size?: string; quality?: string; style?: string }) => Promise<void>;
  processAiCaption: (topic: string, platform: string, tone?: string) => Promise<void>;
  processAiHashtags: (topic: string, count?: number) => Promise<void>;
  processAiBio: (data: { name: string; profession: string; interests?: string[]; platform: string }) => Promise<void>;
  processAiCode: (description: string, language: string) => Promise<void>;
  processAiTranslate: (text: string, targetLanguage: string, sourceLanguage?: string) => Promise<void>;
  processAiSummarize: (text: string, maxLength?: number) => Promise<void>;
  processPasswordGenerator: (options: { length?: number; includeUppercase?: boolean; includeNumbers?: boolean; includeSymbols?: boolean }) => Promise<void>;
  processEmiCalculator: (data: { principal: number; rate: number; tenure: number }) => Promise<void>;
  processUnitConverter: (data: { value: number; from: string; to: string; category: string }) => Promise<void>;
  reset: () => void;
}

export function useToolProcessor(): UseToolProcessorReturn {
  const [state, setState] = useState<ProcessingState>({
    isProcessing: false,
    progress: 0,
    result: null,
    error: null,
  });

  const setProcessing = useCallback((isProcessing: boolean) => {
    setState(prev => ({ ...prev, isProcessing }));
  }, []);

  const setProgress = useCallback((progress: number) => {
    setState(prev => ({ ...prev, progress }));
  }, []);

  const setResult = useCallback((result: any) => {
    setState(prev => ({ ...prev, result, isProcessing: false, progress: 100 }));
  }, []);

  const setError = useCallback((error: string) => {
    setState(prev => ({ ...prev, error, isProcessing: false, progress: 0 }));
  }, []);

  const reset = useCallback(() => {
    setState({
      isProcessing: false,
      progress: 0,
      result: null,
      error: null,
    });
  }, []);

  // PDF Tools
  const processPdfMerge = useCallback(async (files: File[]) => {
    try {
      setProcessing(true);
      setProgress(10);
      const response = await toolsApi.pdfMerge(files);
      setProgress(100);
      setResult(response.data.result);
    } catch (err: any) {
      setError(err.response?.data?.error || 'PDF merge failed');
    }
  }, []);

  const processPdfSplit = useCallback(async (file: File, options: { pages?: number[]; mode: 'extract' | 'split' }) => {
    try {
      setProcessing(true);
      setProgress(10);
      const response = await toolsApi.pdfSplit(file, options);
      setProgress(100);
      setResult(response.data.result);
    } catch (err: any) {
      setError(err.response?.data?.error || 'PDF split failed');
    }
  }, []);

  const processPdfCompress = useCallback(async (file: File, quality: 'low' | 'medium' | 'high') => {
    try {
      setProcessing(true);
      setProgress(10);
      const response = await toolsApi.pdfCompress(file, quality);
      setProgress(100);
      setResult(response.data.result);
    } catch (err: any) {
      setError(err.response?.data?.error || 'PDF compression failed');
    }
  }, []);

  const processPdfRotate = useCallback(async (file: File, angle: 90 | 180 | 270, pages?: number[]) => {
    try {
      setProcessing(true);
      setProgress(10);
      const response = await toolsApi.pdfRotate(file, angle, pages);
      setProgress(100);
      setResult(response.data.result);
    } catch (err: any) {
      setError(err.response?.data?.error || 'PDF rotation failed');
    }
  }, []);

  // Image Tools
  const processImageCompress = useCallback(async (file: File, quality: number, format?: string) => {
    try {
      setProcessing(true);
      setProgress(10);
      const response = await toolsApi.imageCompress(file, quality, format);
      setProgress(100);
      setResult(response.data.result);
    } catch (err: any) {
      setError(err.response?.data?.error || 'Image compression failed');
    }
  }, []);

  const processImageConvert = useCallback(async (file: File, format: 'jpeg' | 'png' | 'webp' | 'gif' | 'avif') => {
    try {
      setProcessing(true);
      setProgress(10);
      const response = await toolsApi.imageConvert(file, format);
      setProgress(100);
      setResult(response.data.result);
    } catch (err: any) {
      setError(err.response?.data?.error || 'Image conversion failed');
    }
  }, []);

  const processImageResize = useCallback(async (file: File, options: { width?: number; height?: number; maintainAspectRatio: boolean }) => {
    try {
      setProcessing(true);
      setProgress(10);
      const response = await toolsApi.imageResize(file, options);
      setProgress(100);
      setResult(response.data.result);
    } catch (err: any) {
      setError(err.response?.data?.error || 'Image resize failed');
    }
  }, []);

  const processImageCrop = useCallback(async (file: File, crop: { left: number; top: number; width: number; height: number }) => {
    try {
      setProcessing(true);
      setProgress(10);
      const response = await toolsApi.imageCrop(file, crop);
      setProgress(100);
      setResult(response.data.result);
    } catch (err: any) {
      setError(err.response?.data?.error || 'Image crop failed');
    }
  }, []);

  const processImageWatermark = useCallback(async (file: File, options: { text: string; position: string; opacity: number; size: number }) => {
    try {
      setProcessing(true);
      setProgress(10);
      const response = await toolsApi.imageWatermark(file, options);
      setProgress(100);
      setResult(response.data.result);
    } catch (err: any) {
      setError(err.response?.data?.error || 'Watermark failed');
    }
  }, []);

  // QR Code
  const processQrGenerate = useCallback(async (text: string, options?: { size?: number; color?: string; bgColor?: string }) => {
    try {
      setProcessing(true);
      setProgress(10);
      const response = await toolsApi.qrGenerate(text, options);
      setProgress(100);
      setResult(response.data.result);
    } catch (err: any) {
      setError(err.response?.data?.error || 'QR code generation failed');
    }
  }, []);

  // AI Tools
  const processAiText = useCallback(async (prompt: string, options?: { maxTokens?: number; temperature?: number }) => {
    try {
      setProcessing(true);
      setProgress(10);
      const response = await toolsApi.aiText(prompt, options);
      setProgress(100);
      setResult(response.data.result);
    } catch (err: any) {
      setError(err.response?.data?.error || 'Text generation failed');
    }
  }, []);

  const processAiImage = useCallback(async (prompt: string, options?: { size?: string; quality?: string; style?: string }) => {
    try {
      setProcessing(true);
      setProgress(10);
      const response = await toolsApi.aiImage(prompt, options);
      setProgress(100);
      setResult(response.data.result);
    } catch (err: any) {
      setError(err.response?.data?.error || 'Image generation failed');
    }
  }, []);

  const processAiCaption = useCallback(async (topic: string, platform: string, tone?: string) => {
    try {
      setProcessing(true);
      setProgress(10);
      const response = await toolsApi.aiCaption(topic, platform, tone);
      setProgress(100);
      setResult(response.data.result);
    } catch (err: any) {
      setError(err.response?.data?.error || 'Caption generation failed');
    }
  }, []);

  const processAiHashtags = useCallback(async (topic: string, count?: number) => {
    try {
      setProcessing(true);
      setProgress(10);
      const response = await toolsApi.aiHashtags(topic, count);
      setProgress(100);
      setResult(response.data.result);
    } catch (err: any) {
      setError(err.response?.data?.error || 'Hashtag generation failed');
    }
  }, []);

  const processAiBio = useCallback(async (data: { name: string; profession: string; interests?: string[]; platform: string }) => {
    try {
      setProcessing(true);
      setProgress(10);
      const response = await toolsApi.aiBio(data);
      setProgress(100);
      setResult(response.data.result);
    } catch (err: any) {
      setError(err.response?.data?.error || 'Bio generation failed');
    }
  }, []);

  const processAiCode = useCallback(async (description: string, language: string) => {
    try {
      setProcessing(true);
      setProgress(10);
      const response = await toolsApi.aiCode(description, language);
      setProgress(100);
      setResult(response.data.result);
    } catch (err: any) {
      setError(err.response?.data?.error || 'Code generation failed');
    }
  }, []);

  const processAiTranslate = useCallback(async (text: string, targetLanguage: string, sourceLanguage?: string) => {
    try {
      setProcessing(true);
      setProgress(10);
      const response = await toolsApi.aiTranslate(text, targetLanguage, sourceLanguage);
      setProgress(100);
      setResult(response.data.result);
    } catch (err: any) {
      setError(err.response?.data?.error || 'Translation failed');
    }
  }, []);

  const processAiSummarize = useCallback(async (text: string, maxLength?: number) => {
    try {
      setProcessing(true);
      setProgress(10);
      const response = await toolsApi.aiSummarize(text, maxLength);
      setProgress(100);
      setResult(response.data.result);
    } catch (err: any) {
      setError(err.response?.data?.error || 'Summarization failed');
    }
  }, []);

  // Business Tools
  const processPasswordGenerator = useCallback(async (options: { length?: number; includeUppercase?: boolean; includeNumbers?: boolean; includeSymbols?: boolean }) => {
    try {
      setProcessing(true);
      const response = await toolsApi.passwordGenerator(options);
      setResult(response.data.result);
    } catch (err: any) {
      setError(err.response?.data?.error || 'Password generation failed');
    }
  }, []);

  const processEmiCalculator = useCallback(async (data: { principal: number; rate: number; tenure: number }) => {
    try {
      setProcessing(true);
      const response = await toolsApi.emiCalculator(data);
      setResult(response.data.result);
    } catch (err: any) {
      setError(err.response?.data?.error || 'EMI calculation failed');
    }
  }, []);

  const processUnitConverter = useCallback(async (data: { value: number; from: string; to: string; category: string }) => {
    try {
      setProcessing(true);
      const response = await toolsApi.unitConverter(data);
      setResult(response.data.result);
    } catch (err: any) {
      setError(err.response?.data?.error || 'Unit conversion failed');
    }
  }, []);

  return {
    ...state,
    processPdfMerge,
    processPdfSplit,
    processPdfCompress,
    processPdfRotate,
    processImageCompress,
    processImageConvert,
    processImageResize,
    processImageCrop,
    processImageWatermark,
    processQrGenerate,
    processAiText,
    processAiImage,
    processAiCaption,
    processAiHashtags,
    processAiBio,
    processAiCode,
    processAiTranslate,
    processAiSummarize,
    processPasswordGenerator,
    processEmiCalculator,
    processUnitConverter,
    reset,
  };
}

export default useToolProcessor;
