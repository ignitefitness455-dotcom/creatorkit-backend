# CreatorHub Full-Stack Deployment Guide

## Overview

This guide will help you deploy the CreatorHub full-stack application (frontend + backend) to production.

## Architecture

- **Frontend**: React + Vite + TypeScript (Deploy to Vercel/Netlify)
- **Backend**: Express + TypeScript + Prisma (Deploy to Railway)
- **Database**: PostgreSQL (Railway provides this)

---

## Part 1: Deploy Backend to Railway

### Step 1: Push Backend Code to GitHub

```bash
cd /mnt/okcomputer/output/creatorhub-fullstack/backend

# Initialize git (if not already done)
git init

# Add all files
git add .

# Commit
git commit -m "Initial backend commit"

# Create GitHub repository and push
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/creatorhub-backend.git
git push -u origin main
```

### Step 2: Create Railway Project

1. Go to https://railway.app/dashboard
2. Click **"New Project"**
3. Select **"Deploy from GitHub repo"**
4. Choose your `creatorhub-backend` repository
5. Railway will automatically detect the configuration

### Step 3: Add PostgreSQL Database

1. In your Railway project, click **"New"**
2. Select **"Database"** → **"Add PostgreSQL"**
3. Railway will automatically:
   - Create the database
   - Set the `DATABASE_URL` environment variable

### Step 4: Configure Environment Variables

Go to your backend service → **Variables** tab and add:

```env
# Required - Railway auto-sets this
DATABASE_URL=${{Postgres.DATABASE_URL}}

# Required - Generate strong random strings
JWT_SECRET=your-super-secret-jwt-key-min-32-characters-long
JWT_REFRESH_SECRET=your-super-secret-refresh-key-min-32-characters-long

# Optional
NODE_ENV=production
FRONTEND_URL=https://your-frontend-url.vercel.app
PORT=5000

# Optional - Stripe (for payments)
STRIPE_SECRET_KEY=sk_test_your_stripe_key
STRIPE_WEBHOOK_SECRET=whsec_your_webhook_secret
STRIPE_PRICE_PRO=price_your_pro_price_id
STRIPE_PRICE_BUSINESS=price_your_business_price_id

# Optional - OpenAI (for AI tools)
OPENAI_API_KEY=sk-your-openai-api-key
```

### Step 5: Deploy Backend

Railway will auto-deploy when you push to GitHub. To manually deploy:

1. Go to your backend service
2. Click **"Deploy"** button

### Step 6: Verify Backend Deployment

After deployment, test these endpoints:

1. **Health Check**: `https://your-app.railway.app/health`
   ```json
   {"status":"healthy","database":"connected"}
   ```

2. **API Info**: `https://your-app.railway.app/api`

---

## Part 2: Deploy Frontend to Vercel

### Step 1: Push Frontend Code to GitHub

```bash
cd /mnt/okcomputer/output/creatorhub-fullstack/frontend

# Initialize git
git init

# Add all files
git add .

# Commit
git commit -m "Initial frontend commit"

# Create GitHub repository and push
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/creatorhub-frontend.git
git push -u origin main
```

### Step 2: Deploy to Vercel

1. Go to https://vercel.com/dashboard
2. Click **"Add New Project"**
3. Import your GitHub repository
4. Configure:
   - **Framework Preset**: Vite
   - **Build Command**: `npm run build`
   - **Output Directory**: `dist`

5. Add Environment Variables:
   ```env
   VITE_API_URL=https://your-backend.railway.app/api
   ```

6. Click **"Deploy"**

### Step 3: Update Backend CORS

After frontend deployment, update your backend environment variable:

```env
FRONTEND_URL=https://your-frontend.vercel.app
```

Then redeploy the backend.

---

## Troubleshooting

### Backend Issues

#### "Cannot find module '@prisma/client'"

**Solution**: The `postinstall` script in package.json should run `prisma generate`. Check it's there:
```json
"postinstall": "prisma generate || true"
```

#### Database connection failed

**Solution**:
- Ensure PostgreSQL is added to your Railway project
- Check `DATABASE_URL` is set correctly
- Format: `postgresql://user:password@host:port/database`

#### Health check failing

**Solution**:
- Ensure server starts on PORT 5000
- Check `/health` endpoint returns 200 OK

### Frontend Issues

#### API calls failing (CORS)

**Solution**:
- Update `FRONTEND_URL` in backend to match your Vercel URL
- Redeploy backend

#### Build failures

**Solution**:
- Check `vite.config.ts` has correct base path
- Ensure all imports are correct

---

## Environment Variables Summary

### Backend (.env)

```env
# Required
DATABASE_URL=postgresql://...
JWT_SECRET=your-jwt-secret
JWT_REFRESH_SECRET=your-refresh-secret

# Optional
NODE_ENV=production
FRONTEND_URL=https://your-frontend.vercel.app
PORT=5000

# Stripe (optional)
STRIPE_SECRET_KEY=sk_...
STRIPE_WEBHOOK_SECRET=whsec_...
STRIPE_PRICE_PRO=price_...
STRIPE_PRICE_BUSINESS=price_...

# OpenAI (optional)
OPENAI_API_KEY=sk-...
```

### Frontend (.env)

```env
VITE_API_URL=https://your-backend.railway.app/api
```

---

## Post-Deployment

### 1. Create Admin User

Use the seed data or register via the API:

```bash
curl -X POST https://your-backend.railway.app/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@creatorhub.com","password":"admin123","name":"Admin"}'
```

### 2. Test All Features

- User registration/login
- File uploads
- PDF tools
- Image tools
- AI tools (if OpenAI key is set)
- Payment flow (if Stripe is set)

### 3. Monitor Logs

- **Railway**: Dashboard → Service → Logs
- **Vercel**: Dashboard → Project → Functions

---

## Support

If you encounter issues:

1. Check deployment logs
2. Verify all environment variables are set
3. Ensure database is connected
4. Test API endpoints directly
5. Check browser console for frontend errors
